/* Pocket Board site — flowing background + interactive demo */
(() => {
const GLASS_FRAG_SRC = "precision highp float;\nprecision highp sampler2D;\nvec4 fragColor;\nvec4 fragCover;\nout vec4 outColor;\nuniform float uDarkK;\nuniform float uAmbientLift;\n\nin vec2 vPos;\n// dual-source blending(GL3.3\u30b3\u30a2)\u3002fragColor\u304c\u52a0\u7b97\u3055\u308c\u308b\u8272\u3001fragCover\u306e\n// \u30a2\u30eb\u30d5\u30a1\u304c\u300cdst\u3092\u3069\u308c\u3060\u3051\u9000\u304b\u305b\u308b\u304b\u300d\u3002\u901a\u5e38\u306e\u30d6\u30ec\u30f3\u30c9\u3060\u3068\u7f6e\u304d\u63db\u3048\u91cf\u3068\n// \u30a2\u30eb\u30d5\u30a1\u66f8\u304d\u8fbc\u307f\u91cf\u304c\u9023\u52d5\u3057\u3066\u3057\u307e\u3044\u3001\u534a\u900f\u660e\u306e\u30dc\u30fc\u30c9\u4e0a\u3067\u5c48\u6298\u306e\n// \u300c\u30b5\u30f3\u30d7\u30eb\u306b\u3088\u308b\u7f6e\u304d\u63db\u3048\u300d\u304c\u6052\u7b49\u306b\u306a\u3089\u305a\u767d\u6d6e\u304d\u3059\u308b(2026-07-19\u306b\u5b9f\u6a5f\u3067\n// \u78ba\u8a8d)\u3002\u30d6\u30ec\u30f3\u30c9\u5f0f\u306f draw() \u5074\u3067 GL_ONE / GL_ONE_MINUS_SRC1_ALPHA\u3002\nuniform vec2      uCenter;\nuniform vec2      uHalfSize;\nuniform float     uRadius;\nuniform float     uBezelPx;     // \u67a0\uff08board\u7e01\u301c\u30b3\u30f3\u30c6\u30f3\u30c4\u7e01\uff09\u306e\u539a\u307f(px)\nuniform float     uContentRadius; // \u5b9f\u969b\u306e\u30b3\u30f3\u30c6\u30f3\u30c4\u89d2\u4e38\u534a\u5f84(px)\nuniform float     uNormalScalePx; // \u5c48\u6298\u6cd5\u7dda\u306e\u6df1\u3055\u57fa\u6e96(px)\nuniform float     uLightAngle;  // \u30e9\u30b8\u30a2\u30f3\u3002\u30d0\u30d6\u30eb\u4e2d\u5fc3\u2192\u5149\u6e90\u306e\u65b9\u5411\nuniform float     uIntensity;   // 0\u301c1\nuniform float     uInnerMix;    // \u5185\u5074\u30ec\u30a4\u30e4\u30fc(innerGlow/innerLine)\u306e\u5f37\u30550\u301c1\u3002\n                                // \u30e9\u30f3\u30c1\u30e3\u30fc\u7b49\u306e\u5c0f\u3055\u306a\u6b63\u65b9\u5f62\u30d0\u30d6\u30eb\u3067\u306f\u5185\u5074\u306e\u7dda\u304c\n                                // \u300c\u56db\u89d2\u306e\u4e2d\u306e\u56db\u89d2\u300d\u306b\u898b\u3048\u3066\u4e0d\u81ea\u7136\u306a\u305f\u30810\u306b\u3059\u308b\nuniform sampler2D uContent;     // \u73fe\u5728\u8868\u793a\u4e2d\u306e\u52d5\u753b/\u753b\u50cf\u3002Quality\u8272\u53cd\u5c04\u7528\nuniform vec4      uContentUvRect; // xy=\u5de6\u4e0a\u3001zw=\u5e45/\u9ad8\u3055(Renderer\u3068\u540c\u3058UV\u7cfb)\nuniform float     uContentReflection; // 0=\u7121\u52b9\u30011=Quality\u306e\u30b3\u30f3\u30c6\u30f3\u30c4\u8272\u53cd\u5c04\nuniform sampler2D uCapture;     // \u5c0f\u9818\u57df\u30ad\u30e3\u30d7\u30c1\u30e3(\u30cd\u30a4\u30c6\u30a3\u30d6\u89e3\u50cf\u5ea6\u3001premultiplied)\nuniform vec2      uCaptureTextureSize; // \u30ad\u30e3\u30d7\u30c1\u30e3\u30c6\u30af\u30b9\u30c1\u30e3\u306e\u78ba\u4fdd\u5bb9\u91cf\nuniform vec2      uCaptureOrigin;      // \u5143FBO\u5185\u306e\u5c0f\u9818\u57df\u5de6\u4e0b(\u7269\u7406px)\nuniform vec2      uCaptureSourceSize;  // \u5143FBO\u4e0a\u3067\u306e\u5c0f\u9818\u57df\u30b5\u30a4\u30ba(\u7269\u7406px)\nuniform vec2      uCaptureDataSize;    // \u30ad\u30e3\u30d7\u30c1\u30e3\u5074\u3078\u66f8\u304d\u8fbc\u3093\u3060\u30b5\u30a4\u30ba\nuniform float     uDpr;         // \u8ad6\u7406px\u2192\u7269\u7406px\u306e\u500d\u7387\nuniform float     uRefractMix;  // \u30ad\u30e3\u30d7\u30c1\u30e3\u7591\u4f3c\u5c48\u6298\u306e\u5f37\u30550\u301c1(\u54c1\u8cea=Quality\u306e\u307f>0)\nuniform float     uRefraction;  // \u56fa\u5b9a\u6cd5\u7dda\u304b\u3089\u7b97\u51fa\u3057\u305f\u5909\u4f4d\u3078\u639b\u3051\u308b\u5f37\u5ea6\nuniform float     uEdgeBoost;   // \u6700\u7d42\u5909\u4f4d\u306e\u5916\u5468\u6210\u5206\u3060\u3051\u3092\u8ffd\u52a0\u5897\u5e45\nuniform float     uChromatic;   // R/B\u30b5\u30f3\u30d7\u30eb\u8ddd\u96e2\u306e\u00b1\u5dee\nuniform float     uRefractionPrepass; // >0.5: \u5168\u9762\u5c48\u6298\u3060\u3051\u3092\u63cf\u304f\u80cc\u666f\u30d7\u30ea\u30d1\u30b9\nuniform float     uDebugNormal; // Shift+D\u30c7\u30d0\u30c3\u30b0\u30020:\u901a\u5e38 1:\u6cd5\u7dda\u8868\u793a 2:\u5c48\u6298\u30ec\u30a4\u30e4\u30fc\u5358\u4f53\u8868\u793a\nuniform float     uSurfaceProfile; // 0=\u52d5\u753b/\u753b\u50cf\u30011=\u30e9\u30f3\u30c1\u30e3\u30fc\u5c02\u7528\u306e\u5916\u5468\u96c6\u4e2d\u578b\nuniform float     uNormalInfluence; // \u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u5225\u306e\u6cd5\u7dda\u5909\u4f4d\u500d\u7387\nuniform vec4      uTint;\nuniform sampler2D uGummySmall;        // 2026-10-11 \u30b0\u30df: \u4e2d\u8eab\u309264\u00d764\u3078\u7e2e\u3081\u305f\u5c0f\u30c6\u30af\u30b9\u30c1\u30e3\uff08\u30df\u30c3\u30d7\u4ed8\u304d\u30fbpremultiplied\uff09\nuniform float     uGummySmallValid;   // \u30b0\u30df: uGummySmall \u304c\u4f7f\u3048\u308b\u3068\u304d1\nuniform sampler2D uGummyCaptureSmall; // \u30b0\u30df: \u80cc\u666f\u30ad\u30e3\u30d7\u30c1\u30e3\u309264\u00d764\u3078\u7e2e\u3081\u305f\u5c0f\u30c6\u30af\u30b9\u30c1\u30e3\uff08\u30df\u30c3\u30d7\u4ed8\u304d\uff09\nuniform float     uCaptureTint; // 2026-10-11 \u30b0\u30df: \u63b4\u3093\u3067\u3044\u308b\u9593\u3001\u80cc\u666f\u30ad\u30e3\u30d7\u30c1\u30e3\u306e\u8272\u3092\u30b2\u30eb\u3078\u6df7\u305c\u308b\u5f37\u3055(0\u301c1)        // uTint.a\u306f\u5168\u4f53\u5f37\u5ea6\u306e\u8ffd\u52a0\u4e57\u6570\u3068\u3057\u3066\u4f7f\u3046\n// 2026-09-22: \u30d0\u30d6\u30eb\u878d\u5408\uff08GlassHighlightEffect::Fusion\uff09\u3002uFuseK=0 \u3067\u7121\u52b9\u3002\nuniform float     uFuseK;             // smin \u306e\u5e45\uff08px\uff09\nuniform vec2      uFuseCenter;        // \u76f8\u624b\u306e\u677f\u306e\u4e2d\u5fc3\nuniform vec2      uFuseHalfSize;      // \u76f8\u624b\u306e\u677f\u306e\u534a\u30b5\u30a4\u30ba\nuniform float     uFuseRadius;        // \u76f8\u624b\u306e\u677f\u306e\u89d2\u4e38\u534a\u5f84\nuniform float     uFuseLightAngle;    // \u76f8\u624b\u306e\u30e9\u30a4\u30c8\u89d2\u5ea6\uff08\u9996\u306e\u90e8\u5206\u3067\u88dc\u9593\u3059\u308b\uff09\nuniform float     uFuseBezelPx;       // \u76f8\u624b\u306e\u30d9\u30bc\u30eb\u5e45\nuniform float     uFuseContentRadius; // \u76f8\u624b\u306e\u30b3\u30f3\u30c6\u30f3\u30c4\u89d2\u4e38\u534a\u5f84\n// 2026-09-23: \u5c48\u6298\u30d7\u30ea\u30d1\u30b9\u306e\u7a74\uff08Fusion::prepassHole\uff09\u3002uPrepassHoleAmount=0 \u3067\u7121\u52b9\u3002\nuniform vec2      uPrepassHoleCenter;\nuniform vec2      uPrepassHoleHalf;\nuniform float     uPrepassHoleAmount;\n\nvec2 captureUv(vec2 physicalPos) {\n    vec2 local = clamp(\n        (physicalPos - uCaptureOrigin) / max(uCaptureSourceSize, vec2(1.0)),\n        0.0, 1.0);\n    // \u66f8\u304d\u8fbc\u307f\u6e08\u307f\u7bc4\u56f2\u306e\u6700\u521d\u301c\u6700\u5f8c\u306e\u30c6\u30af\u30bb\u30eb\u4e2d\u5fc3\u3078\u5199\u50cf\u3059\u308b\u3002\u78ba\u4fdd\u5bb9\u91cf\u3092\n    // \u4e38\u3081\u3066\u4f59\u767d\u304c\u3042\u308b\u5834\u5408\u3067\u3082\u3001\u672a\u66f8\u304d\u8fbc\u307f\u90e8\u5206\u3092\u7dda\u5f62\u88dc\u9593\u3067\u62fe\u308f\u306a\u3044\u3002\n    vec2 texel = local * max(uCaptureDataSize - vec2(1.0), vec2(0.0))\n               + vec2(0.5);\n    return texel / max(uCaptureTextureSize, vec2(1.0));\n}\n\n// \u30e9\u30f3\u30c1\u30e3\u30fc\u306e\u89d2\u4e38\u7387\u306b\u5fdc\u3058\u305f\u5c48\u6298\u6cd5\u7dda\u306e\u6df1\u3055\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u3002\n// \u5c0f\u3055\u3044\u30d0\u30d6\u30eb\uff08\u89d2\u4e38\u7387\u304c\u9ad8\u3044\uff09\u306f\u5e83\u304f\u67d4\u3089\u304b\u304f\u3001\u5927\u304d\u3044\u30d0\u30d6\u30eb\n// \uff08\u89d2\u4e38\u7387\u304c\u4f4e\u3044\uff09\u306f\u72ed\u304f\u7de0\u307e\u308b\u3002\nfloat launcherBendProfile(float depth, float cornerRatio) {\n    float roundness = smoothstep(0.12, 0.42, cornerRatio);\n    float broadWeight = mix(0.16, 0.30, roundness);\n    float sharpDecay = mix(5.2, 3.9, roundness);\n    float broadDecay = mix(2.3, 1.55, roundness);\n    return (1.0 - broadWeight) * exp(-sharpDecay * depth)\n         + broadWeight * exp(-broadDecay * depth);\n}\n\n#ifdef CARVED_GLASS\n// ---- \u524a\u308a\u51fa\u3057\u306e\u65ad\u9762\uff082026-09-16\uff09------------------------------------------\n// \u9762\u53d6\u308a\u306e\u5e2f\u306e\u4f4d\u7f6e\u3068\u5e45\u3002\u30e9\u30a4\u30c6\u30a3\u30f3\u30b0\u30fb\u53cd\u5c04\u30fb\u5c48\u6298\u30fb\u6cd5\u7dda\u8868\u793a\u3067\u540c\u3058\u3082\u306e\u3092\u4f7f\u3046\u3002\nconst float kCarveOuterRatio = 0.18;  // \u5916\u5468\u306e\u9762\u53d6\u308a\u306e\u5e45\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kCarveInnerRatio = 0.14;  // \u5185\u5074\u306e\u9762\u53d6\u308a\u306e\u5e45\nconst float kCarveSoft       = 0.30;  // \u6298\u308c\u76ee\u306e\u4e38\u307f\uff08\u9762\u53d6\u308a\u306e\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\n// \u5c48\u6298\u7528\u306e\u9762\u306e\u50be\u304d\uff08\u6a19\u6e96\u306e bend \u3068\u540c\u3058\u5c3a\u5ea6\u3002\u6a19\u6e96\u306f\u5916\u5468\u30671.0\u304b\u3089\u5185\u5074\u3078\u6e1b\u8870\uff09\u3002\n//   \u5916\u5468\u306e\u9762\u53d6\u308a \u2026 \u5916\u3078\u50be\u3044\u305f\u5e73\u3089\u306a\u659c\u9762\uff08\u4e00\u5b9a\u306e\u50be\u304d\uff09\n//   \u30d9\u30bc\u30eb\u306e\u9762   \u2026 2026-09-16: \u9762\u53d6\u308a\u3060\u3051\u3067\u306f\u3086\u304c\u307f\u304c\u307b\u3068\u3093\u3069\u611f\u3058\u3089\u308c\u306a\u304b\u3063\u305f\u305f\u3081\u3001\n//                  \u30d9\u30bc\u30eb\u306b\u3082\u5916\u5411\u304d\u306e\u50be\u304d\u3092\u6301\u305f\u305b\u305f\u3002\u5916\u5468\u5074\u306e\u6298\u308c\u76ee\u3067\u6700\u3082\u5f37\u304f\n//                  \uff08kCarveTiltFlat\uff09\u3001\u5185\u5074\u306e\u9762\u53d6\u308a\u3078\u5411\u304b\u3063\u30660\u307e\u3067\u5f31\u307e\u308b\u3002\n//                  kCarveTiltFlatCurve \u3067\u5f31\u307e\u308a\u65b9\u306e\u30ab\u30fc\u30d6\u3092\u5909\u3048\u3089\u308c\u308b\n//                  \uff081=\u76f4\u7dda\u3001\u5927\u304d\u3044\u307b\u3069\u5916\u5468\u5bc4\u308a\u306b\u96c6\u4e2d\uff09\u3002\n//   \u5185\u5074\u306e\u9762\u53d6\u308a \u2026 \u30b3\u30f3\u30c6\u30f3\u30c4\u3078\u843d\u3061\u308b\u659c\u9762\uff08\u50be\u304d\u306e\u5411\u304d\u304c\u9006\uff1d\u8ca0\u306e\u5024\uff09\n//   \u30b3\u30f3\u30c6\u30f3\u30c4   \u2026 \u50be\u304d0\uff08\u5c48\u6298\u3057\u306a\u3044\uff09\nconst float kCarveTiltOuter     = 0.85;\n// 2026-09-16: 0.55 / 1.4 \u3067\u306f\u9762\u53d6\u308a\u306e\u6298\u308c\u76ee\u304c\u57cb\u3082\u308c\u3066\u524a\u308a\u51fa\u3057\u3089\u3057\u3055\u304c\u6d88\u3048\u305f\u305f\u3081\u3001\n// \u307b\u3093\u306e\u308a\u4e57\u308b\u7a0b\u5ea6\u3078\u5f31\u3081\u305f\uff08\u9762\u53d6\u308a\u306e 0.85 \u3068\u306e\u6bb5\u5dee\u304c\u306f\u3063\u304d\u308a\u6b8b\u308b\uff09\u3002\n// \u3055\u3089\u306b\u8abf\u6574: \u5916\u5468\u306e\u6298\u308c\u76ee\u306e\u3059\u3050\u5185\u5074\u3060\u3051\u5f37\u3081\uff080.45\uff09\u3001\u30ab\u30fc\u30d6\u3092\u6025\u306b\u3057\u3066\uff083.0\uff09\n// \u3059\u3050\u5f31\u307e\u308b\u3088\u3046\u306b\u3057\u305f\u3002\u30d9\u30bc\u30eb\u306e\u4e2d\u307b\u3069\uff08u=0.5\uff09\u3067\u306e\u5f37\u3055\u306f 0.20/2.0 \u306e\u3068\u304d\u3068\n// \u307b\u307c\u540c\u3058\uff080.05\u21920.056\uff09\u306a\u306e\u3067\u3001\u6e1b\u8870\u306e\u611f\u3058\u306f\u5909\u3048\u305a\u306b\u5916\u5468\u4ed8\u8fd1\u3060\u3051\u304c\u5f37\u304f\u306a\u308b\u3002\nconst float kCarveTiltFlat      = 0.45;\nconst float kCarveTiltFlatCurve = 3.0;\nconst float kCarveTiltInner     = 0.60;\n\n// d: \u677f\u306e\u5916\u5468\u304b\u3089\u306e\u8ddd\u96e2\uff08\u5185\u5074\u304c\u8ca0\uff09 / dContent: \u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u7e01\u304b\u3089\u306e\u8ddd\u96e2\n// px: 1\u7269\u7406\u30d4\u30af\u30bb\u30eb\u3076\u3093\u306e\u8ad6\u7406px\uff08fwidth\u3067\u6c42\u3081\u3066\u6e21\u3059\uff09\nvoid carveBands(float d, float dContent, float bez, float sideMask, float px,\n                out float bandO, out float bandI, out float wO, out float wI)\n{\n    // \u5bc4\u308a\u3059\u304e\u30fb\u5f15\u304d\u3059\u304e\u3067\u3082\u7834\u7dbb\u3057\u306a\u3044\u3088\u3046\u30011\u753b\u7d20\u3076\u3093\u3060\u3051\u306f\u4e0b\u9650\u306b\u3059\u308b\n    wO = max(bez * kCarveOuterRatio, px);\n    wI = max(bez * kCarveInnerRatio, px);\n    float softO = max(wO * kCarveSoft, px);\n    float softI = max(wI * kCarveSoft, px);\n    // \u5e2f\u306e\u4e2d\u306b\u3044\u308b\u304b\u3002\u6298\u308c\u76ee\u306e\u524d\u5f8c soft \u306e\u7bc4\u56f2\u3060\u3051\u306a\u3081\u3089\u304b\u306b\u5207\u308a\u66ff\u3048\u308b\u3002\n    bandO = 1.0 - smoothstep(wO - 0.5 * softO, wO + 0.5 * softO, -d);\n    bandI = (1.0 - smoothstep(wI - 0.5 * softI, wI + 0.5 * softI, dContent)) * sideMask;\n}\n\n// \u9762\u53d6\u308a\u306e\u65ad\u9762\u304b\u3089\u6c42\u3081\u305f\u5c48\u6298\u306e\u50be\u304d\uff08\u7b26\u53f7\u4ed8\u304d\u3002\u6b63=\u5916\u5411\u304d\u3001\u8ca0=\u5185\u5411\u304d\uff09\n// sideMask: \u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u5916\uff08\u30d9\u30bc\u30eb\u5074\uff09\u306a\u30891\nfloat carveBend(float d, float bez, float px, float bandO, float bandI,\n                float sideMask, float innerMix)\n{\n    float wO = max(bez * kCarveOuterRatio, px);\n    float wI = max(bez * kCarveInnerRatio, px);\n    // \u30d9\u30bc\u30eb\u306e\u9762\u3067\u306e\u4f4d\u7f6e\u3002\u5916\u5468\u5074\u306e\u6298\u308c\u76ee\u30671\u3001\u5185\u5074\u306e\u9762\u53d6\u308a\u306e\u6298\u308c\u76ee\u30670\u3002\n    float flatSpan = max(bez - wO - wI, px);\n    float u = clamp((bez - wI - (-d)) / flatSpan, 0.0, 1.0);\n    float flatTilt = kCarveTiltFlat * pow(u, kCarveTiltFlatCurve);\n    float flatMask = (1.0 - bandO) * (1.0 - bandI) * sideMask;\n    return bandO * kCarveTiltOuter\n         + flatMask * flatTilt\n         - bandI * kCarveTiltInner * innerMix;\n}\n#endif\n\n#ifdef GUMMY_GLASS\n// ---- \u30b0\u30df\u306e\u65ad\u9762\u3068\u7c92\uff082026-10-11\uff09-------------------------------------------\n// \u8abf\u6574\u5024\u306f Claude outputs/gummy-glass-lab.html \u3067\u6c7a\u3081\u3066\u3001\u3053\u306e\u7bc4\u56f2\u3092\u4e38\u3054\u3068\u7f6e\u304d\u63db\u3048\u308b\u3002\n// 2026-10-11: \u30e9\u30dc\u3067\u6c7a\u3081\u305f\u5024\uff08\u30e9\u30f3\u30c1\u30e3\u30fc\u306f\u5f8c\u3067\u5225\u9014\u8abf\u6574\u4e88\u5b9a\uff09\u3002\n// @@GUMMY_PARAMS_BEGIN\nconst float kGummyDome        = 1.6;  // \u5916\u5468\u306e\u81a8\u3089\u307f\u306e\u5e45\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummyDomePow     = 3.7;  // \u81a8\u3089\u307f\u306e\u30ab\u30fc\u30d6\uff08\u5927\u304d\u3044\u307b\u3069\u7e01\u3067\u6025\u306b\u7acb\u3061\u4e0a\u304c\u308b\uff09\nconst float kGummyPuff        = 0.71;  // \u81a8\u3089\u307f\u306e\u9ad8\u3055\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummyWell        = 0.45;  // \u5185\u5074\u306e\u304f\u307c\u307f\u306e\u5e45\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummyWellDepth   = 0.38;  // \u304f\u307c\u307f\u306e\u6df1\u3055\uff080\u3067\u5e73\u3089\uff09\nconst float kGummyMilk        = 0.95;  // \u4e73\u767d\u306e\u6fc3\u3055\nconst float kGummyEdgeClear   = 1.0;  // \u7e01\u306e\u6fc3\u3055\uff08\u81a8\u3089\u307f\u306e\u9802\u4e0a\u306b\u5bfe\u3059\u308b\u6bd4\u3002\u5c0f\u3055\u3044\u307b\u3069\u7e01\u304c\u900f\u3051\u308b\uff09\nconst float kGummyAmbient     = 0.5;  // \u9670\u306b\u306a\u3063\u305f\u9762\u306e\u660e\u308b\u3055\nconst float kGummyBleed       = 0.79;  // \u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u8272\u306e\u306b\u3058\u307f\uff08Quality\u306e\u307f\uff09\nconst float kGummyBleedDepth  = 1.02;  // \u306b\u3058\u307f\u306e\u8272\u3092\u62fe\u3046\u6df1\u3055\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummyBleedFar    = 0.7;   // \u5916\u5468\u5074\u3092\u753b\u9762\u5168\u4f53\u306e\u5e73\u5747\u8272\u3078\u5bc4\u305b\u308b\u91cf\nconst float kGummyBleedSat    = 1.4;   // \u306b\u3058\u3080\u8272\u30fb\u6839\u672c\u306e\u5149\u306e\u5f69\u5ea6\uff081=\u4e2d\u8eab\u306e\u307e\u307e\uff09\nconst float kGummyRootGlow    = 0.6;   // \u6839\u672c\uff08\u4e2d\u8eab\u306e\u7e01\u306e\u3059\u3050\u5916\uff09\u306b\u5f53\u305f\u308b\u4e2d\u8eab\u306e\u5149\u306e\u5f37\u3055\nconst float kGummyRootWidth   = 0.18;  // \u6839\u672c\u306e\u5149\u306e\u5e45\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummyIconBleed   = 0.9;   // \u30e9\u30f3\u30c1\u30e3\u30fc\u306e\u30a2\u30a4\u30b3\u30f3\u306e\u8272\u306e\u306b\u3058\u307f\uff08\u52d5\u753b\u30fb\u753b\u50cf\u306f kGummyBleed\uff09\nconst float kGummyUnderTint  = 1.0;   // \u63b4\u3093\u3067\u3044\u308b\u9593\u3001\u4e0b\u306b\u3042\u308b\u3082\u306e\u306e\u8272\u3092\u30b2\u30eb\u3078\u6df7\u305c\u308b\u5f37\u3055\nconst float kGummyElev        = 0.83;  // \u5149\u306e\u9ad8\u3055\uff08\u30e9\u30b8\u30a2\u30f3\u3002\u5c0f\u3055\u3044\u307b\u3069\u6a2a\u304b\u3089\u5f53\u305f\u308b\uff09\nconst float kGummyWrap        = 0.51;  // \u5149\u306e\u56de\u308a\u8fbc\u307f\nconst float kGummySpec        = 0.7;  // \u3064\u3084\u306e\u5f37\u3055\nconst float kGummySpecPow     = 7.0;  // \u3064\u3084\u306e\u92ed\u3055\uff08\u5c0f\u3055\u3044\u307b\u3069\u5e83\u304f\u920d\u3044\uff09\nconst float kGummyRim         = 0.46;  // \u5916\u5468\u306e\u5149\u306e\u7dda\u3092\u6b8b\u3059\u91cf\uff08\u6a19\u6e96=1\uff09\nconst float kGummyRimSoft     = 2.2;  // \u5916\u5468\u306e\u5149\u306e\u7dda\u306e\u592a\u3055\uff08\u6a19\u6e96=1\uff09\nconst float kGummyGlassLayers = 0.0;  // \u30ac\u30e9\u30b9\u306e\u306b\u3058\u307f\u30fb\u5185\u5074\u306e\u7dda\u3092\u6b8b\u3059\u91cf\uff08\u6a19\u6e96=1\uff09\nconst float kGummySSS         = 1.33;  // \u900f\u904e\u5149\uff08\u5149\u306e\u53cd\u5bfe\u5074\u306e\u7e01\u306b\u305f\u307e\u308b\u5149\uff09\nconst float kGummySSSWidth    = 0.5;  // \u900f\u904e\u5149\u306e\u5e45\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummySSSSat      = 0.5;  // \u900f\u904e\u5149\u306e\u5f69\u5ea6\u30d6\u30fc\u30b9\u30c8\nconst float kGummySideDark    = 0.56;  // \u5074\u9762\u306e\u6c88\u307f\uff08\u6a19\u6e96=1\uff09\nconst float kGummyGrain       = 0.16;  // \u7c92\u306e\u5f37\u3055\nconst float kGummyGrainScale  = 0.01;  // \u7c92\u306e\u5927\u304d\u3055\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\nconst float kGummySparkle     = 0.31;  // \u3064\u3084\u306b\u4e57\u308b\u7c92\u306e\u304d\u3089\u3081\u304d\nconst vec3  kGummyTint        = vec3(0.930, 0.970, 0.980);  // \u30b2\u30eb\u306e\u8272\n// \u4e2d\u8eab\u30fb\u80cc\u666f\u306f64\u00d764\u3078\u7e2e\u3081\u305f\u5c0f\u30c6\u30af\u30b9\u30c1\u30e3\u304b\u3089\u8aad\u3080\u3002\u30df\u30c3\u30d7\u306e\u6bb5\u306f 0=64\u00d764\u30011\u6bb5\u3054\u3068\u306b\u534a\u5206\u30016=1\u00d71\nconst float kGummyBleedLevel   = 1.5;  // \u306b\u3058\u307f\u3092\u8aad\u3080\u6bb5\uff08\u6839\u672c\u5074\u3002\u5c0f\u3055\u3044\u307b\u3069\u7d30\u90e8\u304c\u6b8b\u308b\uff09\nconst float kGummyBleedSpread  = 1.5;  // \u5916\u5468\u3078\u884c\u304f\u307b\u3069\u6bb5\u3092\u4e0a\u3052\u308b\u91cf\uff08\u5916\u5468\u307b\u3069\u307c\u3051\u308b\uff09\nconst float kGummyRootLevel    = 1.0;  // \u6839\u672c\u306e\u5149\u3092\u8aad\u3080\u6bb5\nconst float kGummyUnderLevel   = 2.5;  // \u63b4\u3093\u3067\u3044\u308b\u9593\u3001\u4e0b\u306b\u3042\u308b\u3082\u306e\u306e\u8272\u3092\u8aad\u3080\u6bb5\nconst float kGummyUnderGainMax = 2.0;  // \u4e0b\u306b\u3042\u308b\u3082\u306e\u306e\u8272\u3092\u30b2\u30eb\u306e\u660e\u308b\u3055\u3078\u6301\u3061\u4e0a\u3052\u308b\u500d\u7387\u306e\u4e0a\u9650\n// @@GUMMY_PARAMS_END\n\nfloat gummyHash(vec2 p)\n{\n    p = fract(p * vec2(443.897, 441.423));\n    p += dot(p, p.yx + 19.19);\n    return fract((p.x + p.y) * p.x);\n}\n\n// \u7c92\uff08\u5024\u30ce\u30a4\u30ba\uff09\u3002\u30bb\u30eb\u3054\u3068\u306e\u30cf\u30c3\u30b7\u30e5\u3092\u306a\u3081\u3089\u304b\u306b\u88dc\u9593\u3059\u308b\u3002\nfloat gummyGrainNoise(vec2 p)\n{\n    vec2 i = floor(p);\n    vec2 f = fract(p);\n    f = f * f * (3.0 - 2.0 * f);\n    float a = gummyHash(i);\n    float b = gummyHash(i + vec2(1.0, 0.0));\n    float c = gummyHash(i + vec2(0.0, 1.0));\n    float e = gummyHash(i + vec2(1.0, 1.0));\n    return mix(mix(a, b, f.x), mix(c, e, f.x), f.y);\n}\n\n// \u30b0\u30df\u306e\u65ad\u9762\u3002\u5916\u5468\u304b\u3089\u3075\u3063\u304f\u3089\u76db\u308a\u4e0a\u304c\u308b\u30c9\u30fc\u30e0\u3068\u3001\u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u7e01\u3078\u843d\u3061\u308b\n// \u304f\u307c\u307f\u3092\u639b\u3051\u5408\u308f\u305b\u308b\u3002\n// \u623b\u308a\u5024 x: \u9ad8\u3055\uff080=\u5916\u5468\u301c1=\u9802\u4e0a\uff09 / y: \u50be\u304d\uff08sin\u3002\u6b63=\u5916\u5411\u304d\u306b\u4e0b\u304c\u308b\u3001\u8ca0=\u5185\u5411\u304d\uff09\n// y \u306f\u6a19\u6e96\u306e bend \u3068\u540c\u3058\u5c3a\u5ea6\u306a\u306e\u3067\u3001\u6cd5\u7dda\u8868\u793a\u30fb\u5c48\u6298\u306b\u305d\u306e\u307e\u307e\u4f7f\u3048\u308b\u3002\nvec2 gummyProfile(float d, float dContent, float bez, float sideMask, float innerMix)\n{\n    float height = kGummyPuff * bez;\n    float wO = max(bez * kGummyDome, 1.0);\n    float u = clamp(-d / wO, 0.0, 1.0);\n    float hO = 1.0 - pow(1.0 - u, kGummyDomePow);\n    float sO = kGummyDomePow * pow(1.0 - u, kGummyDomePow - 1.0) * height / wO;\n\n    float wI = max(bez * kGummyWell, 1.0);\n    float v = clamp(dContent / wI, 0.0, 1.0);\n    float wellMask = sideMask * innerMix * step(0.001, kGummyWell);\n    float hI = 1.0 - kGummyWellDepth * (1.0 - v) * (1.0 - v);\n    float sI = 2.0 * kGummyWellDepth * (1.0 - v) * height / wI;\n\n    float h = hO * mix(1.0, hI, wellMask);\n    float s = sO - sI * wellMask;\n    return vec2(h, s / sqrt(1.0 + s * s));\n}\n#endif\n\nvoid glassMain() {\n    // \u89d2\u4e38\u77e9\u5f62\u306eSDF\uff08d<0: \u5185\u5074\u3001d=0: \u7e01\u3001d>0: \u5916\u5074\uff09\n    vec2 rel = vPos - uCenter;\n    vec2 q = abs(rel) - uHalfSize + vec2(uRadius);\n    float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius;\n\n    // ---- 2026-09-22: \u30d0\u30d6\u30eb\u878d\u5408 --------------------------------------------\n    // \u76f8\u624b\u306e\u677f\u3068\u306e\u8ddd\u96e2\u3092 smin \u3067\u5408\u6210\u3057\u3001\u6db2\u4f53\u306e\u3088\u3046\u306b\u9996\u3067\u3064\u306a\u304c\u3063\u305f1\u3064\u306e\n    // \u30ac\u30e9\u30b9\u677f\u3068\u3057\u3066\u6271\u3046\uff08\u3069\u3061\u3089\u304b\u7247\u65b9\u306e draw() \u304c\u5168\u4f53\u30921\u56de\u3067\u63cf\u304f\uff09\u3002\n    // fuseH \u306f\u81ea\u5206\u5074\u306e\u91cd\u307f\uff081=\u81ea\u5206\u3060\u3051\u30010=\u76f8\u624b\u3060\u3051\uff09\u3002\u6cd5\u7dda\u30fb\u30e9\u30a4\u30c8\u30fb\n    // \u30b3\u30f3\u30c6\u30f3\u30c4\u5883\u754c\u306e\u88dc\u9593\u306b\u4f7f\u3046\u3002\n    float fuseH = 1.0;\n    vec2  relOther = vec2(0.0);\n    if (uFuseK > 0.0) {\n        relOther = vPos - uFuseCenter;\n        vec2 qo = abs(relOther) - uFuseHalfSize + vec2(uFuseRadius);\n        float dOther = length(max(qo, 0.0)) + min(max(qo.x, qo.y), 0.0) - uFuseRadius;\n        fuseH = clamp(0.5 + 0.5 * (dOther - d) / uFuseK, 0.0, 1.0);\n        d = mix(dOther, d, fuseH) - uFuseK * fuseH * (1.0 - fuseH);\n    }\n\n    float bez = max(uBezelPx, 4.0);\n#ifdef CARVED_GLASS\n    // 1\u7269\u7406\u30d4\u30af\u30bb\u30eb\u3076\u3093\u306e\u8ad6\u7406px\u3002\u5206\u5c90\u306e\u4e2d\u3067 fwidth \u3092\u53d6\u3089\u306a\u3044\u3088\u3046\u5148\u306b\u6c42\u3081\u308b\u3002\n    float carvePx = max(fwidth(d), 1e-3);\n#endif\n#ifdef GUMMY_GLASS\n    float gumPx = max(fwidth(d), 1e-3);\n#endif\n    // \u901a\u5e38\u30ec\u30a4\u30e4\u30fc\u306f\u30ac\u30e9\u30b9\u9762\u306e\u5185\u5074\u3060\u3051\u3060\u304c\u3001\u5f37\u3044\u30cf\u30a4\u30e9\u30a4\u30c8\u306e\u5c02\u7528\n    // \u30d6\u30eb\u30fc\u30e0\u3060\u3051\u306f\u5916\u3078\u7d041\u30d9\u30bc\u30eb\u3076\u3093\u8a31\u53ef\u3059\u308b\u3002\n    float insideMask = 1.0 - smoothstep(-1.5, 2.0, d);\n    float strongBloomExtent = bez * 0.95;\n    if (insideMask <= 0.0 && d >= strongBloomExtent) {\n        fragColor = vec4(0.0); fragCover = vec4(0.0); return;\n    }\n    float cornerRatio =\n        clamp(uRadius / max(min(uHalfSize.x, uHalfSize.y), 1.0),\n              0.0, 1.0);\n\n    // ---- \u30c7\u30d0\u30c3\u30b0: \u5b9f\u52b9\u30b5\u30fc\u30d5\u30a7\u30b9\u6cd5\u7dda\u306e\u8868\u793a\u30e2\u30fc\u30c9(Shift+D) ----\n    // 2026-07-19: \u30ce\u30a4\u30ba\u6cd5\u7dda\u30de\u30c3\u30d7\u5168\u5ec3\u306b\u4f34\u3044\u3001\u5c48\u6298\u306b\u5b9f\u969b\u306b\u4f7f\u3063\u3066\u3044\u308b\n    // \u300c\u30ec\u30f3\u30ba\u72b6\u306b\u6e7e\u66f2\u3057\u305f\u6210\u5f62\u30ac\u30e9\u30b9\u677f\u300d\u306e\u89e3\u6790\u7684\u306a3D\u6cd5\u7dda\u3092\u53ef\u8996\u5316\u3059\u308b\u3002\n    // RGB=\u6cd5\u7ddaxyz\u3001(0.5,0.5,1.0)\u306e\u7d2b\u304c\u5e73\u5766(\u30ac\u30e9\u30b9\u4e2d\u592e)\u3001\u7e01\u307b\u3069\u50be\u304f\u3002\n    if (uDebugNormal > 0.5 && uDebugNormal < 1.5) {\n        vec2 hsD = max(uHalfSize, vec2(1.0));\n        vec2 kkD = vec2(log(0.5)) / log(clamp((hsD - vec2(uRadius)) / hsD, vec2(0.05), vec2(0.99)));\n        vec2 gD = sign(rel) * pow(clamp(abs(rel) / hsD, 0.0, 1.0), kkD);\n        float gLD = length(gD);\n        vec2 nrmD = gLD > 1e-4 ? gD / gLD : vec2(0.0, -1.0);\n        float normalScaleD = max(uNormalScalePx, 4.0);\n        // \u5c48\u6298\u3068\u540c\u3058\u3001\u30bd\u30d5\u30c8\u30de\u30c3\u30af\u30b9\u5316\u3057\u305f\u6ed1\u3089\u304b\u306a\u8ddd\u96e2+\u30af\u30c3\u30b7\u30e7\u30f3\u5f62\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\n        // (\u7e01\u3067\u6700\u5927\u2192\u4e2d\u592e\u3067\u306a\u3081\u3089\u304b\u306b0\u3002\u5bfe\u89d2\u306e\u5207\u308c\u76ee\u304c\u51fa\u306a\u3044)\n        // \u5c48\u6298\u5074\u3068\u540c\u4e00: \u5206\u5c90\u306a\u3057\u30bd\u30d5\u30c8\u30de\u30c3\u30af\u30b9\u5834+\u6307\u6570\u6e1b\u8870\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb(\u5168\u57dfC\u221e)\n        float smWD = normalScaleD * 0.5;\n        float dSoftD = 0.5 * ((q.x + q.y) + sqrt((q.x - q.y) * (q.x - q.y) + smWD * smWD)) - uRadius;\n        float rr = -dSoftD / normalScaleD;\n        // \u30e9\u30f3\u30c1\u30e3\u30fc\u306f\u92ed\u3044\u5916\u5468\u6210\u5206\u306b\u5f31\u304f\u5e83\u3044\u88fe\u3092\u91cd\u306d\u3001\u6cd5\u7dda\u3092\u307c\u304b\u3057\u305f\n        // \u3088\u3046\u306b\u5f71\u97ff\u7bc4\u56f2\u3092\u5e83\u3052\u308b\u3002\u8ffd\u52a0\u30c6\u30af\u30b9\u30c1\u30e3\u30b5\u30f3\u30d7\u30eb\u306f\u4f7f\u308f\u306a\u3044\u3002\n        float rrPositiveD = max(rr, 0.0);\n        float mediaBendD = exp(-2.6 * rrPositiveD);\n        float launcherBendD =\n            launcherBendProfile(rrPositiveD, cornerRatio);\n        float bendD =\n            mix(mediaBendD, launcherBendD, uSurfaceProfile);\n#ifdef CARVED_GLASS\n        // \u524a\u308a\u51fa\u3057: \u5c48\u6298\u3068\u540c\u3058\u9762\u53d6\u308a\u306e\u65ad\u9762\u3067\u6cd5\u7dda\u3092\u8868\u793a\u3059\u308b\uff08\u4e0b\u306e\u5c48\u6298\u51e6\u7406\u3068\u540c\u3058\u5f0f\uff09\u3002\n        {\n            vec2 contentHalfD = max(uHalfSize - vec2(bez), vec2(2.0));\n            float contentRadiusD = min(uContentRadius, min(contentHalfD.x, contentHalfD.y));\n            vec2 qContentD = abs(rel) - contentHalfD + vec2(contentRadiusD);\n            float dContentD = length(max(qContentD, 0.0))\n                            + min(max(qContentD.x, qContentD.y), 0.0) - contentRadiusD;\n            float sideMaskD = smoothstep(-carvePx, 0.0, dContentD);\n            float bOD, bID, wOD, wID;\n            carveBands(d, dContentD, bez, sideMaskD, carvePx, bOD, bID, wOD, wID);\n            bendD = carveBend(d, bez, carvePx, bOD, bID, sideMaskD, uInnerMix);\n        }\n#endif\n#ifdef GUMMY_GLASS\n        // \u30b0\u30df: \u5c48\u6298\u3068\u540c\u3058\u65ad\u9762\u3067\u6cd5\u7dda\u3092\u8868\u793a\u3059\u308b\n        {\n            vec2 contentHalfD = max(uHalfSize - vec2(bez), vec2(2.0));\n            float contentRadiusD = min(uContentRadius, min(contentHalfD.x, contentHalfD.y));\n            vec2 qContentD = abs(rel) - contentHalfD + vec2(contentRadiusD);\n            float dContentD = length(max(qContentD, 0.0))\n                            + min(max(qContentD.x, qContentD.y), 0.0) - contentRadiusD;\n            float sideMaskD = smoothstep(-gumPx, 0.0, dContentD);\n            bendD = gummyProfile(d, dContentD, bez, sideMaskD, uInnerMix).y;\n        }\n#endif\n        float effectiveBendD =\n            clamp(bendD * uNormalInfluence, -0.999, 0.999);\n        vec3 n3 = vec3(\n            nrmD * effectiveBendD,\n            sqrt(max(0.0, 1.0 - effectiveBendD * effectiveBendD)));\n        // \u6cd5\u7dda\u30de\u30c3\u30d7\u306e\u6163\u4f8b(y\u306f\u4e0a\u5411\u304d\u6b63)\u306b\u5408\u308f\u305bscreen\u5ea7\u6a19\u306ey\u3092\u53cd\u8ee2\u3057\u3066\u8868\u793a\n        vec3 colD = vec3(n3.x, -n3.y, n3.z) * 0.5 + 0.5;\n        fragColor = vec4(colD * insideMask, insideMask);\n        fragCover = vec4(insideMask);\n        return;\n    }\n\n    // ---- \u7e01\u306e\u5916\u5411\u304d\u6cd5\u7dda\uff08\u8d85\u6955\u5186\u8fd1\u4f3c\u30fb\u5168\u5468\u306a\u3081\u3089\u304b\u7248\uff09 ----\n    // 2026-07-19: \u5f53\u521d\u306fSDF\u52fe\u914d\u305d\u306e\u3082\u306e\uff08\u8fba\u9818\u57df=\u8ef8\u65b9\u5411/\u89d2\u9818\u57df=\u653e\u5c04\u65b9\u5411\u306e\n    // if\u5206\u5c90\uff09\u3092\u4f7f\u3063\u3066\u3044\u305f\u304c\u3001\u5206\u5c90\u5883\u754c\uff08\u89d2\u304b\u3089\u5185\u5074\u3078\u4f38\u3073\u308b\u5bfe\u89d2\u7dda\uff1dSDF\u306e\n    // \u4e2d\u8ef8\u7dda\uff09\u3067\u6cd5\u7dda\u304c\u4e0d\u9023\u7d9a\u306b\u306a\u308a\u3001\u30d9\u30bc\u30eb\u304c\u89d2\u4e38\u534a\u5f84\u3088\u308a\u539a\u3044\u672c\u30a2\u30d7\u30ea\u3067\u306f\n    // \u300c\u984d\u7e01\u306e\u7559\u3081\u7d99\u304e\u300d\u306e\u3088\u3046\u306a\u7b4b\u304c\u89d2\u306b\u898b\u3048\u3066\u3057\u307e\u3063\u305f\uff08\u5b9f\u6a5f\u3067\u78ba\u8a8d\uff09\u3002\n    // \u305d\u3053\u3067\u8d85\u6955\u5186 (|x/w|^k + |y/h|^k = 1) \u306e\u6cd5\u7dda\u3067\u8fd1\u4f3c\u3059\u308b: \u8fba\u306e\u4e2d\u592e\u3067\u306f\n    // \u8ef8\u65b9\u5411\u3001\u89d2\u4e38\u30be\u30fc\u30f3\u306b\u5165\u308b\u3068\u306a\u3081\u3089\u304b\u306b\u5bfe\u89d2\u3078\u56de\u8ee2\u3057\u3001\u4e0d\u9023\u7d9a\u304c\u4e00\u5207\u306a\u3044\u3002\n    // \u6307\u6570k\u306f\u300c\u89d2\u4e38\u306e\u59cb\u307e\u308b\u4f4d\u7f6e\u3067\u5bc4\u4e0e\u304c0.5\u306b\u306a\u308b\u300d\u3088\u3046\u8ef8\u3054\u3068\u306b\u81ea\u52d5\u7b97\u51fa\u3002\n    vec2 hs = max(uHalfSize, vec2(1.0));\n    vec2 kk = vec2(log(0.5)) / log(clamp((hs - vec2(uRadius)) / hs, vec2(0.05), vec2(0.99)));\n    vec2 g = sign(rel) * pow(clamp(abs(rel) / hs, 0.0, 1.0), kk);\n    float gLen = length(g);\n    vec2 nrm = gLen > 1e-4 ? g / gLen : vec2(0.0, -1.0);\n\n    vec2 L = vec2(cos(uLightAngle), sin(uLightAngle));\n    // 2026-09-22: \u878d\u5408\u4e2d\u306f\u76f8\u624b\u306e\u5f62\u306e\u6cd5\u7dda\u30fb\u30e9\u30a4\u30c8\u3068\u91cd\u307f fuseH \u3067\u6df7\u305c\u308b\u3002\n    // \u9996\u306e\u90e8\u5206\u3067\u306f2\u3064\u306e\u89d2\u306e\u6cd5\u7dda\u304c\u6df7\u3056\u3063\u3066\u3001\u9996\u306e\u5411\u304d\u306b\u6cbf\u3063\u305f\u6cd5\u7dda\u306b\u306a\u308b\u3002\n    if (uFuseK > 0.0 && fuseH < 0.999) {\n        vec2 hsO = max(uFuseHalfSize, vec2(1.0));\n        vec2 kkO = vec2(log(0.5)) / log(clamp((hsO - vec2(uFuseRadius)) / hsO,\n                                              vec2(0.05), vec2(0.99)));\n        vec2 gO = sign(relOther) * pow(clamp(abs(relOther) / hsO, 0.0, 1.0), kkO);\n        float gLO = length(gO);\n        vec2 nrmO = gLO > 1e-4 ? gO / gLO : nrm;\n        vec2 nm = mix(nrmO, nrm, fuseH);\n        if (length(nm) > 1e-4)\n            nrm = normalize(nm);\n        vec2 LO = vec2(cos(uFuseLightAngle), sin(uFuseLightAngle));\n        vec2 lm = mix(LO, L, fuseH);\n        if (length(lm) > 1e-4)\n            L = normalize(lm);\n    }\n    float facing = dot(nrm, L); // 1: \u5149\u6e90\u3092\u5411\u304f\u7e01 / 0: \u5074\u9762 / -1: \u771f\u88cf\n    float litSharp = pow(clamp(facing, 0.0, 1.0), 20.0);\n    float strongBloomSigma = max(bez * 0.30, 2.5);\n    float strongBloomDistance = max(d, 0.0);\n    float strongOuterBloom =\n        exp(-(strongBloomDistance * strongBloomDistance)\n            / (2.0 * strongBloomSigma * strongBloomSigma))\n        * smoothstep(-1.0, 1.5, d)\n        * litSharp * 0.30;\n\n    // \u5916\u5074\u306f\u5c02\u7528\u30d6\u30eb\u30fc\u30e0\u3060\u3051\u3092\u51fa\u3057\u3001\u30b3\u30f3\u30c6\u30f3\u30c4\u53cd\u5c04\u3084\u5c48\u6298\u306e\u91cd\u3044\u51e6\u7406\u3078\n    // \u9032\u307e\u305b\u306a\u3044\u3002\u30c7\u30d0\u30c3\u30b0\u8868\u793a\u3068\u5c48\u6298\u30d7\u30ea\u30d1\u30b9\u3067\u306f\u5f93\u6765\u3069\u304a\u308a\u5916\u3078\u51fa\u3055\u306a\u3044\u3002\n    if (insideMask <= 0.0) {\n        if (uRefractionPrepass > 0.5 || uDebugNormal > 0.5) {\n            fragColor = vec4(0.0); fragCover = vec4(0.0); return;\n        }\n        float bloomK = uIntensity * strongOuterBloom * uTint.a;\n        fragColor = vec4(vec3(bloomK), bloomK);\n        fragCover = vec4(bloomK);\n        return;\n    }\n\n    // ---- \u6df1\u3055\u65b9\u5411\u306e\u5c64\uff08\u3059\u3079\u3066\u7e01\u304b\u3089\u306e\u8ddd\u96e2d\u306e\u30ac\u30a6\u30b9\uff09 ----\n    // 2026-07-19: \u5f53\u521d\u306f\u592a\u3055\u30fb\u4f4d\u7f6e\u304c\u56fa\u5b9apx\u3060\u3063\u305f\u305f\u3081\u3001\u30ab\u30e1\u30e9\u3092\u5f15\u304f\uff08\u30ba\u30fc\u30e0\n    // \u30a2\u30a6\u30c8\u3059\u308b\uff09\u3068\u30d0\u30d6\u30eb\u306b\u5bfe\u3057\u3066\u76f8\u5bfe\u7684\u306b\u592a\u304f\u898b\u3048\u3001\u30ba\u30fc\u30e0\u5177\u5408\u3067\u30cf\u30a4\u30e9\u30a4\u30c8\u306e\n    // \u5165\u308a\u65b9\u304c\u5909\u308f\u3063\u3066\u3057\u307e\u3063\u305f\uff08\u30e6\u30fc\u30b6\u30fc\u6307\u6458\uff09\u3002\u3059\u3079\u3066\u30d9\u30bc\u30eb\u539auBezelPx\n    // \u57fa\u6e96\u306e\u76f8\u5bfe\u5024\u306b\u5909\u66f4\u3057\u3001\u30ea\u30b5\u30a4\u30ba\u3084\u30ba\u30fc\u30e0\u306b\u4f9d\u5b58\u3057\u306a\u3044\u6bd4\u7387\u306b\u3059\u308b\u3002\n    // \u4fc2\u6570\u306f\u5909\u66f4\u524d\u306e\u6a19\u6e96\u7684\u306a\u898b\u305f\u76ee\n    // \uff08bez\u224826px\u6642: \u30ea\u30e0\u03c32.4/\u306b\u3058\u307f\u03c36.0/\u5185\u5074\u7dda\u03c31.8\uff09\u3068\u4e00\u81f4\u3059\u308b\u3088\u3046\u9006\u7b97\u3002\n    // \u6975\u5c0f\u30d0\u30d6\u30eb\u3067\u30b5\u30d6\u30d4\u30af\u30bb\u30eb\u5316\u3057\u3066\u6d88\u3048\u306a\u3044\u3088\u3046\u6700\u5c0fpx\u3067\u30af\u30e9\u30f3\u30d7\u3002\n    // \u30b3\u30f3\u30c6\u30f3\u30c4\u5883\u754c\u306eSDF\u3002\u5185\u5468\u30cf\u30a4\u30e9\u30a4\u30c8\u30fb\u93e1\u50cf\u30fb\u7247\u5074\u30de\u30b9\u30af\u3067\u5171\u7528\u3057\u3001\n    // \u5404\u30ec\u30a4\u30e4\u30fc\u306e\u6839\u5143\u304c\u540c\u3058\u4f4d\u7f6e\u304b\u3089\u59cb\u307e\u308b\u3088\u3046\u306b\u3059\u308b\u3002\n    vec2 contentHalf = max(uHalfSize - vec2(bez), vec2(2.0));\n    float contentRadius =\n        min(uContentRadius, min(contentHalf.x, contentHalf.y));\n    vec2 qContent = abs(rel) - contentHalf + vec2(contentRadius);\n    float dContent = length(max(qContent, 0.0))\n                   + min(max(qContent.x, qContent.y), 0.0)\n                   - contentRadius;\n    // 2026-09-22: \u878d\u5408\u4e2d\u306f\u76f8\u624b\u306e\u30b3\u30f3\u30c6\u30f3\u30c4\u5883\u754c\u3082\u5185\u5074\u306e\u7dda\u306e\u5bfe\u8c61\u306b\u3059\u308b\n    // \uff082\u679a\u306e\u52d5\u753b\u306f\u305d\u308c\u305e\u308c\u306e\u89d2\u4e38\u306e\u307e\u307e\u3002\u9996\u306e\u90e8\u5206\u306f\u30ac\u30e9\u30b9\u3060\u3051\u306b\u306a\u308b\uff09\u3002\n    if (uFuseK > 0.0) {\n        vec2 contentHalfO = max(uFuseHalfSize - vec2(max(uFuseBezelPx, 4.0)), vec2(2.0));\n        float crO = min(uFuseContentRadius, min(contentHalfO.x, contentHalfO.y));\n        vec2 qcO = abs(relOther) - contentHalfO + vec2(crO);\n        float dcO = length(max(qcO, 0.0)) + min(max(qcO.x, qcO.y), 0.0) - crO;\n        dContent = min(dContent, dcO);\n    }\n    float contentEdgeAa = max(fwidth(dContent), 0.75);\n    float bezelSideMask =\n        smoothstep(-contentEdgeAa, 0.0, dContent);\n\n    // (a) \u5916\u5468\u30ea\u30e0: \u7e01\u3074\u3063\u305f\u308a\u306e\u92ed\u304f\u5f37\u3044\u5149\u306e\u7dda\uff0b\u5468\u56f2\u306e\u67d4\u3089\u304b\u3044\u306b\u3058\u307f\n    // 2026-09-11: \u5149\u91cf(\u30d4\u30fc\u30af\u5024)\u306f\u30ac\u30a6\u30b9\u306e\u6027\u8cea\u4e0asigma\u306b\u4f9d\u5b58\u305b\u305a\u5e38\u306b1.0\u3067\n    // \u5909\u308f\u3089\u306a\u3044\u305f\u3081\u3001\u7dda\u3092\u7d30\u304f\u3057\u305f\u3044\u3068\u3044\u3046\u8981\u671b\u306b\u5bfe\u3057\u3066sigma\u6bd4\u7387\u3060\u3051\u3092\n    // 0.092\u21920.06\u3078\u4e0b\u3052\u305f(\u5149\u306e\u5f37\u3055\u306f\u305d\u306e\u307e\u307e\u3001\u592a\u3055\u3060\u3051\u7d042/3\u306b)\u3002\n    float rimSigma = max(bez * 0.06, 1.0);\n    float rimT = d + rimSigma * 0.75;\n    float rimLine = exp(-(rimT * rimT) / (2.0 * rimSigma * rimSigma));\n    // ---- \u7591\u4f3c\u8272\u53ce\u5dee\uff08chromatic aberration\uff09 ----\n    // \u672c\u7269\u306e\u5206\u6563\uff08\u6ce2\u9577\u3054\u3068\u306e\u5c48\u6298\u7387\u5dee\uff09\u306f\u80cc\u666f\u5c48\u6298\u306a\u3057\u3067\u306f\u518d\u73fe\u3067\u304d\u306a\u3044\u305f\u3081\u3001\n    // \u30ea\u30e0\u306e\u30ac\u30a6\u30b9\u3092\u30c1\u30e3\u30f3\u30cd\u30eb\u3054\u3068\u306b\u6df1\u3055\u65b9\u5411\u3078\u00b1ca\u3060\u3051\u305a\u3089\u3057\u3066\u30b5\u30f3\u30d7\u30eb\u3059\u308b\u3002\n    // \u9752\u306f\u5916\u5074\u3078\u30fb\u8d64\u306f\u5185\u5074\u3078\u5bc4\u308b\u306e\u3067\u3001\u30a8\u30c3\u30b8\u306e\u5916\u5074\u304c\u9752\u7d2b\u3001\u5185\u5074\u304c\u30aa\u30ec\u30f3\u30b8\u306b\n    // \u3046\u3063\u3059\u3089\u8272\u3065\u304f\u3002caMix\u3067\u5f37\u3055\u3092\u8abf\u6574\uff080=\u7121\u52b9\u30011=\u30d5\u30eb\u305a\u3089\u3057\uff09\u3002\n    float ca = clamp(rimSigma * 0.5, 0.5, 2.0);\n    const float caMix = 0.65;\n    float tR = rimT + ca;\n    float tB = rimT - ca;\n    float rimR = exp(-(tR * tR) / (2.0 * rimSigma * rimSigma));\n    float rimB = exp(-(tB * tB) / (2.0 * rimSigma * rimSigma));\n    vec3 rimRGB = mix(vec3(rimLine), vec3(rimR, rimLine, rimB), caMix);\n    float bloomSigma = max(bez * 0.18, 2.5);\n    float bloomT = d + bloomSigma * 0.5;\n    float rimBloom = exp(-(bloomT * bloomT) / (2.0 * bloomSigma * bloomSigma));\n    // (b) \u30d9\u30bc\u30eb\u5185\u90e8\u3092\u6e80\u305f\u3059\u539a\u307f\u306e\u3042\u308b\u30b0\u30ed\u30fc\uff08\u30ac\u30e9\u30b9\u306e\u300c\u539a\u307f\u300d\u306e\u8868\u73fe\uff09\n    float glowT = d + bez * 0.55;\n    float glowSigma = bez * 0.45;\n    float innerGlow = exp(-(glowT * glowT) / (2.0 * glowSigma * glowSigma));\n    // (c) \u5185\u5074\u5883\u754c: \u30b3\u30f3\u30c6\u30f3\u30c4\u3068\u306e\u5b9f\u969b\u306e\u5883\u76ee\u306b\u8d70\u308b\u7d30\u3044\u7dda\u3002\n    // \u30b3\u30f3\u30c6\u30f3\u30c4\u5074\u3078\u6f0f\u3089\u3055\u305a\u3001\u30ac\u30e9\u30b9\u5074\u3060\u3051\u3078\u5e83\u3052\u308b\u3002\n    float lineSigma = max(bez * 0.07, 1.0);\n    float innerLine =\n        exp(-(dContent * dContent) / (2.0 * lineSigma * lineSigma))\n        * bezelSideMask;\n\n    // ---- \u6cd5\u7dda\u30d9\u30fc\u30b9\u306e\u7167\u660e\u9805 ----\n    float litBroad = smoothstep(-0.05, 1.0, facing);      // \u5f31\u3044\u56de\u308a\u8fbc\u307f\u3082\u63a7\u3048\u3081\u306b\n    float counter  = pow(clamp(-facing, 0.0, 1.0), 2.5);  // \u53cd\u5bfe\u5074\u306e\u5f31\u3044\u53cd\u5c04\n\n#ifdef CARVED_GLASS\n    // ---- \u524a\u308a\u51fa\u3057: \u5f37\u3044\u5149\u3092\u30ab\u30af\u3063\u3068\u3055\u305b\u308b\uff082026-09-16\uff09--------------------\n    // \u6a19\u6e96\u306e\u5f37\u3044\u5149\u306f\u300c\u7e01\u304b\u3089\u30ac\u30a6\u30b9\u3067\u306b\u3058\u3080\u7dda\u300d\u3068\u300c\u5149\u6e90\u306e\u5411\u304d\u3078 pow \u3067\n    // \u306a\u3081\u3089\u304b\u306b\u7d5e\u308b\u300d\u306e\u7d44\u307f\u5408\u308f\u305b\u3067\u3001\u306a\u3081\u3089\u304b\u306a\u5f62\u72b6\u5411\u304d\u3002\u524a\u308a\u51fa\u3057\u3067\u306f\u3001\n    //   \u30fb\u6df1\u3055\u65b9\u5411 \u2026 \u5149\u3092\u5916\u5468\u306e\u9762\u53d6\u308a\u306e\u9762\u3044\u3063\u3071\u3044\u306b\u5e73\u3089\u306b\u4e57\u305b\u3001\u6298\u308c\u76ee\u3067\n    //                \u307b\u307c\u6bb5\u5dee\u3067\u5207\u308b\uff08\u8272\u53ce\u5dee\u3082\u6298\u308c\u76ee\u306e\u4f4d\u7f6e\u3092\u305a\u3089\u3057\u3066\u51fa\u3059\uff09\n    //   \u30fb\u5468\u65b9\u5411   \u2026 \u5149\u6e90\u306e\u5411\u304d\u306b\u5bfe\u3057\u3066\u3001\u3042\u308b\u89d2\u5ea6\u3092\u5883\u306b\u30d1\u30c3\u3068\u70b9\u706f\u3059\u308b\n    // \u306b\u3057\u3066\u3001\u9762\u3054\u3068\u306b\u5149\u3092\u62fe\u3063\u3066\u3044\u308b\u898b\u3048\u65b9\u306b\u3059\u308b\u3002\n    // \u8abf\u6574\u306f\u3053\u306e\u5b9a\u6570\u304b\u3089:\n    //   kCarveRimSoft          \u2026 \u5149\u306e\u5e2f\u306e\u6298\u308c\u76ee\u306e\u306a\u3058\u307f\uff08\u9762\u53d6\u308a\u306e\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\n    //   kCarveLitStart / End   \u2026 \u5468\u65b9\u5411\u306e\u70b9\u706f\u306e\u5207\u308a\u66ff\u3048\uff08facing \u306e\u7bc4\u56f2\u30021\u306b\u8fd1\u3044\u307b\u3069\u5149\u6e90\u306e\u6b63\u9762\u3060\u3051\uff09\n    //   kCarveRimDepth         \u2026 \u5149\u306e\u5e2f\u306e\u6df1\u3055\uff08\u5916\u5468\u306e\u9762\u53d6\u308a\u306e\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\n    //\n    // 2026-09-16 \u8abf\u6574: \u524d\u9762\uff08\u30d9\u30bc\u30eb\u306e\u5e73\u3089\u306a\u9762\u306e\u306b\u3058\u307f\u30fb\u539a\u307f\u306e\u30b0\u30ed\u30fc\u30fb\u5185\u5074\u306e\u7dda\uff09\u306f\n    // \u6a19\u6e96\u3068\u540c\u3058\u306b\u623b\u3057\u3001\u30ab\u30af\u3063\u3068\u3055\u305b\u308b\u306e\u306f\u5916\u5468\u306e\u9762\u53d6\u308a\u306e\u5f37\u3044\u5149\u3060\u3051\u306b\u3057\u305f\u3002\n    // \u70b9\u706f\u3059\u308b\u89d2\u5ea6\u306e\u7bc4\u56f2\u3082\u72ed\u3081\uff080.55\u301c0.72 \u2192 0.82\u301c0.95\uff09\u3001\u5149\u6e90\u306e\u6b63\u9762\u306e\u8fba\u306b\u9650\u5b9a\u3002\n    float litSharpRim = litSharp;\n    {\n        const float kCarveRimSoft  = 0.10;\n        // \u3055\u3089\u306b\u8abf\u6574: \u5149\u308b\u7bc4\u56f2\u304c\u5e83\u3044\u3068\u7729\u3057\u3044\u306e\u3067\u3001\u89d2\u5ea6\u3092 0.82\u301c0.95 \u2192 0.90\u301c0.985 \u306b\u3001\n        // \u5149\u306e\u5e2f\u306e\u6df1\u3055\u3092\u9762\u53d6\u308a\u306e\u5e45\u306e 60% \u306b\u7d5e\u3063\u305f\uff08\u9762\u53d6\u308a\u306e\u5916\u5bc4\u308a\u3060\u3051\u304c\u5149\u308b\uff09\u3002\n        const float kCarveLitStart = 0.90;\n        const float kCarveLitEnd   = 0.985;\n        const float kCarveRimDepth = 0.60;\n\n        float wRimO = max(bez * kCarveOuterRatio * kCarveRimDepth, carvePx);\n        float softR = max(wRimO * kCarveRimSoft, carvePx);\n        float caR = clamp(wRimO * 0.12, 0.0, 2.0);\n        float tRim = -d;\n        rimLine = 1.0 - smoothstep(wRimO - 0.5 * softR, wRimO + 0.5 * softR, tRim);\n        rimR = 1.0 - smoothstep(wRimO + caR - 0.5 * softR, wRimO + caR + 0.5 * softR, tRim);\n        rimB = 1.0 - smoothstep(wRimO - caR - 0.5 * softR, wRimO - caR + 0.5 * softR, tRim);\n        rimRGB = mix(vec3(rimLine), vec3(rimR, rimLine, rimB), caMix);\n\n        litSharpRim = smoothstep(kCarveLitStart, kCarveLitEnd, facing);\n    }\n#elif defined(GUMMY_GLASS)\n    // \u30b0\u30df: \u5916\u5468\u306e\u92ed\u3044\u5149\u306e\u7dda\u3092\u592a\u304f\u67d4\u3089\u304b\u304f\u3057\u3001\u5f37\u3055\u3092 kGummyRim \u307e\u3067\u843d\u3068\u3059\u3002\n    // \u70b9\u706f\u3059\u308b\u89d2\u5ea6\u306e\u7d5e\u308a\u3082\u7de9\u3081\uff08pow 20\u21926\uff09\u3001\u8fba\u5168\u4f53\u304c\u307c\u3093\u3084\u308a\u5149\u308b\u3088\u3046\u306b\u3059\u308b\u3002\n    float litSharpRim = pow(clamp(facing, 0.0, 1.0), 6.0);\n    {\n        float rsG = rimSigma * kGummyRimSoft;\n        float rtG = d + rsG * 0.75;\n        float caG = clamp(rsG * 0.5, 0.5, 3.0);\n        rimLine = exp(-(rtG * rtG) / (2.0 * rsG * rsG));\n        rimR = exp(-((rtG + caG) * (rtG + caG)) / (2.0 * rsG * rsG));\n        rimB = exp(-((rtG - caG) * (rtG - caG)) / (2.0 * rsG * rsG));\n        rimRGB = mix(vec3(rimLine), vec3(rimR, rimLine, rimB), caMix) * kGummyRim;\n    }\n#else\n    float litSharpRim = litSharp;\n#endif\n\n    // \u30ea\u30e0\u306b\u306f\u5c0f\u3055\u306a\u5b9a\u6570\u9805\u3092\u8db3\u3057\u3001\u5074\u9762\u3067\u3082\u30ac\u30e9\u30b9\u306e\u5207\u308a\u53e3\u304c\u3046\u3063\u3059\u3089\u5149\u308b\u3088\u3046\u306b\u3059\u308b\u3002\n    // \u30ea\u30e0\u306e\u307f\u8272\u53ce\u5dee\u3067RGB\u5225\u3001\u4ed6\u30ec\u30a4\u30e4\u30fc\u306f\u767d\u306e\u307e\u307e\u30b9\u30ab\u30e9\u30fc\u52a0\u7b97\u3002\n    float rimW  = 1.18 * litSharpRim + 0.20 * litBroad + 0.62 * counter + 0.05;\n    float restW = rimBloom  * (0.48 * litSharp + 0.20 * counter)\n              + (innerGlow * (0.38 * litSharp + 0.08 * counter)\n               + innerLine * (0.48 * litSharp + 0.24 * counter)) * uInnerMix;\n#ifdef GUMMY_GLASS\n    // \u30ac\u30e9\u30b9\u3089\u3057\u3044\u306b\u3058\u307f\u30fb\u539a\u307f\u306e\u30b0\u30ed\u30fc\u30fb\u5185\u5074\u306e\u7dda\u306f\u63a7\u3048\u3081\u306b\u3059\u308b\n    restW *= kGummyGlassLayers;\n#endif\n    vec3 lum = rimRGB * rimW + vec3(restW);\n\n    // ---- \u30ac\u30e9\u30b9\u30b9\u30bf\u30a4\u30eb\u300c\u524a\u308a\u51fa\u3057\u300d\uff082026-09-16\uff09------------------------\n    // CARVED_GLASS \u3092\u5b9a\u7fa9\u3057\u3066\u30b3\u30f3\u30d1\u30a4\u30eb\u3057\u305f\u30b7\u30a7\u30fc\u30c0\u30fc\u3060\u3051\u306b\u5165\u308b\uff08\u6a19\u6e96\u306e\n    // \u30b7\u30a7\u30fc\u30c0\u30fc\u306b\u306f1\u547d\u4ee4\u3082\u5897\u3048\u306a\u3044\u3002GlassHighlightEffect::initShader \u53c2\u7167\uff09\u3002\n    //\n    // \u7dda\u3092\u8db3\u3059\u306e\u3067\u306f\u306a\u304f\u300c\u9762\u53d6\u308a\u306e\u9762\u300d\u3092\u4f5c\u308b\u3002\u677f\u306e\u5916\u5468\u306e\u3059\u3050\u5185\u5074\u3068\u3001\n    // \u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u7e01\u306e\u3059\u3050\u5916\u5074\u306b\u3001\u50be\u3044\u305f\u7d30\u3044\u5e2f\uff08\u9762\u53d6\u308a\uff09\u304c\u3042\u308b\u3068\u307f\u306a\u3057\u3001\n    // \u5e2f\u306e\u5411\u304d\u3068\u5149\u306e\u5411\u304d\u3067\u660e\u6697\u3092\u6c7a\u3081\u308b\u3002\u5e73\u3089\u306a\u30d9\u30bc\u30eb\u3068\u306e\u5883\u76ee\u306f\u307c\u304b\u3055\u305a\n    // \u304f\u3063\u304d\u308a\u5207\u308a\u66ff\u3048\u308b\u306e\u3067\u3001\u300c\u524a\u308a\u51fa\u3057\u305f\u89d2\u300d\u306e\u6bb5\u5dee\u306b\u898b\u3048\u308b\u3002\n    //   \u5916\u5468\u306e\u9762\u53d6\u308a \u2026 \u5916\u3078\u5411\u304b\u3063\u3066\u4e0b\u304c\u308b\u9762\u3002\u5149\u6e90\u5074\u304c\u660e\u308b\u304f\u3001\u53cd\u5bfe\u5074\u304c\u6697\u3044\u3002\n    //   \u5185\u5074\u306e\u9762\u53d6\u308a \u2026 \u30b3\u30f3\u30c6\u30f3\u30c4\u3078\u5411\u304b\u3063\u3066\u843d\u3061\u308b\u9762\u3002\u5411\u304d\u304c\u9006\u306a\u306e\u3067\u660e\u6697\u3082\u9006\u3002\n    // \u660e\u6697\u306e\u5411\u304d\u306f\u65e2\u5b58\u306e\u7e01\u306e\u5149\u3068\u540c\u3058 facing\uff08\u7e01\u306e\u6cd5\u7dda\u00d7\u5149\u306e\u5411\u304d\uff09\u3092\u4f7f\u3046\u306e\u3067\u3001\n    // \u30ab\u30e1\u30e9\u304c\u52d5\u3051\u3070\u4e00\u7dd2\u306b\u56de\u308b\u3002\n    //\n    // \u8abf\u6574\u306f\u3053\u306e\u5b9a\u6570\u304b\u3089:\n    //   kCarveOuterRatio / kCarveInnerRatio \u2026 \u5916\u5468\u30fb\u5185\u5074\u306e\u9762\u53d6\u308a\u306e\u5e45\uff08\u30d9\u30bc\u30eb\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\n    //   kCarveSoft / kCarveEdgeRatio         \u2026 \u6298\u308c\u76ee\u306e\u4e38\u307f\u30fb\u7a1c\u7dda\u306e\u592a\u3055\uff08\u9762\u53d6\u308a\u306e\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\n    //   kCarveHi / kCarveShade      \u2026 \u9762\u53d6\u308a\u306e\u660e\u308b\u3044\u5074\u30fb\u6697\u3044\u5074\u306e\u5f37\u3055\n    //   kCarveEdge                  \u2026 \u9762\u53d6\u308a\u3068\u5e73\u3089\u306a\u9762\u306e\u5883\u76ee\u306b\u4e57\u308b\u7d30\u3044\u5149\n    float carveDark = 0.0;\n    // \u9762\u53d6\u308a\u306e\u5e2f\u306e\u88ab\u8986\u7387\uff08\u53cd\u5c04\u30fb\u900f\u904e\u30fb\u5c48\u6298\u3067\u3082\u4f7f\u3046\u3002\u6a19\u6e96\u3067\u306f0\u306e\u307e\u307e\uff09\n    float carveBandO = 0.0;\n    float carveBandI = 0.0;\n#ifdef CARVED_GLASS\n    {\n        // 2026-09-16 \u6539\u8a02:\n        //  - \u5e45\u30fb\u5883\u76ee\u306e\u306a\u3058\u307f\u30fb\u7a1c\u7dda\u306e\u592a\u3055\u3092\u3001\u3059\u3079\u3066\u30d9\u30bc\u30eb\u5e45\u306b\u6bd4\u4f8b\u3055\u305b\u305f\u3002\n        //    \u4ee5\u524d\u306f px \u306e\u4e0b\u9650/\u4e0a\u9650\u3068\u300c1\u7269\u7406\u30d4\u30af\u30bb\u30eb\u306e\u5883\u76ee\u300d\u3092\u4f7f\u3063\u3066\u3044\u305f\u305f\u3081\u3001\n        //    \u30ab\u30e1\u30e9\u3067\u5bc4\u308b\u3068\u9762\u53d6\u308a\u3060\u3051\u304c\u76f8\u5bfe\u7684\u306b\u7d30\u304f\u30fb\u786c\u304f\u306a\u3063\u3066\u3044\u305f\u3002\n        //    \u30d9\u30bc\u30eb\u5e45\u306f\u30ba\u30fc\u30e0\u306b\u6bd4\u4f8b\u3059\u308b\u306e\u3067\u3001\u3053\u308c\u3067\u5bc4\u3063\u3066\u3082\u5f15\u3044\u3066\u3082\u540c\u3058\u5f62\u306b\u898b\u3048\u308b\u3002\n        //  - \u5883\u76ee\u3092\u5b8c\u5168\u306a\u6bb5\u5dee\u306b\u305b\u305a\u3001\u89d2\u3060\u3051\u308f\u305a\u304b\u306b\u4e38\u3081\u308b\uff08kCarveSoft\uff09\u3002\n        //    \u5168\u4f53\u304c\u307c\u3084\u3051\u308b\u306e\u3067\u306f\u306a\u304f\u3001\u6298\u308c\u76ee\u306e\u524d\u5f8c\u3060\u3051\u304c\u306a\u3058\u3080\u3002\n        //  \uff08\u5e45\u30fb\u4e38\u307f\u306e\u5b9a\u6570\u3068\u5e2f\u306e\u8a08\u7b97\u306f carveBands() \u306b\u79fb\u3057\u305f\uff09\n        const float kCarveEdgeRatio  = 0.10;  // \u7a1c\u7dda\u306e\u5149\u306e\u592a\u3055\uff08\u9762\u53d6\u308a\u306e\u5e45\u306b\u5bfe\u3059\u308b\u5272\u5408\uff09\n        const float kCarveHi         = 0.34;\n        // \u524a\u308a\u51fa\u3057\u306f\u9762\u304c\u306f\u3063\u304d\u308a\u6298\u308c\u3066\u3044\u308b\u306e\u3067\u3001\u306a\u3081\u3089\u304b\u306a\u6a19\u6e96\u3088\u308a\u5f71\u3092\u5f37\u3081\u306b\u3059\u308b\u3002\n        const float kCarveShade      = 0.46;\n        const float kCarveEdge       = 0.26;\n\n        float pxO = carvePx;\n        float pxI = carvePx;\n        float bandO, bandI, wO, wI;\n        carveBands(d, dContent, bez, bezelSideMask, carvePx, bandO, bandI, wO, wI);\n        float tO = -d;                                        // \u5916\u5468\u304b\u3089\u5185\u5074\u3078\u306e\u8ddd\u96e2\n\n        // \u9762\u306e\u5411\u304d\u3068\u5149\u3002\u5916\u5468\u306e\u9762\u53d6\u308a\u306f\u5916\u5411\u304d\uff08facing\uff09\u3001\u5185\u5074\u306f\u5185\u5411\u304d\uff08-facing\uff09\u3002\n        float sO = facing;\n        float sI = -facing;\n        // \u9762\u3054\u3068\u306b\u5149\u3092\u62fe\u3046\u898b\u3048\u65b9\u306b\u3059\u308b\u305f\u3081\u3001\u660e\u6697\u306e\u5207\u308a\u66ff\u3048\u3082\u89d2\u5ea6\u3067\u6025\u306b\u3059\u308b\n        float hiO = smoothstep(0.35, 0.55, sO);\n        float shO = smoothstep(0.35, 0.55, -sO);\n        float hiI = smoothstep(0.35, 0.55, sI);\n        float shI = smoothstep(0.35, 0.55, -sI);\n\n        // \u6298\u308c\u76ee\u306b\u4e57\u308b\u5149\uff08\u592a\u3055\u3082\u9762\u53d6\u308a\u306e\u5e45\u306b\u6bd4\u4f8b\uff09\n        float edgeHalfO = max(wO * kCarveEdgeRatio, 0.5 * pxO);\n        float edgeHalfI = max(wI * kCarveEdgeRatio, 0.5 * pxI);\n        float edgeO = 1.0 - smoothstep(edgeHalfO * 0.5, edgeHalfO + pxO, abs(tO - wO));\n        float edgeI = 1.0 - smoothstep(edgeHalfI * 0.5, edgeHalfI + pxI, abs(dContent - wI));\n\n        lum += vec3(bandO * hiO * kCarveHi\n                  + bandI * hiI * kCarveHi * 0.8 * uInnerMix\n                  + edgeO * kCarveEdge * (0.35 + 0.65 * litBroad)\n                  + edgeI * kCarveEdge * 0.8 * (0.35 + 0.65 * max(counter, litBroad * 0.5))\n                    * uInnerMix);\n        carveDark = bandO * shO * kCarveShade\n                  + bandI * shI * kCarveShade * 0.8 * uInnerMix;\n        carveBandO = bandO * insideMask;\n        carveBandI = bandI;\n    }\n#endif\n#ifdef GUMMY_GLASS\n    // ---- \u30ac\u30e9\u30b9\u30b9\u30bf\u30a4\u30eb\u300c\u30b0\u30df\u300d\uff082026-10-11\uff09--------------------------------\n    // \u539a\u307f\u306e\u3042\u308b\u534a\u900f\u660e\u306e\u30b2\u30eb\u3068\u3057\u3066\u63cf\u304f\u3002\u30ac\u30e9\u30b9\u306e\u300c\u7e01\u306e\u7dda\u300d\u3067\u898b\u305b\u308b\u306e\u3067\u306f\u306a\u304f\u3001\n    //   \u30fb\u65ad\u9762 \u2026 \u5916\u5468\u304b\u3089\u3075\u3063\u304f\u3089\u76db\u308a\u4e0a\u304c\u308b\u30c9\u30fc\u30e0\uff0b\u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u7e01\u3078\u843d\u3061\u308b\u304f\u307c\u307f\n    //   \u30fb\u4f53   \u2026 \u4e73\u767d\u3067\u534a\u900f\u660e\u3002\u539a\u3044\u3068\u3053\u308d\u307b\u3069\u6fc3\u304f\u3001\u7e01\u306f\u5c11\u3057\u900f\u3051\u308b\u3002\u7c92\u3067\u3056\u3089\u3064\u304f\n    //   \u30fb\u5149   \u2026 3D\u306e\u6cd5\u7dda\u3067\u5e83\u304f\u67d4\u3089\u304b\u3044\u62e1\u6563\u3068\u920d\u3044\u3064\u3084\u3002\u5149\u306e\u53cd\u5bfe\u5074\u306e\u7e01\u306b\u3001\n    //            \u30b2\u30eb\u306e\u4e2d\u3092\u901a\u3063\u3066\u304d\u305f\u8272\u4ed8\u304d\u306e\u5149\uff08\u900f\u904e\u5149\uff09\u304c\u305f\u307e\u308b\n    // \u4f53\u306e\u8272\u306f kGummyTint\u3002Quality \u3067\u306f\u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u8272\u3092\u306b\u3058\u307e\u305b\u308b\u3002\n    // \u4f53\uff08gumBody\uff09\u306f\u5408\u6210\u306e\u3068\u304d\u30cf\u30a4\u30e9\u30a4\u30c8\u306e\u4e0b\u306b\u6577\u304f\u3002\n    vec4 gumBody = vec4(0.0);\n    {\n        vec2 prof = gummyProfile(d, dContent, bez, bezelSideMask, uInnerMix);\n        float gH = prof.x;\n        float gBend = prof.y;\n        vec3 n3 = vec3(nrm * gBend, sqrt(max(0.0, 1.0 - gBend * gBend)));\n        vec3 L3 = normalize(vec3(L * cos(kGummyElev), sin(kGummyElev)));\n        float dif = clamp((dot(n3, L3) + kGummyWrap) / (1.0 + kGummyWrap), 0.0, 1.0);\n        vec3 H3 = normalize(L3 + vec3(0.0, 0.0, 1.0));\n        float spec = pow(max(dot(n3, H3), 0.0), kGummySpecPow);\n\n        // \u7c92\u306f\u30d0\u30d6\u30eb\u306e\u5c40\u6240\u5ea7\u6a19\u30fb\u30d9\u30bc\u30eb\u6bd4\u3067\u4f5c\u308b\uff08\u52d5\u304b\u3057\u3066\u3082\u30ba\u30fc\u30e0\u3057\u3066\u3082\u540c\u3058\u898b\u3048\u65b9\uff09\n        float grainSize = max(bez * kGummyGrainScale, gumPx);\n        float grain = gummyGrainNoise(rel / grainSize) * 2.0 - 1.0;\n\n        // \u30b2\u30eb\u306f\u52d5\u753b\u30fb\u753b\u50cf\u3067\u306f\u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u5916\uff08\u30d9\u30bc\u30eb\u5074\uff09\u3060\u3051\u3002\n        // \u30e9\u30f3\u30c1\u30e3\u30fc\uff08innerMix=0\uff09\u306f\u304f\u307c\u307f\u3092\u4f5c\u3089\u305a\u3001\u677f\u5168\u4f53\u30921\u3064\u306e\u30b2\u30eb\u3067\u8986\u3046\u3002\n        // \u30e9\u30f3\u30c1\u30e3\u30fc\u306f\u3053\u306e\u30b2\u30eb\u3092\u30a2\u30a4\u30b3\u30f3\u3088\u308a\u5148\u306b\u63cf\u304f\uff08CanvasWidget \u5074\uff09\u306e\u3067\u3001\n        // \u30a2\u30a4\u30b3\u30f3\u306f\u30b2\u30eb\u306e\u4e0a\u306b\u4e57\u308b\uff08draw() \u3067\u30b0\u30df\u306e\u30e9\u30f3\u30c1\u30e3\u30fc\u306f\u30ea\u30f3\u30b0\u306e\u4e2d\u629c\u304d\u3082\u3084\u3081\u3066\u3044\u308b\uff09\u3002\n        float gel = mix(1.0, bezelSideMask, uInnerMix);\n        vec3 bodyCol = kGummyTint;\n        vec3 rootCol = vec3(0.0);   // \u6839\u672c\uff08\u4e2d\u8eab\u306e\u7e01\uff09\u306b\u5f53\u305f\u308b\u4e2d\u8eab\u306e\u5149\u306e\u8272\n        // \u30b0\u30df: \u4e2d\u8eab\u309264\u00d764\u3078\u7e2e\u3081\u3066\u30df\u30c3\u30d7\u3092\u4f5c\u3063\u305f\u5c0f\u30c6\u30af\u30b9\u30c1\u30e3\n        // \uff08GlassHighlightEffect::updateGummySmall\u300110Hz\uff09\u3092\u8aad\u3080\u3060\u3051\u3002\u7e2e\u3081\u305f\u6642\u70b9\u3067\n        // \u5341\u5206\u307c\u3051\u3066\u3044\u308b\u306e\u3067\u7b4b\u3082\u51fa\u306a\u3044\u3002\u306b\u3058\u307f\u30fb\u6839\u672c\u306e\u5149\u30fb\u5e73\u5747\u8272\u306e3\u56de\u3060\u3051\u3067\u6e08\u3080\n        // \uff08\u5143\u306e\u30b0\u30df\u306f\u6bce\u753b\u7d2022\u56de\uff09\u3002\u5916\u5468\u307b\u3069\u307c\u304b\u3059\u306e\u306f\u30df\u30c3\u30d7\u306e\u6bb5\u3092\u4e0a\u3052\u3066\u8868\u73fe\u3059\u308b\u3002\n        if (uContentReflection > 0.001 && uGummySmallValid > 0.5 && gel > 0.001) {\n            float tG = clamp(max(dContent, 0.0) / bez, 0.0, 1.0);\n            float depthIn = max(dContent, 0.0) + bez * kGummyBleedDepth;\n            vec2 c01 = clamp((rel - nrm * depthIn) / (2.0 * contentHalf) + vec2(0.5), 0.0, 1.0);\n            vec4 sb = textureLod(uGummySmall, c01, kGummyBleedLevel + kGummyBleedSpread * tG);\n            vec4 sr = textureLod(uGummySmall, c01, kGummyRootLevel);\n            vec4 avgG = textureLod(uGummySmall, vec2(0.5), 6.0);   // 1\u00d71 \u306e\u6bb5\uff1d\u5168\u4f53\u306e\u5e73\u5747\n            vec4 sc = mix(sb, avgG, kGummyBleedFar * smoothstep(0.0, 1.0, tG));\n            // 2026-10-11: \u30e9\u30f3\u30c1\u30e3\u30fc\uff08innerMix=0\uff09\u306f\u5834\u6240\u3054\u3068\u306e\u8272\u3092\u62fe\u3046\u3068\u30a2\u30a4\u30b3\u30f3\u306e\n            // \u307c\u3051\u305f\u8907\u88fd\u304c\u30b2\u30eb\u306b\u6d6e\u3044\u3066\u898b\u3048\u305f\u305f\u3081\u3001\u30a2\u30a4\u30b3\u30f3\u5168\u4f53\u306e\u5e73\u5747\u82721\u8272\u3067\u67d3\u3081\u308b\u3002\n            sc = mix(avgG, sc, uInnerMix);\n            vec3 scCol = sc.rgb / max(sc.a, 1e-3);\n            // 2026-10-11: \u306b\u3058\u3080\u8272\u306f\u5c11\u3057\u9bae\u3084\u304b\u306b\u3059\u308b\uff08kGummyBleedSat\u30021=\u5143\u306e\u5f69\u5ea6\uff09\n            float scL = dot(scCol, vec3(0.2126, 0.7152, 0.0722));\n            scCol = clamp(mix(vec3(scL), scCol, kGummyBleedSat), 0.0, 1.0);\n            vec3 bleed = mix(scCol, vec3(1.0), 0.18);\n            float bleedK = mix(kGummyIconBleed, kGummyBleed, uInnerMix);\n            bodyCol = mix(bodyCol, bleed,\n                          bleedK * uContentReflection * smoothstep(0.0, 0.35, sc.a));\n            rootCol = (sr.rgb / max(sr.a, 1e-3)) * smoothstep(0.0, 0.35, sr.a) * uContentReflection;\n            float rootL = dot(rootCol, vec3(0.2126, 0.7152, 0.0722));\n            rootCol = clamp(mix(vec3(rootL), rootCol, kGummyBleedSat), 0.0, 1.0);\n        }\n\n        // \u63b4\u3093\u3067\u3044\u308b\u9593\uff08Quality\u3067\u80cc\u666f\u30ad\u30e3\u30d7\u30c1\u30e3\u304c\u3042\u308b\u3068\u304d\uff09\u306f\u3001\u4e0b\u306b\u3042\u308b\u3082\u306e\n        // \uff08\u4ed6\u306e\u30d0\u30d6\u30eb\u30fb\u30ad\u30e3\u30f3\u30d0\u30b9\uff09\u306e\u8272\u3092\u30b2\u30eb\u3078\u6df7\u305c\u308b\u3002\u5c48\u6298\u50cf\u306f\u898b\u305b\u305a\u3001\u5927\u304d\u304f\n        // \u307c\u304b\u3057\u305f\u8272\u5473\u3060\u3051\u3092\u79fb\u3059\u3002\u660e\u308b\u3055\u306f\u30b2\u30eb\u306e\u307e\u307e\u306b\u3057\u3001\u7070\u8272\uff08\u30ad\u30e3\u30f3\u30d0\u30b9\u7b49\uff09\u306f\u6df7\u305c\u306a\u3044\u3002\n        if (uCaptureTint > 0.001 && gel > 0.001) {\n            // \u30b0\u30df: \u80cc\u666f\u30ad\u30e3\u30d7\u30c1\u30e3\u308264\u00d764\u3078\u7e2e\u3081\u3066\u3042\u308b\u306e\u30671\u56de\u8aad\u3080\u3060\u3051\n            vec2 clU = clamp((gl_FragCoord.xy - uCaptureOrigin)\n                             / max(uCaptureSourceSize, vec2(1.0)), 0.0, 1.0);\n            vec4 su = textureLod(uGummyCaptureSmall, clU, kGummyUnderLevel);\n            vec3 uc = su.rgb / max(su.a, 1e-3);\n            float ucMax = max(uc.r, max(uc.g, uc.b));\n            float ucMin = min(uc.r, min(uc.g, uc.b));\n            float ucSat = (ucMax - ucMin) / max(ucMax, 1e-3);\n            vec3 lumW = vec3(0.2126, 0.7152, 0.0722);\n            // 2026-10-11: \u4ee5\u524d\u306f\u660e\u308b\u3055\u3092\u7121\u5236\u9650\u306b\u30b2\u30eb\u3078\u5408\u308f\u305b\u3066\u3044\u305f\u305f\u3081\u3001\u518d\u751f\u4e2d\u306e\u52d5\u753b\u306e\n            // \u6697\u3044\u90e8\u5206\u304c\u4f55\u500d\u306b\u3082\u6301\u3061\u4e0a\u304c\u3063\u3066\u539f\u8272\u306b\u5316\u3051\u3001\u6bce\u30d5\u30ec\u30fc\u30e0\u3061\u3089\u3064\u3044\u305f\u3002\n            // \u500d\u7387\u306b\u4e0a\u9650\u3092\u3064\u3051\u3001\u6697\u3044\u8272\u307b\u3069\u6df7\u305c\u308b\u91cf\u3082\u6e1b\u3089\u3059\uff08\u7e2e\u5c0f\u5074\u3067\u3082\u6642\u9593\u65b9\u5411\u306b\u306a\u3081\u3089\u304b\u306b\u3057\u3066\u3044\u308b\uff09\u3002\n            float ucL = dot(uc, lumW);\n            float gainU = min(dot(bodyCol, lumW) / max(ucL, 0.05), kGummyUnderGainMax);\n            vec3 ucBright = clamp(uc * gainU, 0.0, 1.0);\n            bodyCol = mix(bodyCol, ucBright,\n                          kGummyUnderTint * uCaptureTint * su.a\n                          * smoothstep(0.02, 0.25, ucSat) * smoothstep(0.03, 0.2, ucL));\n        }\n\n        float milkA = kGummyMilk * mix(kGummyEdgeClear, 1.0, gH);\n        milkA = clamp(milkA * (1.0 + kGummyGrain * grain), 0.0, 1.0) * gel;\n        vec3 milkRgb = bodyCol * mix(mix(kGummyAmbient, 1.0, uAmbientLift), 1.0, dif);   // \u6620\u50cf\u7528: \u9670\u306e\u9762\u3092\u6301\u3061\u4e0a\u3052\u308b\uff08\u672c\u5bb6=0\uff09\n        gumBody = vec4(milkRgb * milkA, milkA);\n\n        // \u3064\u3084: \u7c92\u3067\u307e\u3060\u3089\u306b\u3057\u3066\u3001\u7802\u7cd6\u3092\u307e\u3076\u3057\u305f\u3088\u3046\u306a\u920d\u3044\u5149\u308a\u65b9\u306b\u3059\u308b\n        float sheen = max(spec * kGummySpec * (1.0 + kGummySparkle * grain), 0.0) * gel;\n        // \u900f\u904e\u5149: \u5149\u306e\u53cd\u5bfe\u5074\u306e\u5916\u5468\u4ed8\u8fd1\u3078\u3001\u30b2\u30eb\u3092\u901a\u3063\u3066\u304d\u305f\u8272\u4ed8\u304d\u306e\u5149\u304c\u305f\u307e\u308b\n        float back = smoothstep(0.0, 1.0, -facing);\n        float sssBand = exp(-max(-d, 0.0) / max(bez * kGummySSSWidth, 1.0));\n        float lumaB = dot(bodyCol, vec3(0.2126, 0.7152, 0.0722));\n        vec3 sssCol = clamp(mix(vec3(lumaB), bodyCol, 1.0 + kGummySSSSat), 0.0, 1.0);\n        lum += vec3(sheen) + sssCol * (kGummySSS * back * sssBand * gel);\n        // \u6839\u672c\u306e\u5149: \u4e2d\u8eab\u306e\u7e01\u306e\u3059\u3050\u5916\u5074\u306b\u3001\u4e2d\u8eab\u306e\u5149\u304c\u5f37\u304f\u5f53\u305f\u3063\u3066\u3044\u308b\u5e2f\u3002\n        // \u93e1\u50cf\u3067\u306f\u306a\u304f\u3001\u4e0a\u3067\u307c\u304b\u3057\u305f\u4e2d\u8eab\u306e\u8272\u3092\u305d\u306e\u307e\u307e\u5149\u3068\u3057\u3066\u8db3\u3059\u3002\n        float rootBand = exp(-max(dContent, 0.0) / max(bez * kGummyRootWidth, 1.0))\n                       * bezelSideMask * uInnerMix;\n        lum += rootCol * (kGummyRootGlow * rootBand);\n    }\n#endif\n    vec3 contentReflectionRgb = vec3(0.0);\n    float contentReflectionCoverage = 0.0;\n\n    // ---- \u30b3\u30f3\u30c6\u30f3\u30c4\u7531\u6765\u306e\u8272\u53cd\u5c04\uff08Quality\u306e\u307f\uff09 ----\n    // \u30ac\u30e9\u30b9\u5185\u5468\u3092\u93e1\u9762\u3068\u3057\u3066\u3001\u30d9\u30bc\u30eb\u4e0a\u306e\u70b9\u3092\u5185\u5074\u5883\u754c\u306e\u6cd5\u7dda\u65b9\u5411\u3078\u6298\u308a\u8fd4\u3059\u3002\n    // \u4e0a\u4e0b\u8fba\u306f\u7e26\u53cd\u8ee2\u3001\u5de6\u53f3\u8fba\u306f\u6a2a\u53cd\u8ee2\u3057\u3001\u89d2\u3067\u306f\u4e0a\u3067\u6c42\u3081\u305f\u9023\u7d9a\u6cd5\u7ddanrm\u306b\n    // \u6cbf\u3063\u3066\u653e\u5c04\u72b6\u306b\u56de\u308a\u8fbc\u3080\u30024\u8fba\u3092\u5225\u3005\u306b\u8cbc\u308b\u65b9\u5f0f\u3067\u306f\u306a\u3044\u305f\u3081\u7d99\u304e\u76ee\u304c\u306a\u3044\u3002\n    if (uContentReflection > 0.001) {\n        // \u5185\u5468\u306e\u6025\u306a\u66f2\u9762\u3092\u901a\u308b\u53cd\u5c04\u3068\u3057\u3066\u3001\u6839\u5143\u3067\u306f\u6cd5\u7dda\u65b9\u5411\u306e\u50cf\u3092\u5f37\u304f\u5727\u7e2e\u3057\u3001\n        // \u5916\u5074\u3078\u96e2\u308c\u308b\u307b\u3069\u901a\u5e38\u306e\u5e73\u9762\u93e1\uff08\u7b49\u500d\u306e\u6298\u308a\u8fd4\u3057\uff09\u3078\u623b\u3059\u3002\n        float reflectionDepth = max(dContent, 0.0);\n        // \u5185\u5468\u53cd\u5c04\u3092\u5916\u5074\u304b\u3089\u5358\u7d14\u306b\u5207\u308a\u843d\u3068\u3059\u306e\u3067\u306f\u306a\u304f\u3001\u5883\u754c\u304b\u3089\u306e\n        // \u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u5ea7\u6a19\u305d\u306e\u3082\u306e\u3092\u5c11\u3057\u5727\u7e2e\u3059\u308b\u3002\u53cd\u5c04\u50cf\u306e\u9032\u307f\u65b9\u3001\u6fc3\u5ea6\u3001\n        // \u8272\u62e1\u6563\u304c\u307e\u3068\u3081\u3066\u72ed\u3044\u5e2f\u3078\u53ce\u307e\u308a\u3001\u5143\u306e\u30b0\u30e9\u30c7\u30fc\u30b7\u30e7\u30f3\u3092\u7dad\u6301\u3059\u308b\u3002\n        float reflectionProfileDepth = reflectionDepth * 1.15;\n        float rootDistortion =\n            exp(-reflectionProfileDepth / max(bez * 0.18, 1.0));\n        float reflectedDepth =\n            reflectionProfileDepth * mix(1.0, 4.6, rootDistortion);\n        // p=b+d*n \u304b\u3089\u5883\u754c\u3092\u8d8a\u3048\u3001\u30b3\u30f3\u30c6\u30f3\u30c4\u5074\u306ereflectedDepth\u3078\u5199\u3059\u3002\n        // AA\u753b\u7d20\u3092\u907f\u3051\u308b\u30aa\u30d5\u30bb\u30c3\u30c8\u306f\u30d9\u30bc\u30eb\u6bd4\u7387\u3067\u306f\u306a\u304f1\u301c2px\u306b\u5236\u9650\u3057\u3001\n        // \u5927\u304d\u3044\u30d0\u30d6\u30eb\u3067\u3082\u93e1\u50cf\u306e\u6839\u5143\u304c\u5883\u754c\u304b\u3089\u96e2\u308c\u306a\u3044\u3088\u3046\u306b\u3059\u308b\u3002\n        float boundaryInset =\n            clamp(contentEdgeAa * 1.25, 0.75, 2.0);\n        vec2 reflectedRel =\n            rel - nrm\n                * (reflectionDepth + reflectedDepth + boundaryInset);\n        vec2 content01 =\n            clamp(reflectedRel / (2.0 * contentHalf) + vec2(0.5), 0.0, 1.0);\n        vec2 contentUv =\n            uContentUvRect.xy + content01 * uContentUvRect.zw;\n        // \u5916\u5468\u306e\u900f\u904e\u5149\u306f\u93e1\u50cf\u3067\u306f\u306a\u3044\u3002\u30ac\u30e9\u30b9\u4e0a\u306e\u70b9\u3092\u540c\u3058\u5074\u306e\n        // \u30b3\u30f3\u30c6\u30f3\u30c4\u5883\u754c\u3078\u623b\u3057\u3001\u5c11\u3057\u5185\u5074\u3092\u8aad\u3080\u975e\u53cd\u8ee2UV\u3092\u4f7f\u3046\u3002\n        vec2 transmittedRel =\n            rel - nrm * (reflectionDepth + boundaryInset);\n        vec2 transmitted01 =\n            clamp(transmittedRel / (2.0 * contentHalf) + vec2(0.5), 0.0, 1.0);\n        vec2 transmittedUv =\n            uContentUvRect.xy + transmitted01 * uContentUvRect.zw;\n\n        // \u30b3\u30f3\u30c6\u30f3\u30c4\u8272\u3092\u5e83\u3044\u30b0\u30ed\u30fc\u3078\u6df7\u305c\u306a\u3044\u3002\u93e1\u50cf\u306f\u5185\u5468\u5883\u754c\u3001\u900f\u904e\u8272\u306f\n        // \u5916\u5468\u5883\u754c\u3092\u4e2d\u5fc3\u3068\u3057\u305f\u7d30\u3044\u5e2f\u3060\u3051\u306b\u9650\u5b9a\u3059\u308b\u3002\n        float innerReflectionSigma = max(bez * 0.130, 1.0);\n        float outerTransmissionSigma = max(bez * 0.120, 1.5);\n        // \u53cd\u5c04\u5e2f\u306f\u5185\u5468\u5883\u754c\u306e\u30ac\u30e9\u30b9\u5074\u3060\u3051\u306b\u5b58\u5728\u3055\u305b\u308b\u3002\u4ee5\u524d\u306f\u30ac\u30a6\u30b9\u304c\n        // \u5883\u754c\u306e\u4e21\u5074\u3078\u5e83\u304c\u308a\u3001\u30b3\u30f3\u30c6\u30f3\u30c4\u672c\u4f53\u3078\u53cd\u5c04\u30b5\u30f3\u30d7\u30eb\u304c\u6f0f\u308c\u3066\u3044\u305f\u3002\n        float innerReflectionMask =\n            exp(-(reflectionProfileDepth * reflectionProfileDepth)\n                / (2.0 * innerReflectionSigma * innerReflectionSigma))\n            * bezelSideMask;\n        // \u30b3\u30f3\u30c6\u30f3\u30c4\u306b\u63a5\u3059\u308b\u6839\u5143\u3060\u3051\u306f\u3001\u8fd1\u8ddd\u96e2\u304b\u3089\u5f37\u3044\u5149\u3092\u53d7\u3051\u308b\u7d30\u3044\n        // \u30b3\u30a2\u53cd\u5c04\u3092\u91cd\u306d\u308b\u3002\u5e83\u3044\u53cd\u5c04\u9818\u57df\u3092\u767d\u98db\u3073\u3055\u305b\u305a\u3001\u5883\u754c\u3067\u6700\u5927\u306b\u306a\u308b\u3002\n        float innerReflectionCoreSigma = max(bez * 0.035, 0.75);\n        float innerReflectionCore =\n            exp(-(reflectionProfileDepth * reflectionProfileDepth)\n                / (2.0 * innerReflectionCoreSigma\n                   * innerReflectionCoreSigma))\n            * bezelSideMask;\n        float outerTransmissionMask =\n            exp(-(d * d)\n                / (2.0 * outerTransmissionSigma * outerTransmissionSigma));\n#ifdef CARVED_GLASS\n        // 2026-09-16 \u524a\u308a\u51fa\u3057: \u53cd\u5c04\u3068\u900f\u904e\u3092\u307c\u304b\u3055\u305a\u3001\u9762\u53d6\u308a\u306e\u5e2f\u306e\u4e2d\u3060\u3051\u306b\n        // \u9589\u3058\u8fbc\u3081\u308b\u3002\u93e1\u50cf\u306f\u5185\u5074\u306e\u9762\u53d6\u308a\u3001\u30ac\u30e9\u30b9\u8d8a\u3057\u306e\u8272\u306f\u5916\u5468\u306e\u9762\u53d6\u308a\u306b\u4e57\u308a\u3001\n        // \u5e73\u3089\u306a\u9762\u3068\u306e\u5883\u76ee\u3067\u304f\u3063\u304d\u308a\u5207\u308c\u308b\uff08\u6a19\u6e96\u306f\u5883\u754c\u304b\u3089\u30ac\u30a6\u30b9\u3067\u307c\u308f\u3063\u3068\u6e1b\u8870\uff09\u3002\n        innerReflectionMask = carveBandI;\n        innerReflectionCore = carveBandI * 0.35;\n        outerTransmissionMask = carveBandO;\n#endif\n#ifdef GUMMY_GLASS\n        // \u30b0\u30df: \u93e1\u9762\u7684\u306a\u6620\u308a\u8fbc\u307f\u306f\u6301\u305f\u306a\u3044\u3002\u4e2d\u8eab\u306e\u8272\u306f\u307c\u304b\u3057\u305f\u306b\u3058\u307f\uff08\u4e0a\u306e\u4f53\u306e\u8272\uff09\u3060\u3051\u3067\u51fa\u3059\n        innerReflectionMask = 0.0;\n        innerReflectionCore = 0.0;\n        outerTransmissionMask = 0.0;\n#endif\n        float directW =\n            innerReflectionMask * 0.45 + innerReflectionCore * 0.525;\n        float throughW = outerTransmissionMask * 0.40;\n        // 2026-09-22: \u878d\u5408\u4e2d\u3001\u30b3\u30f3\u30c6\u30f3\u30c4\u8272\u306e\u53cd\u5c04\u306f\u81ea\u5206\u306e\u52d5\u753b\u306e\u5074\u3060\u3051\u306b\u51fa\u3059\n        // \uff08\u76f8\u624b\u306e\u52d5\u753b\u306e\u7e01\u306b\u3001\u81ea\u5206\u306e\u52d5\u753b\u306e\u8272\u304c\u6620\u308a\u8fbc\u307e\u306a\u3044\u3088\u3046\u306b\uff09\u3002\n        if (uFuseK > 0.0) {\n            float selfSide = smoothstep(0.35, 0.65, fuseH);\n            directW *= selfSide;\n            throughW *= selfSide;\n        }\n\n        // \u5e2f\u304b\u3089\u96e2\u308c\u305f\u5927\u90e8\u5206\u306e\u753b\u7d20\u3067\u306f\u30c6\u30af\u30b9\u30c1\u30e3\u3092\u8aad\u307e\u306a\u3044\u3002\u5185\u5468\u306f1\u56de\u3001\n        // \u5916\u5468\u306e\u900f\u904e\u8272\u304c\u898b\u3048\u308b\u5e2f\u3060\u3051\u8ffd\u52a0\u306e4\u56de\u30b5\u30f3\u30d7\u30eb\u3092\u884c\u3046\u3002\n        if (directW + throughW > 0.001) {\n            vec2 uvMin = uContentUvRect.xy;\n            vec2 uvMax = uContentUvRect.xy + uContentUvRect.zw;\n            vec4 directSample = vec4(0.0);\n            vec3 reflectedRgb = vec3(0.0);\n            if (directW > 0.001) {\n                directSample = texture(uContent, contentUv);\n                reflectedRgb = directSample.rgb;\n                // \u30b3\u30f3\u30c6\u30f3\u30c4\u53cd\u5c04\u306b\u3082\u5206\u6563\u3092\u52a0\u3048\u308b\u3002\u6839\u5143\u3092\u6700\u5927\u306b\u3057\u3064\u3064\u3001\n                // \u5bc6\u96c6\u3057\u305f\u5883\u754c\u90e8\u5206\u3060\u3051\u306b\u504f\u3089\u306a\u3044\u3088\u3046\u53cd\u5c04\u5e2f\u306e\u5916\u5074\u306b\u3082\n                // 45%\u4ee5\u4e0a\u3092\u6b8b\u3059\u3002\u6a19\u6e96\u30b5\u30a4\u30ba\u3067\u7d042.5px\u3001\u5de8\u5927\u30d0\u30d6\u30eb\u3067\u306f\n                // 8px\u3092\u4e0a\u9650\u306b\u3059\u308b\u3002\n                float dispersionFalloff =\n                    exp(-reflectionProfileDepth / max(bez * 0.42, 1.0));\n                float dispersionProfile =\n                    mix(0.45, 1.0, dispersionFalloff);\n                float dispersionPx =\n                    clamp(bez * 0.10, 2.0, 8.0) * dispersionProfile;\n                vec2 dispersionUv =\n                    nrm * dispersionPx / (2.0 * contentHalf)\n                    * uContentUvRect.zw;\n                vec4 redSample = texture(\n                    uContent,\n                    clamp(contentUv + dispersionUv, uvMin, uvMax));\n                vec4 blueSample = texture(\n                    uContent,\n                    clamp(contentUv - dispersionUv, uvMin, uvMax));\n                reflectedRgb = vec3(\n                    redSample.r, directSample.g, blueSample.b);\n            }\n            vec3 throughColor = vec3(0.0);\n\n            if (throughW > 0.001) {\n                // \u4e2d\u592e\uff0b\u4e0a\u4e0b\u5de6\u53f3\u306e5\u70b9\u5e73\u5747\u3067\u50cf\u3092\u5d29\u3057\u3001\u30b3\u30f3\u30c6\u30f3\u30c4\u306e\u8272\u3060\u3051\u3092\u6b8b\u3059\u3002\n                vec2 blurStep = uContentUvRect.zw / 18.0;\n                vec4 throughSample = texture(uContent, transmittedUv);\n                vec4 blurredSample =\n                    (throughSample * 2.0\n                     + texture(uContent, clamp(transmittedUv + vec2( blurStep.x, 0.0), uvMin, uvMax))\n                     + texture(uContent, clamp(transmittedUv + vec2(-blurStep.x, 0.0), uvMin, uvMax))\n                     + texture(uContent, clamp(transmittedUv + vec2(0.0,  blurStep.y), uvMin, uvMax))\n                     + texture(uContent, clamp(transmittedUv + vec2(0.0, -blurStep.y), uvMin, uvMax))) / 6.0;\n                throughColor = blurredSample.rgb * blurredSample.a;\n                float throughLuma =\n                    dot(throughColor, vec3(0.2126, 0.7152, 0.0722));\n                // \u30ac\u30e9\u30b9\u3092\u901a\u3063\u305f\u5149\u3068\u3057\u3066\u4f4e\u5f69\u5ea6\u306b\u3059\u308b\u3002\n                throughColor =\n                    mix(vec3(throughLuma), throughColor, 0.62);\n            }\n\n            // \u93e1\u50cf\u306f\u80cc\u5f8c\u306e\u900f\u904e\u6210\u5206\u3092\u53cd\u5c04\u7387\u3076\u3093\u7f6e\u304d\u63db\u3048\u308b\u72ec\u7acb\u30ec\u30a4\u30e4\u30fc\u3002\n            // \u30ac\u30e9\u30b9\u8868\u9762\u306e\u767d\u3044\u30cf\u30a4\u30e9\u30a4\u30c8\u306f\u5225\u306e\u5149\u8def\u306a\u306e\u3067\u6e1b\u8870\u3055\u305b\u305a\u3001\n            // \u6700\u7d42\u5408\u6210\u3067\u3053\u306e\u53cd\u5c04\u50cf\u3088\u308a\u4e0a\u306b\u305d\u306e\u307e\u307e\u6b8b\u3059\u3002\n            float directCoverage =\n                clamp(directW * uContentReflection, 0.0, 1.0)\n                * directSample.a;\n            contentReflectionRgb =\n                reflectedRgb * directCoverage;\n            lum += throughColor * throughW * uContentReflection;\n            contentReflectionCoverage =\n                max(contentReflectionCoverage, directCoverage);\n        }\n    }\n\n    // ---- \u5de6\u53f3\u5074\u9762\uff08facing\u22480\uff09\u306f\u6697\u304f\u6c88\u307e\u305b\u3066\u30b3\u30f3\u30c8\u30e9\u30b9\u30c8\u3092\u4f5c\u308b ----\n    // 2026-07-19: \u300c\u6697\u3044\u3068\u3053\u308d\u3092\u3082\u3063\u3068\u6697\u304f\u300d\u306e\u6307\u793a\u3067\u30b3\u30f3\u30c8\u30e9\u30b9\u30c8\u5897\u5f37\u3002\n    // \u30de\u30b9\u30af\u3092\u5e83\u3052\uff08\u660e\u30fb\u6697\u306e\u7e01\u306e\u8fd1\u304f\u307e\u3067\u6697\u307f\u304c\u53ca\u3076\uff09\u3001\u30a2\u30eb\u30d5\u30a1\u3082\u5f15\u304d\u4e0a\u3052\u3002\n    float darkMask = 1.0 - smoothstep(0.08, 0.75, abs(facing));\n    float rimDark = rimLine * 0.50 * darkMask;\n    float bellyDark = innerGlow * 0.38 * uInnerMix * darkMask;\n#ifdef CARVED_GLASS\n    // \u524a\u308a\u51fa\u3057\u306f\u5074\u9762\u306e\u6c88\u307f\u3082\u5c11\u3057\u5f37\u3081\u308b\uff08\u6a19\u6e96\u306f\u306a\u3081\u3089\u304b\u306a\u5f62\u306a\u306e\u3067\u63a7\u3048\u3081\uff09\u3002\n    rimDark *= 1.35;\n    bellyDark *= 1.35;\n#endif\n#ifdef GUMMY_GLASS\n    // \u30b0\u30df\u306f\u67d4\u3089\u304b\u3044\u5f62\u306a\u306e\u3067\u3001\u5074\u9762\u306e\u6c88\u307f\u306f\u5f31\u304f\u3059\u308b\n    rimDark *= kGummySideDark;\n    bellyDark *= kGummySideDark;\n#endif\n    // \u6620\u50cf\u7528\u306e\u88dc\u6b63: \u6697\u304f\u6c88\u3080\u90e8\u5206\u306e\u6fc3\u3055\uff08\u672c\u5bb6=1\uff09\n    rimDark *= uDarkK; bellyDark *= uDarkK; carveDark *= uDarkK;\n    float aDark = rimDark + bellyDark + carveDark;\n\n    // ---- \u5408\u6210\uff08premultiplied alpha\uff09 ----\n    // \u8272\u53ce\u5dee\u3067RGB\u5225\u306b\u306a\u3063\u305f\u305f\u3081aLight\u306f\u30d9\u30af\u30c8\u30eb\u3002\u30a2\u30eb\u30d5\u30a1\u306b\u306f\u6700\u5927\u6210\u5206\u3092\u4f7f\u3046\n    // \uff08\u5e73\u5747\u3060\u3068\u30d5\u30ea\u30f3\u30b8\u90e8\u5206\u304c\u80cc\u666f\u3092\u524a\u308a\u3059\u304e\u3066\u6fc1\u308b\uff09\u3002\n    // (2026-07-19: \u6cd5\u7dda\u30de\u30c3\u30d7\u306e\u00b18%\u3080\u3089(grain)\u306f\u30ce\u30a4\u30ba\u5168\u5ec3\u306b\u4f34\u3044\u524a\u9664)\n    vec3 aLightRGB = clamp(lum, 0.0, 1.0);\n    float aLight = max(aLightRGB.r, max(aLightRGB.g, aLightRGB.b));\n    // 2026-07-19: \u300c\u5358\u7d14\u306a\u9ed2\u611f\u304c\u3042\u308b\u300d\u3068\u306e\u6307\u6458\u3067\u3001\u6697\u90e8\u306b\u308f\u305a\u304b\u306b\u9752\u307f\u3092\n    // \u8db3\u3057\u305f\uff08\u30ac\u30e9\u30b9\u306e\u5f71\u304c\u74b0\u5883\u5149\u306e\u9752\u3092\u62fe\u3063\u3066\u3044\u308b\u30a4\u30e1\u30fc\u30b8\uff09\u3002\n    vec3 rimDarkColor = vec3(0.04, 0.07, 0.13);\n    vec3 bellyDarkColor = rimDarkColor;\n    // \u30b0\u30df: \u6697\u90e8\u306b\u6df7\u305c\u308b\u753b\u9762\u5e73\u5747\u3082\u3001\u5c0f\u30c6\u30af\u30b9\u30c1\u30e3\u306e1\u00d71\u6bb5\u30921\u56de\u8aad\u3080\u3060\u3051\n    if (uContentReflection > 0.001 && aDark > 0.001 && uGummySmallValid > 0.5) {\n        vec4 avL = textureLod(uGummySmall, vec2(0.5), 6.0);\n        vec3 averageRgb = avL.rgb / max(avL.a, 1e-3);\n        rimDarkColor = mix(rimDarkColor, averageRgb * 0.32, 0.72);\n        bellyDarkColor = mix(bellyDarkColor, averageRgb * 0.40, 0.90);\n    }\n    // \u53cd\u5c04\u50cf\u306f\u900f\u904e\u80cc\u666f\u3088\u308a\u524d\u3001\u89e3\u6790\u7684\u306a\u767d\u30cf\u30a4\u30e9\u30a4\u30c8\u306f\u305d\u306e\u4e0a\u306b\u52a0\u7b97\u3059\u308b\u3002\n    // \u9ed2\u3044\u53cd\u5c04\u3067\u3082coverage\u306f\u6b8b\u308b\u305f\u3081\u80cc\u666f\u3060\u3051\u304c\u6697\u304f\u306a\u308a\u3001\u767d\u30cf\u30a4\u30e9\u30a4\u30c8\u306f\n    // contentReflectionRgb\u306b\u5de6\u53f3\u3055\u308c\u305a\u540c\u3058\u660e\u308b\u3055\u3067\u5b58\u5728\u3057\u7d9a\u3051\u308b\u3002\n    vec3 lightRgb = clamp(\n        aLightRGB + contentReflectionRgb\n        + rimDarkColor * (rimDark + carveDark) + bellyDarkColor * bellyDark,\n        0.0, 1.0);\n    float lightA = clamp(aLight + aDark, 0.0, 1.0);\n#ifdef GUMMY_GLASS\n    // \u30b2\u30eb\u306e\u4f53\u3092\u4e00\u756a\u4e0b\u306b\u6577\u304f\uff08\u53cd\u5c04\u30fb\u30cf\u30a4\u30e9\u30a4\u30c8\u306f\u305d\u306e\u4e0a\u306b\u4e57\u308b\uff09\n    lightRgb = clamp(lightRgb + gumBody.rgb * (1.0 - lightA), 0.0, 1.0);\n    lightA = clamp(lightA + gumBody.a * (1.0 - lightA), 0.0, 1.0);\n#endif\n    lightA += (1.0 - lightA) * contentReflectionCoverage;\n    lightA = max(lightA,\n                 max(lightRgb.r, max(lightRgb.g, lightRgb.b)));\n\n    // ---- \u30ad\u30e3\u30d7\u30c1\u30e3\u7591\u4f3c\u5c48\u6298\uff08\u54c1\u8cea=Quality\u306e\u307f\u3002\u8a2d\u8a08md 4\u7ae0\uff09 ----\n    // \u81eaFBO\u30ad\u30e3\u30d7\u30c1\u30e3\u3092\u7e01\u306e\u6cd5\u7dda\u306b\u6cbf\u3063\u3066\u5185\u5074\u3078\u305a\u3089\u3057\u3066\u30b5\u30f3\u30d7\u30eb\u3057\u3001\n    // \u30e9\u30a4\u30c6\u30a3\u30f3\u30b0\u306e\u4e0b\u6577\u304d\u3068\u3057\u3066\u5408\u6210\u3059\u308b\u3002R/B\u306fuChromatic\u3076\u3093\u8ddd\u96e2\u3092\u5909\u3048\u3066\n    // \u672c\u7269\u306e\u5206\u6563\u306b\u3088\u308b\u8272\u53ce\u5dee\u3092\u51fa\u3059\u3002\u30ad\u30e3\u30d7\u30c1\u30e3\u306e\u900f\u904e\u90e8(alpha=0)\u3067\u306f\n    // \u5c48\u6298\u306e\u5bc4\u4e0e\u304c\u81ea\u52d5\u7684\u306b\u6d88\u3048\u3001\u5f93\u6765\u306e\u30e9\u30a4\u30c6\u30a3\u30f3\u30b0\u306e\u307f\u306b\u843d\u3061\u308b\u3002\n    vec3 outRgb = lightRgb;\n    float outA  = lightA;\n    float cover = lightA; // dst\u3092\u3069\u308c\u3060\u3051\u9000\u304b\u305b\u308b\u304b(dual-source\u306e\u7b2c2\u51fa\u529b)\n    if (uRefractionPrepass > 0.5 && uRefractMix <= 0.001) {\n        fragColor = vec4(0.0);\n        fragCover = vec4(0.0);\n        return;\n    }\n    if (uRefractMix > 0.001) {\n        // 2026-07-19(3): \u300c\u81ea\u30b3\u30f3\u30c6\u30f3\u30c4\u304c\u6620\u308a\u3059\u304e\u300d\u300c\u89d2\u306e\u5185\u5074\u306e\u6e9d\u300d\n        // \u300c\u30ab\u30e1\u30e9\u79fb\u52d5\u3067\u3086\u3089\u3086\u3089\u300d\u306e3\u70b9\u5bfe\u7b56\u3067\u30b5\u30f3\u30d7\u30eb\u65b9\u5411\u3092\u518d\u8a2d\u8a08(\u5b9f\u6a5f\u78ba\u8a8d)\u3002\n        //   - \u539a\u3044\u30ac\u30e9\u30b9\u677f\u306e\u7e01\u306f\u672c\u6765\u300c\u80cc\u666f(\u30d0\u30d6\u30eb\u306e\u5916)\u300d\u3092\u5c48\u6298\u3057\u3066\u898b\u305b\u308b\u3002\n        //     \u5916\u5468\u7aef(rt=0)\u3067\u5916\u50740.6bez \u2192 \u5185\u5074\u5883\u754c(rt=1)\u3067\u5185\u50740.15bez\n        //     (\u81ea\u30b3\u30f3\u30c6\u30f3\u30c4\u304c\u5c11\u3057\u3060\u3051\u6620\u308b)\u3078\u306e\u5358\u8abf\u306a\u7dda\u5f62\u9077\u79fb\u306b\u3059\u308b\u3002\n        //   - \u65e7\u5b9f\u88c5(\u5168\u5e2f\u3067\u5185\u5074\u30b5\u30f3\u30d7\u30eb)\u306f\u89d2\u3067\u5185\u5411\u304d\u5199\u50cf\u304c\u6298\u308a\u7573\u307e\u308c\u3066\n        //     \u300c\u6e9d\u300d\u72b6\u306e\u50cf\u306e\u6298\u308a\u8fd4\u3057\u304c\u51fa\u3066\u3044\u305f\u3002\u5358\u8abf\u9077\u79fb\u306a\u3089\u6298\u308a\u8fd4\u3057\u304c\u7121\u3044\u3002\n        //   - \u62e1\u5927\u7387\u3082\u7d047\u500d\u2192\u7d041.7\u500d\u306b\u4e0b\u304c\u308a\u3001\u30ab\u30e1\u30e9\u79fb\u52d5\u6642\u306e\u30b5\u30d6\u30d4\u30af\u30bb\u30eb\n        //     \u63fa\u308c(\u3086\u3089\u3086\u3089)\u304c\u5927\u5e45\u306b\u6e1b\u308b\u3002\n        //   - \u3055\u3089\u306b\u6cd5\u7dda\u30de\u30c3\u30d7xy\u306e\u300c\u30ac\u30e9\u30b9\u9762\u306e\u3086\u3089\u304e\u300d\u3092\u30d0\u30d6\u30eb\u9762\u5168\u4f53\u306b\n        //     \u8584\u304f\u4e57\u305b\u308b(\u3053\u306e\u305f\u3081Quality\u6642\u306f\u30ea\u30f3\u30b0\u3067\u306f\u306a\u304f\u5168\u9762\u30af\u30ef\u30c3\u30c9\u3067\n        //     \u63cf\u753b\u3059\u308b\u3002draw()\u306e\u30b8\u30aa\u30e1\u30c8\u30ea\u5206\u5c90\u53c2\u7167)\u3002\n        // 2026-07-19(6): SDF\u306emax(q.x,q.y)\u306f\u5bfe\u89d2\u306e\u4e2d\u8ef8\u7dda\u3067\u52fe\u914d\u304c\u4e0d\u9023\u7d9a\n        // (x\u8fba\u652f\u914d\u21d4y\u8fba\u652f\u914d\u306e\u5207\u308a\u66ff\u308f\u308a)\u306a\u305f\u3081\u3001\u3053\u308c\u3092\u8ddd\u96e2\u306b\u4f7f\u3046\u3068\u6cd5\u7dda\u5834\u306b\n        // \u89d2\u304b\u3089\u5bfe\u89d2\u3078\u4f38\u3073\u308b\u5207\u308c\u76ee\u304c\u51fa\u308b(Shift+D\u3067\u78ba\u8a8d)\u3002\u6e7e\u66f2\u91cfbend\u306e\u8a08\u7b97\n        // \u3060\u3051\u3001max\u3092\u30bd\u30d5\u30c8\u30de\u30c3\u30af\u30b9\u3078\u7f6e\u304d\u63db\u3048\u305f\u6ed1\u3089\u304b\u306a\u8ddd\u96e2dSoft\u3092\u4f7f\u3046\n        // (\u7e01\u306e\u30e9\u30a4\u30c6\u30a3\u30f3\u30b0\u5e2f\u306f\u6b63\u78ba\u306ad\u306e\u307e\u307e\u306a\u306e\u3067\u898b\u305f\u76ee\u306e\u4f4d\u7f6e\u306f\u5909\u308f\u3089\u306a\u3044)\u3002\n        // 2026-07-19(7): \u300c\u6e7e\u66f2\u3092\u3088\u308a\u30a8\u30c3\u30b8\u5074\u3078\u5bc4\u305b\u305f\u3044\u300d(\u30e6\u30fc\u30b6\u30fc\u6307\u793a\u3001\n        // \u53c2\u8003\u30a4\u30e1\u30fc\u30b8\u3042\u308a)\u3002\u5e73\u6ed1\u5e452bez\u3060\u3068\u89d2\u306e\u6e7e\u66f2\u304c\u5185\u5074\u3078\u81a8\u3089\u307f\u3059\u304e\u308b\n        // \u305f\u30811bez\u3078\u7e2e\u5c0f\u3002\u6e7e\u66f2\u306e\u5c4a\u304f\u6df1\u3055\u30822.5bez\u21921.3bez\u3078\u7d5e\u308a\u3001\n        // \u4e2d\u592e\u306e\u5e73\u5766\u9818\u57df\u3092\u5927\u304d\u304f\u53d6\u308b\u3002\n        // 2026-07-19(8): min()/length()\u306e\u5206\u5c90\u304c\u6b8b\u3063\u3066\u3044\u308b\u3068\u3001\u30af\u30e9\u30f3\u30d7\u70b9\u306e\n        // \u7b49\u5024\u7dda\u4e0a\u306b\u5fae\u5c0f\u306a\u4e0d\u9023\u7d9a\u306e\u8f2a\u304c\u51fa\u308b(\u30b3\u30f3\u30c8\u30e9\u30b9\u30c8\u3092\u4e0a\u3052\u308b\u3068\u898b\u3048\u308b)\u3002\n        // \u5206\u5c90\u306a\u3057\u306e\u7d14\u7c8b\u306a\u30bd\u30d5\u30c8\u30de\u30c3\u30af\u30b9\u5834 dSoft = smax(q.x,q.y) - r \u306b\u5909\u66f4\u3002\n        // \u5168\u57dfC\u221e\u3067\u3001\u5883\u754c(dSoft=0)\u306f\u6b63\u78ba\u306aSDF\u306e\u7e01\u3068\u307b\u307c\u4e00\u81f4\u3059\u308b\u3002\n        float normalScale = max(uNormalScalePx, 4.0);\n        float smW = normalScale * 0.5;\n        float dSoft = 0.5 * ((q.x + q.y) + sqrt((q.x - q.y) * (q.x - q.y) + smW * smW)) - uRadius;\n        float rtRaw = -dSoft / normalScale; // 0=\u5916\u5468\u7aef\u3001\u5185\u5074\u307b\u3069\u5897\u52a0\n        // 2026-07-19(5): \u300c\u5185\u5074\u5883\u754c\u3067\u5916\u5411\u304d\u2192\u5185\u5411\u304d\u3078\u53cd\u8ee2\u300d\u3059\u308b\u533a\u5206\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\n        // \u306f\u3001\u5883\u754c\u3067\u5fae\u5206\u304c\u4e0d\u9023\u7d9a\u306b\u306a\u308a\u6cd5\u7dda\u5834\u306b\u56db\u89d2\u3044\u88c2\u3051\u76ee(\u7a1c\u7dda)\u304c\u51fa\u3066\u3044\u305f\n        // (Shift+D\u3067\u78ba\u8a8d)\u3002\u65b9\u5411\u53cd\u8ee2\u3092\u5ec3\u6b62\u3057\u3001\u7403\u306e\u6cd5\u7dda\u30de\u30c3\u30d7\u306e\u3088\u3046\u306a\n        // \u300c\u7e01\u3067\u6700\u5927\u2192\u4e2d\u592e\u3078\u306a\u3081\u3089\u304b\u306b0\u300d\u306e\u5358\u4e00\u306e\u30af\u30c3\u30b7\u30e7\u30f3\u5f62\u6e7e\u66f2\u306b\u4e00\u672c\u5316:\n        //   tilt = 0.6bez \u00d7 (1 - smoothstep(0, 2.5, rtRaw))\u3001\u65b9\u5411\u306f\u5e38\u306b\u5916\u5074\u3002\n        // smoothstep\u306f\u4e21\u7aef\u3067\u5fae\u52060\u306a\u306e\u3067\u5168\u57dfC1\u9023\u7d9a=\u7a1c\u7dda\u304c\u51fa\u306a\u3044\u3002\n        // \u7d42\u7aef\u3092\u6301\u305f\u306a\u3044\u6307\u6570\u6e1b\u8870\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb(\u5168\u57dfC\u221e)\u3002\u6709\u9650\u533a\u9593\u306e\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\n        // ((1-t)\u00b2\u7b49)\u306f\u7d42\u7aef\u306e\u9ad8\u6b21\u4e0d\u9023\u7d9a\u304c\u30de\u30c3\u30cf\u30d0\u30f3\u30c9\u3068\u3057\u3066\u77e5\u899a\u3055\u308c\u308b\u305f\u3081\u3001\n        // \u300c\u3069\u3053\u306b\u3082\u5883\u754c\u304c\u7121\u3044\u300d\u56fa\u5b9a\u66f2\u7dda\u306b\u3059\u308b\u3002\u78ba\u5b9a\u30d1\u30e9\u30e1\u30fc\u30bf\u30fc\u306f\n        // \u3053\u306e\u6cd5\u7dda\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u81ea\u4f53\u3092\u5909\u66f4\u305b\u305a\u3001\u7b97\u51fa\u5f8c\u306e\u5909\u4f4d\u3060\u3051\u3078\u9069\u7528\u3059\u308b\u3002\n        // \u30e9\u30f3\u30c1\u30e3\u30fc\u306f\u5c0f\u3055\u306a\u6b63\u65b9\u5f62\u306a\u306e\u3067\u3001\u52d5\u753b\u3068\u540c\u3058\u6e1b\u8870\u3060\u3068\u5c48\u6298\u66f2\u7387\u304c\n        // \u9762\u306e\u4e2d\u592e\u8fd1\u304f\u307e\u3067\u5c4a\u304d\u3059\u304e\u308b\u3002\u5c02\u7528\u30d7\u30ed\u30d5\u30a1\u30a4\u30eb\u3067\u306f\u5916\u5468\u306e\u6700\u5927\u50be\u659c\u3092\n        // \u4fdd\u3063\u305f\u307e\u307e\u4e2d\u592e\u65b9\u5411\u3078\u901f\u304f\u6e1b\u8870\u3055\u305b\u3001\u5916\u5468\u30ea\u30e0\u4e2d\u5fc3\u306e\u898b\u305f\u76ee\u306b\u63c3\u3048\u308b\u3002\n        float rtPositive = max(rtRaw, 0.0);\n        float mediaBend = exp(-2.6 * rtPositive);\n        float launcherBend =\n            launcherBendProfile(rtPositive, cornerRatio);\n        float bend =\n            mix(mediaBend, launcherBend, uSurfaceProfile);\n#ifdef CARVED_GLASS\n        // \u524a\u308a\u51fa\u3057: \u9762\u53d6\u308a\u306e\u65ad\u9762\u304b\u3089\u4f5c\u3063\u305f\u6cd5\u7dda\u3067\u3086\u304c\u307e\u305b\u308b\uff08\u6cd5\u7dda\u8868\u793a\u3068\u540c\u3058\u5f0f\uff09\u3002\n        // \u5916\u5468\u306e\u9762\u53d6\u308a\u306f\u5916\u5411\u304d\u3001\u5185\u5074\u306e\u9762\u53d6\u308a\u306f\u5185\u5411\u304d\u306b\u4e00\u5b9a\u306e\u50be\u304d\u3067\u3001\u5e73\u3089\u306a\n        // \u30d9\u30bc\u30eb\u3068\u30b3\u30f3\u30c6\u30f3\u30c4\u306f\u50be\u304d0\u3002\u4ee5\u964d\u306e\u305a\u308c\u91cf\u306e\u8a08\u7b97\u30fb\u30ad\u30e3\u30d7\u30c1\u30e3\u306e\u8aad\u307f\u65b9\u30fb\n        // \u30d5\u30a7\u30fc\u30c9\u306f\u6a19\u6e96\u3068\u5b8c\u5168\u306b\u540c\u3058\uff08refractionField \u4ee5\u964d\u306f\u5171\u901a\uff09\u3002\n        bend = carveBend(d, bez, carvePx, carveBandO, carveBandI, bezelSideMask, uInnerMix);\n#endif\n        // \u524a\u308a\u51fa\u3057\u3067\u306f\u5185\u5074\u306e\u9762\u53d6\u308a\u304c\u8ca0\u306e\u50be\u304d\u306b\u306a\u308b\u306e\u3067\u3001\u5897\u5e45\u306f\u5927\u304d\u3055\u3067\u639b\u3051\u308b\n        // \uff08\u6a19\u6e96\u306f bend>=0 \u306a\u306e\u3067 abs \u3092\u4ed8\u3051\u3066\u3082\u7d50\u679c\u306f\u5909\u308f\u3089\u306a\u3044\uff09\u3002\n        float edgeGain = 1.0 + uEdgeBoost * abs(bend);\n        // exe/lnk\u3067\u78ba\u5b9a\u3057\u305f\u5411\u304d\u306b\u3001\u52d5\u753b\u30fb\u753b\u50cf\u3082\u7d71\u4e00\u3059\u308b\u3002\n        const float refractionDirection = -1.0;\n        vec2 refractionField =\n            nrm * bend * edgeGain * uNormalInfluence\n            * refractionDirection;\n        // refractionField\u306fscreen\u5ea7\u6a19(y\u4e0b\u5411\u304d)\u3001\u30b5\u30f3\u30d7\u30eb\u4f4d\u7f6e\u306fGL\u5ea7\u6a19\n        // (y\u4e0a\u5411\u304d)\u306a\u306e\u3067y\u3060\u3051\u53cd\u8ee2\u3059\u308b\u3002\n        vec2 ofsPx =\n            vec2(refractionField.x, -refractionField.y)\n            * (normalScale * uRefraction) * uDpr;\n        vec2 base = gl_FragCoord.xy;\n        // \u78ba\u5b9a\u30d6\u30e9\u30fc\u5024\u306f0\u306a\u306e\u3067\u3001\u540c\u4e00\u4f4d\u7f6e\u3060\u3063\u305fG\u306e3\u30bf\u30c3\u30d7\u30921\u56de\u3078\u7d71\u5408\u3002\n        // G/R/B\u306e\u5408\u8a083\u30b5\u30f3\u30d7\u30eb\u3002\u30c6\u30af\u30b9\u30c1\u30e3\u306e\u7dda\u5f62\u88dc\u9593\u304c\u7a4f\u3084\u304b\u306a\n        // \u30ed\u30fc\u30d1\u30b9\u3092\u517c\u306d\u308b\u305f\u3081\u3001\u8ffd\u52a0\u30d6\u30e9\u30fc\u306a\u3057\u3067\u3082\u30b8\u30e3\u30ae\u30fc\u306f\u51fa\u306b\u304f\u3044\u3002\n        vec2 uvG = captureUv(base + ofsPx);\n        vec2 uvR = captureUv(base + ofsPx * (1.0 + uChromatic));\n        vec2 uvB = captureUv(base + ofsPx * (1.0 - uChromatic));\n        vec4 sG = texture(uCapture, uvG);\n        vec4 sR = texture(uCapture, uvR);\n        vec4 sB = texture(uCapture, uvB);\n        vec4 refr = vec4(sR.r, sG.g, sB.b, sG.a);  // premultiplied\n        // \u80cc\u666f\u30d7\u30ea\u30d1\u30b9: item\u3092\u63cf\u304f\u524d\u306edst\u3092\u3001\u5c48\u6298\u30b5\u30f3\u30d7\u30eb\u3067\u30d0\u30d6\u30eb\u5168\u9762\u306b\n        // \u7f6e\u304d\u63db\u3048\u308b\u3002\u4e2d\u592e\u306f\u5909\u4f4d\u304c\u5c0f\u3055\u3051\u308c\u3070\u540c\u4e00\u4f4d\u7f6e\u30b5\u30f3\u30d7\u30eb\u3068\u306a\u308a\u53b3\u5bc6\u306b\n        // \u6052\u7b49\u3068\u306a\u308b\u3002refraction/edgeBoost\u306f\u6cd5\u7dda\u3092\u5909\u3048\u305a\u3001\u7b97\u51fa\u5f8c\u306e\u5909\u4f4d\u91cf\n        // \u3060\u3051\u3092\u8abf\u6574\u3059\u308b\u3002item\u672c\u4f53\u306f\u3053\u306e\u5f8c\u306b\u63cf\u304f\u305f\u3081\u3001\u5168\u9762\u7f6e\u63db\u3057\u3066\u3082\n        // \u30a2\u30a4\u30b3\u30f3\u3084\u52d5\u753b\u3092\u6d88\u3055\u306a\u3044\u3002\n        if (uRefractionPrepass > 0.5) {\n            float passMask = uRefractMix * uIntensity * insideMask * uTint.a;\n            if (uPrepassHoleAmount > 0.0) {\n                // \u76f8\u624b\u306e\u4e2d\u8eab\u306e\u5185\u5074\uff08\u7e01\u304b\u30898px\u3067\u306a\u3081\u3089\u304b\u306b\uff09\u3067\u306f\u5c48\u6298\u3092\u51fa\u3055\u306a\u3044\n                vec2 hd = uPrepassHoleHalf - abs(vPos - uPrepassHoleCenter);\n                float inHole = smoothstep(0.0, 8.0, min(hd.x, hd.y));\n                passMask *= 1.0 - uPrepassHoleAmount * inHole;\n            }\n            if (uDebugNormal > 1.5) {\n                vec3 debugRefr =\n                    refr.rgb + vec3(0.08, 0.11, 0.16) * (1.0 - refr.a);\n                fragColor = vec4(debugRefr * passMask, passMask);\n            } else {\n                fragColor = vec4(refr.rgb * passMask, refr.a * passMask);\n            }\n            fragCover = vec4(passMask);\n            return;\n        }\n    }\n    // \u30c7\u30d0\u30c3\u30b02\u3067\u5c48\u6298\u304c\u7121\u52b9(Medium\u7b49)\u306e\u5834\u5408\u306f\u4f55\u3082\u51fa\u3055\u306a\u3044\n    if (uDebugNormal > 1.5) { fragColor = vec4(0.0); fragCover = vec4(0.0); return; }\n\n    float surfaceK = uIntensity * insideMask * uTint.a;\n    float bloomK = uIntensity * strongOuterBloom * uTint.a;\n    fragColor = vec4(\n        clamp(outRgb * surfaceK + vec3(bloomK), 0.0, 1.0),\n        clamp(outA * surfaceK + bloomK, 0.0, 1.0));\n    fragCover = vec4(clamp(cover * surfaceK + bloomK, 0.0, 1.0));\n}\n\nvoid main() {\n    glassMain();\n    // dual-source blending (ONE, ONE_MINUS_SRC1_ALPHA) \u306e\u518d\u73fe:\n    // rgb=\u52a0\u7b97\u8272\u3001alpha=dst\u3092\u9000\u304b\u305b\u308b\u91cf \u2192 (ONE, ONE_MINUS_SRC_ALPHA) \u3067\u540c\u3058\u5f0f\u306b\u306a\u308b\n    outColor = vec4(fragColor.rgb, fragCover.a);\n}\n";
/* =====================================================================
   バブル描画（WebGL2）— PocketBoard 本体の描画を移植
   - ガラス: GlassHighlightEffect.cpp の GLASS_FRAG をそのまま使用（標準 / CARVED_GLASS / GUMMY_GLASS）
   - 影・枠: Renderer.cpp の GLOW_FRAG と CanvasWidget の描画順・値
   - 品質: Quality 相当（コンテンツ色の反射・グミのにじみ）。屈折プリパスは掴んでいる1個だけの演出なので無し
   ===================================================================== */

const makeGLR = () => {
  let RES = 1, VW = 1, VH = 1;
  const cv = document.createElement('canvas');
  function resize(w, h, r) { VW = w; VH = h; RES = r; cv.width = Math.max(1, Math.round(w * r)); cv.height = Math.max(1, Math.round(h * r)); }
  const gl = cv.getContext('webgl2', {premultipliedAlpha: true, alpha: true, antialias: true, preserveDrawingBuffer: true});
  if (!gl) return null;

  const VERT = `#version 300 es
in vec2 aPos; uniform vec2 uView; out vec2 vPos;
void main(){ vPos = aPos; gl_Position = vec4(aPos.x / uView.x * 2.0 - 1.0, 1.0 - aPos.y / uView.y * 2.0, 0.0, 1.0); }`;
  // 形状: 0=角丸矩形の塗り＋線（Renderer::drawRect）, 1=グロー（GLOW_FRAG）, 2=円, 3=線分（drawLine）
  const SHAPE = `#version 300 es
precision highp float; in vec2 vPos; out vec4 o;
uniform int uMode; uniform vec2 uCenter; uniform vec2 uHalf; uniform float uRadius;
uniform vec4 uFill; uniform vec4 uStroke; uniform float uLw; uniform float uGlowW; uniform vec2 uA; uniform vec2 uB;
float rr(vec2 p){ vec2 q = abs(p - uCenter) - uHalf + vec2(uRadius); return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius; }
void main(){
  if (uMode == 0) {
    float d = rr(vPos); float aa = max(fwidth(d), 0.5);
    float fillA = 1.0 - smoothstep(-aa, aa, d);
    float strokeA = (1.0 - smoothstep(-aa, aa, abs(d + uLw * 0.5) - uLw * 0.5));
    vec4 c = uFill * fillA; c = uStroke * strokeA + c * (1.0 - uStroke.a * strokeA); o = c;
  } else if (uMode == 1) {
    float d = rr(vPos);
    float outer = 1.0 - clamp(d / uGlowW, 0.0, 1.0); outer *= outer;
    float inner = smoothstep(-2.0, 0.0, d);
    float a = uFill.a * outer * inner; o = vec4(uFill.rgb * a, a);
  } else if (uMode == 2) {
    float d = length(vPos - uCenter) - uRadius; float aa = max(fwidth(d), 0.5);
    o = uFill * (1.0 - smoothstep(-aa, aa, d));
  } else {
    vec2 pa = vPos - uA, ba = uB - uA; float h = clamp(dot(pa, ba) / dot(ba, ba), 0.0, 1.0);
    float d = length(pa - ba * h) - uLw * 0.5; float aa = max(fwidth(d), 0.5);
    o = uFill * (1.0 - smoothstep(-aa, aa, d));
  }
}`;
  const TEX = `#version 300 es
precision highp float; in vec2 vPos; out vec4 o;
uniform sampler2D uTex; uniform vec4 uRect; uniform float uRadius; uniform float uAlpha; uniform vec4 uUv;
void main(){
  vec2 c = uRect.xy + uRect.zw * 0.5; vec2 q = abs(vPos - c) - uRect.zw * 0.5 + vec2(uRadius);
  float d = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - uRadius; float aa = max(fwidth(d), 0.5);
  float m = 1.0 - smoothstep(-aa, aa, d);
  vec2 uv = uUv.xy + (vPos - uRect.xy) / uRect.zw * uUv.zw;
  o = texture(uTex, uv) * (m * uAlpha);
}`;
  function compile(type, src) {
    const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) { const log = gl.getShaderInfoLog(s); console.error('shader error', log); throw new Error(log); }
    return s;
  }
  function program(fs) {
    const p = gl.createProgram(); gl.attachShader(p, compile(gl.VERTEX_SHADER, VERT)); gl.attachShader(p, compile(gl.FRAGMENT_SHADER, fs));
    gl.bindAttribLocation(p, 0, 'aPos'); gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p));
    const u = {}; const n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); u[info.name] = gl.getUniformLocation(p, info.name); }
    return {p, u};
  }
  const glassSrc = def => `#version 300 es\n${def ? `#define ${def}\n` : ''}` + GLASS_FRAG_SRC;
  const P = {
    shape: program(SHAPE), tex: program(TEX),

  };
  // ガラスのシェーダーは大きいので、使うスタイルの分だけ必要になった時にコンパイルする
  const GLASS_DEF = {std: '', carved: 'CARVED_GLASS', gummy: 'GUMMY_GLASS'};
  for (const k in GLASS_DEF) { let cache = null; Object.defineProperty(P, k, {get: () => cache || (cache = program(glassSrc(GLASS_DEF[k])))}); }
  const vbo = gl.createBuffer(), vao = gl.createVertexArray();
  gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  gl.bufferData(gl.ARRAY_BUFFER, 8 * 4, gl.DYNAMIC_DRAW);
  gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  const quadBuf = new Float32Array(8);
  function quad(x0, y0, x1, y1) { quadBuf.set([x0, y0, x1, y0, x0, y1, x1, y1]); gl.bufferSubData(gl.ARRAY_BUFFER, 0, quadBuf); gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4); }

  function texFrom(src, {mip = false} = {}) {
    const t = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, t);
    gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    if (mip) { gl.generateMipmap(gl.TEXTURE_2D); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); }
    else gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    return t;
  }
  function texUpdate(t, src, mip = false) {
    gl.bindTexture(gl.TEXTURE_2D, t); gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    if (mip) gl.generateMipmap(gl.TEXTURE_2D);
  }
  const dummy = (() => { const c = document.createElement('canvas'); c.width = c.height = 1; return texFrom(c); })();
  // グミ: 中身を 64×64 に縮めてミップを作った小テクスチャ（GlassHighlightEffect::renderGummySmall 相当）
  const smallCv = document.createElement('canvas'); smallCv.width = smallCv.height = 64;
  const sctx = smallCv.getContext('2d');
  function makeSmall(src, sx, sy, sw, sh, tex) {
    sctx.clearRect(0, 0, 64, 64); sctx.imageSmoothingEnabled = true; sctx.imageSmoothingQuality = 'high';
    sctx.drawImage(src, sx, sy, sw, sh, 0, 0, 64, 64);
    if (tex) { texUpdate(tex, smallCv, true); return tex; }
    return texFrom(smallCv, {mip: true});
  }

  const view = () => { gl.viewport(0, 0, cv.width, cv.height); };
  function begin() {
    view(); gl.clearColor(0, 0, 0, 0); gl.clear(gl.COLOR_BUFFER_BIT);
    gl.enable(gl.BLEND); gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA);
    gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
  }
  const pm = (r, g, b, a) => [r / 255 * a / 255, g / 255 * a / 255, b / 255 * a / 255, a / 255];
  function useShape() { gl.useProgram(P.shape.p); gl.uniform2f(P.shape.u.uView, VW, VH); return P.shape.u; }
  function rect(x, y, w, h, radius, fill, stroke, lw) {
    const u = useShape(); gl.uniform1i(u.uMode, 0);
    gl.uniform2f(u.uCenter, x + w / 2, y + h / 2); gl.uniform2f(u.uHalf, w / 2, h / 2); gl.uniform1f(u.uRadius, Math.min(radius, w / 2, h / 2));
    gl.uniform4fv(u.uFill, fill); gl.uniform4fv(u.uStroke, stroke); gl.uniform1f(u.uLw, lw);
    quad(x - 2, y - 2, x + w + 2, y + h + 2);
  }
  function glow(x, y, w, h, radius, color, gw) {
    if (color[3] <= 0 || gw <= 0) return;
    const u = useShape(); gl.uniform1i(u.uMode, 1);
    gl.uniform2f(u.uCenter, x + w / 2, y + h / 2); gl.uniform2f(u.uHalf, w / 2, h / 2); gl.uniform1f(u.uRadius, Math.min(radius, w / 2, h / 2));
    gl.uniform4fv(u.uFill, color); gl.uniform1f(u.uGlowW, gw);
    quad(x - gw, y - gw, x + w + gw, y + h + gw);
  }
  function circle(cx, cy, r, fill) {
    const u = useShape(); gl.uniform1i(u.uMode, 2); gl.uniform2f(u.uCenter, cx, cy); gl.uniform1f(u.uRadius, r); gl.uniform4fv(u.uFill, fill);
    quad(cx - r - 2, cy - r - 2, cx + r + 2, cy + r + 2);
  }
  function line(ax, ay, bx, by, w, fill) {
    const u = useShape(); gl.uniform1i(u.uMode, 3); gl.uniform2f(u.uA, ax, ay); gl.uniform2f(u.uB, bx, by); gl.uniform1f(u.uLw, w); gl.uniform4fv(u.uFill, fill);
    quad(Math.min(ax, bx) - w - 2, Math.min(ay, by) - w - 2, Math.max(ax, bx) + w + 2, Math.max(ay, by) + w + 2);
  }
  function image(tex, x, y, w, h, radius = 0, alpha = 1, uv = [0, 0, 1, 1]) {
    const u = P.tex.u; gl.useProgram(P.tex.p); gl.uniform2f(u.uView, VW, VH);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, tex); gl.uniform1i(u.uTex, 0);
    gl.uniform4f(u.uRect, x, y, w, h); gl.uniform1f(u.uRadius, Math.min(radius, w / 2, h / 2)); gl.uniform1f(u.uAlpha, alpha); gl.uniform4fv(u.uUv, uv);
    quad(x - 1, y - 1, x + w + 1, y + h + 1);
  }
  function multiply(on) { if (on) gl.blendFunc(gl.DST_COLOR, gl.ONE_MINUS_SRC_ALPHA); else gl.blendFunc(gl.ONE, gl.ONE_MINUS_SRC_ALPHA); }

  // GlassHighlightEffect::draw 相当
  function glass(style, o) {
    const pr = P[style === 'standard' ? 'std' : style], u = pr.u; gl.useProgram(pr.p); gl.uniform2f(u.uView, VW, VH);
    const set1 = (n, v) => { if (u[n]) gl.uniform1f(u[n], v); };
    const set2 = (n, a, b) => { if (u[n]) gl.uniform2f(u[n], a, b); };
    const [bx, by, bw, bh] = o.board;
    const hw = bw / 2, hh = bh / 2;
    set2('uCenter', bx + hw, by + hh); set2('uHalfSize', hw, hh);
    set1('uRadius', Math.min(Math.max(0, o.radius), hw, hh));
    set1('uBezelPx', Math.max(4, o.bezel)); set1('uContentRadius', Math.max(0, o.contentRadius));
    set1('uNormalScalePx', Math.max(4, o.bezel)); set1('uLightAngle', o.lightAngle); set1('uIntensity', o.intensity);
    set1('uInnerMix', o.innerMix);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, dummy);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, o.content || dummy);
    gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, o.small || dummy);
    gl.activeTexture(gl.TEXTURE4); gl.bindTexture(gl.TEXTURE_2D, dummy);
    if (u.uCapture) gl.uniform1i(u.uCapture, 1);
    if (u.uContent) gl.uniform1i(u.uContent, 2);
    if (u.uGummySmall) gl.uniform1i(u.uGummySmall, 3);
    if (u.uGummyCaptureSmall) gl.uniform1i(u.uGummyCaptureSmall, 4);
    if (u.uContentUvRect) gl.uniform4fv(u.uContentUvRect, o.uv || [0, 0, 1, 1]);
    set1('uContentReflection', o.content ? 1 : 0);
    set2('uCaptureTextureSize', 1, 1); set2('uCaptureOrigin', 0, 0); set2('uCaptureSourceSize', 1, 1); set2('uCaptureDataSize', 1, 1);
    set1('uDpr', RES); set1('uRefractMix', 0); set1('uRefraction', 0); set1('uEdgeBoost', 0); set1('uChromatic', .15);
    set1('uRefractionPrepass', 0); set1('uDebugNormal', 0);
    set1('uSurfaceProfile', o.launcher ? 1 : 0); set1('uNormalInfluence', o.launcher ? 2.2 : 1);
    if (u.uTint) gl.uniform4f(u.uTint, 1, 1, 1, 1);
    set1('uCaptureTint', 0); set1('uGummySmallValid', o.small ? 1 : 0);
    set1('uFuseK', 0); set1('uPrepassHoleAmount', 0);
    set1('uDarkK', typeof GLASS_DARK_K === 'number' ? GLASS_DARK_K : 1); set1('uAmbientLift', typeof GUMMY_AMBIENT_LIFT === 'number' ? GUMMY_AMBIENT_LIFT : 0);
    const pad = Math.max(2, o.bezel * .95);
    quad(bx - pad, by - pad, bx + bw + pad, by + bh + pad);
    gl.activeTexture(gl.TEXTURE0);
  }
  return {cv, gl, resize, begin, rect, glow, circle, line, image, glass, multiply, texFrom, texUpdate, makeSmall, pm};
};

let uid = 0;
const ART = {
  img1: () => { const i = ++uid; return `<svg viewBox="0 0 320 240" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="s${i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a1a52"/><stop offset=".55" stop-color="#e0557c"/><stop offset="1" stop-color="#ffb46a"/></linearGradient></defs><rect width="320" height="240" fill="url(#s${i})"/><circle cx="205" cy="150" r="40" fill="#ffe2a0"/><path d="M0 172 L58 122 L112 160 L172 104 L238 166 L290 128 L320 148 V240 H0Z" fill="#3b1c4a"/><path d="M0 204 L84 166 L150 196 L224 170 L320 202 V240 H0Z" fill="#1c0f2e"/></svg>`; },
  img2: () => { const i = ++uid; return `<svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="bg${i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0e2b35"/><stop offset="1" stop-color="#174b52"/></linearGradient><radialGradient id="a${i}" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#c6fff3"/><stop offset=".45" stop-color="#2fb9a6"/><stop offset="1" stop-color="#0b3a44"/></radialGradient><radialGradient id="b${i}" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#ffe0ef"/><stop offset=".5" stop-color="#f06fa8"/><stop offset="1" stop-color="#5a1840"/></radialGradient><radialGradient id="c${i}" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#fff6cf"/><stop offset=".5" stop-color="#ffc94d"/><stop offset="1" stop-color="#6b4a08"/></radialGradient></defs><rect width="400" height="300" fill="url(#bg${i})"/><ellipse cx="150" cy="262" rx="90" ry="12" fill="#06191e" opacity=".6"/><ellipse cx="288" cy="168" rx="46" ry="7" fill="#06191e" opacity=".5"/><circle cx="150" cy="165" r="95" fill="url(#a${i})"/><circle cx="288" cy="110" r="55" fill="url(#b${i})"/><circle cx="305" cy="232" r="34" fill="url(#c${i})"/></svg>`; },
  thumbA: () => { const i = ++uid; return `<svg viewBox="0 0 200 150" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="t${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd3a5"/><stop offset="1" stop-color="#fd6585"/></linearGradient></defs><rect width="200" height="150" fill="url(#t${i})"/><rect x="40" y="40" width="70" height="70" rx="14" fill="#fff" opacity=".55" transform="rotate(-12 75 75)"/><circle cx="140" cy="88" r="30" fill="#fff" opacity=".35"/></svg>`; },
  thumbB: () => { const i = ++uid; return `<svg viewBox="0 0 200 150" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="t${i}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0f2027"/><stop offset="1" stop-color="#2c5364"/></linearGradient></defs><rect width="200" height="150" fill="url(#t${i})"/><path d="M0 110 L50 70 L90 100 L140 55 L200 105 V150 H0Z" fill="#0a161b"/><circle cx="150" cy="38" r="12" fill="#e9f2ff"/></svg>`; },
};
const ICON = {
  folder: () => `<svg viewBox="0 0 64 64"><path d="M6 16a5 5 0 0 1 5-5h14l6 6h22a5 5 0 0 1 5 5v4H6z" fill="#e8a21f"/><path d="M6 24h52v25a5 5 0 0 1-5 5H11a5 5 0 0 1-5-5z" fill="#ffcf4f"/><path d="M6 24h52v4H6z" fill="#ffe08a"/></svg>`,
  exe: () => `<svg viewBox="0 0 64 64"><path d="M32 6 56 19 32 32 8 19z" fill="#8ab4ff"/><path d="M32 32v26L8 45V19z" fill="#2d58ad"/><path d="M32 32 56 19v26L32 58z" fill="#4b82e6"/></svg>`,
  notes: () => `<svg viewBox="0 0 64 64"><rect x="6" y="6" width="52" height="52" rx="14" fill="#2f9e74"/><path d="M22 17h15l9 9v20a2 2 0 0 1-2 2H22a2 2 0 0 1-2-2V19a2 2 0 0 1 2-2z" fill="#fff"/><path d="M26 32h14M26 38h10" stroke="#2f9e74" stroke-width="3" stroke-linecap="round"/></svg>`,
  lumen: () => { const i = ++uid; return `<svg viewBox="0 0 64 64"><defs><linearGradient id="l${i}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8b5cf6"/><stop offset="1" stop-color="#22d3ee"/></linearGradient></defs><rect x="6" y="6" width="52" height="52" rx="14" fill="url(#l${i})"/><circle cx="32" cy="32" r="10" fill="#fff"/><circle cx="32" cy="32" r="17" fill="none" stroke="#fff" stroke-opacity=".55" stroke-width="3"/></svg>`; },
  image: () => `<svg viewBox="0 0 48 48"><rect x="4" y="8" width="40" height="32" rx="6" fill="#ff8aa6"/><circle cx="17" cy="19" r="4" fill="#fff"/><path d="M8 36l11-11 7 7 5-5 9 9z" fill="#fff"/></svg>`,
  film: () => `<svg viewBox="0 0 48 48"><rect x="4" y="9" width="40" height="30" rx="6" fill="#9d7cf0"/><path d="M20 17v14l12-7z" fill="#fff"/></svg>`,
  globe: () => `<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="18" fill="#3fbf8f"/><path d="M6 24h36M24 6c6 6 6 30 0 36M24 6c-6 6-6 30 0 36" stroke="#fff" stroke-width="2.5" fill="none"/></svg>`,
  lock: () => `<svg viewBox="0 0 24 24"><rect x="5" y="10" width="14" height="10" rx="2" fill="#a9adb6"/><path d="M8 10V8a4 4 0 0 1 8 0v2" stroke="#a9adb6" stroke-width="2" fill="none"/></svg>`,
  file: () => `<svg viewBox="0 0 64 64"><path d="M16 6h22l12 12v38a2 2 0 0 1-2 2H16a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z" fill="#d7dbe4"/><path d="M38 6v12h12z" fill="#aab0bd"/></svg>`,
  png: () => `<svg viewBox="0 0 64 64"><path d="M16 6h22l12 12v38a2 2 0 0 1-2 2H16a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2z" fill="#f3a4b8"/><path d="M38 6v12h12z" fill="#d97890"/><path d="M20 48l9-9 6 6 4-4 7 7z" fill="#fff"/></svg>`,
};


const rand = i => { const s = Math.sin(i * 12.9898 + 78.233) * 43758.5453; return s - Math.floor(s); };
function paintVid1(c, tt) {
  // 明るい南国の海（青〜エメラルド）。雲が流れ、波が寄せ、水面がきらめく
  const x = c.getContext('2d'), w = c.width, h = c.height, hy = h * .5;
  const sky = x.createLinearGradient(0, 0, 0, hy);
  sky.addColorStop(0, '#3fa9f5'); sky.addColorStop(.75, '#9fdcff'); sky.addColorStop(1, '#d9f4ff');
  x.fillStyle = sky; x.fillRect(0, 0, w, hy);
  // 太陽の光
  const sx0 = w * .74, sy0 = h * .16;
  const sun = x.createRadialGradient(sx0, sy0, 0, sx0, sy0, h * .55);
  sun.addColorStop(0, 'rgba(255,255,240,.95)'); sun.addColorStop(.12, 'rgba(255,253,225,.6)'); sun.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = sun; x.fillRect(0, 0, w, hy);
  // 雲
  const cloud = (cx, cy, s) => { x.fillStyle = 'rgba(255,255,255,.92)'; x.beginPath();
    x.ellipse(cx, cy, s * 1.6, s * .55, 0, 0, Math.PI * 2); x.ellipse(cx - s * .7, cy + s * .05, s * .8, s * .45, 0, 0, Math.PI * 2);
    x.ellipse(cx + s * .2, cy - s * .35, s * .75, s * .55, 0, 0, Math.PI * 2); x.ellipse(cx + s * .95, cy + s * .05, s * .7, s * .4, 0, 0, Math.PI * 2); x.fill(); };
  for (let i = 0; i < 4; i++) { const s = h * (.05 + rand(i + 20) * .04); const px = ((rand(i + 30) * 1.4 + tt * .018 * (1 + i * .3)) % 1.4 - .2) * w;
    cloud(px, h * (.1 + rand(i + 40) * .22), s); }
  // 遠くの島
  x.fillStyle = '#2f9e7a'; x.beginPath(); x.moveTo(w * .08, hy); x.quadraticCurveTo(w * .2, hy - h * .09, w * .34, hy); x.fill();
  x.fillStyle = '#4cbf8f'; x.beginPath(); x.moveTo(w * .18, hy); x.quadraticCurveTo(w * .26, hy - h * .05, w * .38, hy); x.fill();
  // 海
  const sea = x.createLinearGradient(0, hy, 0, h);
  sea.addColorStop(0, '#1fb8d6'); sea.addColorStop(.45, '#13c2b0'); sea.addColorStop(1, '#5fe3c4');
  x.fillStyle = sea; x.fillRect(0, hy, w, h - hy);
  // 波の線（奥ほど細かく）
  x.lineCap = 'round';
  for (let k = 0; k < 14; k++) {
    const z = ((k + tt * .9) % 14) / 14, yy = hy + (h - hy) * z * z;
    x.strokeStyle = `rgba(255,255,255,${(.18 + z * .45).toFixed(3)})`; x.lineWidth = Math.max(1, w / 900 + z * w / 260);
    x.beginPath();
    for (let xx = 0; xx <= w; xx += w / 60) { const yv = yy + Math.sin(xx / w * (18 - z * 12) + tt * 1.6 + k) * h * .008 * (1 + z * 3); xx === 0 ? x.moveTo(xx, yv) : x.lineTo(xx, yv); }
    x.stroke();
  }
  // 水面のきらめき（太陽の下）
  for (let i = 0; i < 60; i++) {
    const px = sx0 + (rand(i) - .5) * w * .35 * (.4 + rand(i + 5)), py = hy + rand(i + 9) * (h - hy) * .55;
    const a = Math.pow(Math.max(0, Math.sin(tt * (3 + rand(i + 3) * 4) + i)), 6);
    if (a > .02) { x.fillStyle = `rgba(255,255,255,${(a * .9).toFixed(3)})`; x.fillRect(px, py, w / 140, w / 700 + 1); }
  }
  // 手前の砂浜
  const sand = x.createLinearGradient(0, h * .86, 0, h);
  sand.addColorStop(0, '#fff3cf'); sand.addColorStop(1, '#ffe2a3');
  x.fillStyle = sand; x.beginPath(); x.moveTo(0, h);
  for (let xx = 0; xx <= w; xx += w / 40) x.lineTo(xx, h * .9 + Math.sin(xx / w * 5 + tt * .8) * h * .012 + (xx / w) * h * .03);
  x.lineTo(w, h); x.closePath(); x.fill();
  x.strokeStyle = 'rgba(255,255,255,.85)'; x.lineWidth = Math.max(1.5, w / 300); x.beginPath();
  for (let xx = 0; xx <= w; xx += w / 40) { const yv = h * .9 + Math.sin(xx / w * 5 + tt * .8) * h * .012 + (xx / w) * h * .03; xx === 0 ? x.moveTo(xx, yv) : x.lineTo(xx, yv); }
  x.stroke();
}
function paintVid2(c, tt) {
  const x = c.getContext('2d'), w = c.width, h = c.height;
  const g = x.createRadialGradient(w * .5, h * .5, 0, w * .5, h * .5, w * .7);
  g.addColorStop(0, '#16224a'); g.addColorStop(1, '#070a18');
  x.globalCompositeOperation = 'source-over'; x.fillStyle = g; x.fillRect(0, 0, w, h);
  x.globalCompositeOperation = 'lighter';
  const cols = [[80, 220, 255], [255, 90, 190], [255, 210, 90]];
  for (let k = 0; k < 3; k++) {
    const px = w * .5 + Math.cos(tt * .9 + k * 2.1) * w * .26, py = h * .5 + Math.sin(tt * 1.2 + k * 1.7) * h * .26, rr = h * .42;
    const og = x.createRadialGradient(px, py, 0, px, py, rr);
    const [r, gg, b] = cols[k];
    og.addColorStop(0, `rgba(${r},${gg},${b},.95)`); og.addColorStop(.35, `rgba(${r},${gg},${b},.35)`); og.addColorStop(1, `rgba(${r},${gg},${b},0)`);
    x.fillStyle = og; x.fillRect(0, 0, w, h);
  }
  x.globalCompositeOperation = 'source-over';
}

const ISLAND_ACCENT = '#0067C0';   // アプリのアクセント色（Windowsのアクセント or 設定値）
const UI_K = 1.5;                  // 論理px → 映像px
function hexRgb(h){const n=parseInt(h.slice(1),16);return [(n>>16)&255,(n>>8)&255,n&255];}
function rgb2hsv([r,g,b]){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;
  if(d){h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360;}return [h,mx?d/mx:0,mx];}
function hsv2rgb(h,s,v){const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;
  if(h<60)[r,g,b]=[c,x,0];else if(h<120)[r,g,b]=[x,c,0];else if(h<180)[r,g,b]=[0,c,x];else if(h<240)[r,g,b]=[0,x,c];else if(h<300)[r,g,b]=[x,0,c];else[r,g,b]=[c,0,x];
  return [Math.round((r+m)*255),Math.round((g+m)*255),Math.round((b+m)*255)];}
const rgba=(c,a)=>`rgba(${c[0]},${c[1]},${c[2]},${(a/255).toFixed(4)})`;
const W8=a=>rgba([255,255,255],a);
function shadeOf(hex,vk){const [h,s,v]=rgb2hsv(hexRgb(hex));return hsv2rgb(h,Math.min(1,s*1.10),v*vk);}
function grad(ctx,x0,y0,x1,y1,stops){const g=ctx.createLinearGradient(x0,y0,x1,y1);stops.forEach(([o,c])=>g.addColorStop(o,c));return g;}
function rgrad(ctx,x,y,r,stops){const g=ctx.createRadialGradient(x,y,0,x,y,r);stops.forEach(([o,c])=>g.addColorStop(o,c));return g;}
function pillPath(l,t,r_,b,rad){const p=new Path2D();p.moveTo(l+rad,t);p.lineTo(r_-rad,t);p.arc(r_-rad,t+rad,rad,-Math.PI/2,0);p.lineTo(r_,b-rad);
  p.arc(r_-rad,b-rad,rad,0,Math.PI/2);p.lineTo(l+rad,b);p.arc(l+rad,b-rad,rad,Math.PI/2,Math.PI);p.lineTo(l,t+rad);p.arc(l+rad,t+rad,rad,Math.PI,Math.PI*1.5);p.closePath();return p;}

function paintIslandBody(ctx, IW, IH, accentHex=ISLAND_ACCENT){
  const L=1, T=1, R=IW-1, B=IH-1;
  const rad=Math.min(IH/2,(B-T)/2,(R-L)/2);
  const path=pillPath(L,T,R,B,rad);
  const acc=hexRgb(accentHex), shade=shadeOf(accentHex,.42);
  // 本体: アクセント色 α165
  ctx.fillStyle=rgba(acc,165); ctx.fill(path);
  const innerH=B-T, lightSpan=Math.min(IH*.95,innerH*.36), s1=Math.min(.34,(IH*.62)/innerH), s2=1-s1;
  const span=IH*.045;
  const bands=(count,style,clip)=>{ctx.save();if(clip){ctx.beginPath();ctx.rect(...clip);ctx.clip();}
    ctx.strokeStyle=style;for(let i=0;i<Math.min(count,12);i++){ctx.lineWidth=span*2*(1-i/12);ctx.stroke(path);}ctx.restore();};
  ctx.save(); ctx.clip(path);
  ctx.fillStyle=W8(10); ctx.fillRect(0,0,IW,IH);           // フロスト
  ctx.globalCompositeOperation='lighter';
  bands(12,grad(ctx,0,T,0,T+lightSpan,[[0,W8(14)],[.45,W8(4)],[1,W8(0)]]),[L,T-2,R-L,lightSpan+4]);
  bands(12,grad(ctx,0,B-lightSpan,0,B,[[0,W8(0)],[.55,W8(3)],[1,W8(9)]]),[L,B-lightSpan-2,R-L,lightSpan+4]);
  const dx=(R-L)*.55, dy=innerH*.55;
  bands(12,grad(ctx,L,T,L+dx,T+dy,[[0,W8(20)],[.55,W8(3)],[1,W8(0)]]));
  bands(12,grad(ctx,R-dx,B-dy,R,B,[[0,W8(0)],[.45,W8(2)],[1,W8(11)]]));
  ctx.globalCompositeOperation='multiply';
  bands(8,grad(ctx,0,T,0,B,[[0,rgba(shade,0)],[s1,rgba(shade,30)],[s2,rgba(shade,30)],[1,rgba(shade,0)]]));
  ctx.restore();
  ctx.save(); ctx.globalCompositeOperation='multiply';
  ctx.strokeStyle=grad(ctx,0,T,0,B,[[0,rgba(shade,120)],[s1,rgba(shade,230)],[s2,rgba(shade,230)],[1,rgba(shade,190)]]);
  ctx.lineWidth=1; ctx.stroke(path); ctx.restore();
}
function drawIsland(cv, IWp=240, buttons=true){
  const ctx=cv.getContext('2d');
  const s=cv.width/420*UI_K;           // canvas px per logical px
  ctx.setTransform(1,0,0,1,0,0); ctx.clearRect(0,0,cv.width,cv.height);
  ctx.setTransform(s,0,0,s,30*cv.width/420+(240-IWp)/2*s,30*cv.width/420);
  const IW=IWp, IH=42;
  paintIslandBody(ctx, IW, IH);
  // ボタン（中心X: 21 / w-95 / w-58 / w-21）
  if(buttons) [['#4A90E2','+',21],['#28C940','-',IW-95],['#FFBD2E','square',IW-58],['#FF5F57','x',IW-21]].forEach(([c,ic,x],i)=>{
    const sc=Array.isArray(buttons)?buttons[i]:1; if(sc<.01) return;
    ctx.save(); ctx.translate(x,IH/2); ctx.scale(sc,sc); ctx.translate(-x,-IH/2); drawIslandButton(ctx,c,ic,x,IH/2); ctx.restore(); });
}
function drawIslandButton(ctx,hex,icon,cx,cy){
  const r=12, base=hexRgb(hex);
  const shade=shadeOf(hex,.52);
  const [h,sa,v]=rgb2hsv(base); const tint=hsv2rgb(h,Math.min(1,sa*1.04),Math.min(1,v*1.20+10/255));
  // 落ち影
  const sr=r*1.28, sy=cy+r*.16;
  ctx.fillStyle=rgrad(ctx,cx,sy,sr,[[0,'rgba(0,0,0,.259)'],[.6,'rgba(0,0,0,.11)'],[1,'rgba(0,0,0,0)']]);
  ctx.beginPath();ctx.arc(cx,sy,sr,0,Math.PI*2);ctx.fill();
  const box=[cx-r,cy-r,r*2,r*2];
  ctx.save();ctx.beginPath();ctx.arc(cx,cy,r,0,Math.PI*2);ctx.clip();
  ctx.fillStyle=W8(10);ctx.fillRect(...box);
  ctx.fillStyle=rgba(tint,192);ctx.fillRect(...box);
  ctx.globalCompositeOperation='lighter';
  ctx.fillStyle=grad(ctx,cx-r,cy-r,cx+r,cy+r,[[0,W8(13)],[.55,W8(3)],[1,W8(0)]]);ctx.fillRect(...box);
  ctx.fillStyle=rgrad(ctx,cx,cy,r,[[0,W8(0)],[.38,W8(0)],[.68,W8(4)],[.86,W8(12)],[.96,W8(22)],[1,W8(18)]]);ctx.fillRect(...box);
  ctx.fillStyle=rgrad(ctx,cx,cy-r*1.02,r*.95,[[0,W8(22)],[.45,W8(7)],[1,W8(0)]]);ctx.fillRect(...box);
  ctx.fillStyle=rgrad(ctx,cx,cy+r*1.06,r*.80,[[0,W8(16)],[.45,W8(5)],[1,W8(0)]]);ctx.fillRect(...box);
  ctx.globalCompositeOperation='multiply';
  for(const side of [-1,1]){ctx.fillStyle=rgrad(ctx,cx+side*r*.92,cy,r*.95,[[0,rgba(shade,70)],[.45,rgba(shade,26)],[1,rgba(shade,0)]]);ctx.fillRect(...box);}
  ctx.restore();
  ctx.save();ctx.globalCompositeOperation='multiply';ctx.lineWidth=.9;
  ctx.strokeStyle=grad(ctx,0,cy-r,0,cy+r,[[0,rgba(shade,120)],[.5,rgba(shade,230)],[1,rgba(shade,190)]]);
  ctx.beginPath();ctx.arc(cx,cy,r-.35,0,Math.PI*2);ctx.stroke();
  ctx.globalCompositeOperation='lighter';
  ctx.strokeStyle=grad(ctx,0,cy-r,0,cy+r,[[0,W8(30)],[.32,W8(11)],[.68,W8(10)],[1,W8(24)]]);
  ctx.beginPath();ctx.arc(cx,cy,r-.85,0,Math.PI*2);ctx.stroke();
  ctx.restore();
  // アイコン（白）。閉じる/全画面/最小化は image/svg の 32×32 を 30px で描画
  ctx.save();ctx.fillStyle='#fff';ctx.strokeStyle='#fff';
  if(icon==='+'){ctx.lineWidth=2;ctx.lineCap='round';ctx.beginPath();ctx.moveTo(cx-4,cy);ctx.lineTo(cx+4,cy);ctx.moveTo(cx,cy-4);ctx.lineTo(cx,cy+4);ctx.stroke();}
  else{
    ctx.translate(cx-15,cy-15);ctx.scale(30/32,30/32);
    if(icon==='-'){ctx.beginPath();ctx.roundRect(16-10.351/2,16-2.227/2,10.351,2.227,.79);ctx.fill();}
    if(icon==='square'){const o=new Path2D('M10.645,12.705v6.589c0,1.138.922,2.06,2.06,2.06h6.589c1.138,0,2.06-.922,2.06-2.06v-6.589c0-1.138-.922-2.06-2.06-2.06h-6.589c-1.138,0-2.06.922-2.06,2.06ZM19.192,19.741h-6.385c-.303,0-.548-.245-.548-.548v-6.385c0-.303.245-.548.548-.548h6.385c.303,0,.548.245.548.548v6.385c0,.303-.245.548-.548.548Z');ctx.fill(o);}
    if(icon==='x'){for(const a of [45,-45]){ctx.save();ctx.translate(16,16);ctx.rotate(a*Math.PI/180);ctx.beginPath();ctx.roundRect(-2.227/2,-12.331/2,2.227,12.331,1.114);ctx.fill();ctx.restore();}}
  }
  ctx.restore();
}


const SOUND3_PATHS = ['M7.313,11.497h.686c.517,0,.936.419.936.936v6.194c0,.517-.419.936-.936.936h-.686c-1.057,0-1.916-.858-1.916-1.916v-4.235c0-1.057.858-1.916,1.916-1.916Z',
  'M14.184,24.115l-2.197-1.881c-.826-.732-1.495-1.76-1.495-2.297v-8.821c0-.537.669-1.565,1.495-2.297.732-.627,1.464-1.254,2.197-1.881,1.255-1.132,2.273-.661,2.273,1.054v15.071c0,1.714-1.018,2.186-2.273,1.054Z',
  'M20.439,21.592c-.248,0-.491-.123-.634-.348-.223-.35-.119-.813.23-1.035,1.597-1.015,2.55-2.764,2.55-4.679s-.953-3.664-2.55-4.679c-.35-.222-.453-.686-.23-1.035.222-.349.686-.453,1.035-.23,2.032,1.292,3.245,3.514,3.245,5.945s-1.213,4.653-3.245,5.944c-.125.079-.264.117-.401.117Z',
  'M22.13,24.257c-.247,0-.489-.122-.633-.346-.224-.349-.121-.812.228-1.036,2.499-1.6,3.991-4.346,3.991-7.345s-1.492-5.746-3.993-7.355c-.348-.225-.448-.688-.225-1.037.225-.347.687-.451,1.037-.225,2.931,1.887,4.681,5.108,4.681,8.616s-1.75,6.731-4.683,8.608c-.125.08-.266.118-.403.118Z',
  'M18.759,18.945c-.242,0-.479-.116-.624-.332-.23-.344-.139-.81.205-1.041.198-.133.346-.255.462-.383.079-.08.128-.14.171-.205.084-.113.135-.189.18-.272.103-.19.173-.372.217-.554.041-.129.049-.196.06-.268.022-.13.027-.246.027-.361s-.005-.232-.024-.341c-.014-.092-.021-.159-.044-.225-.062-.245-.133-.426-.235-.617-.045-.084-.096-.159-.153-.235-.069-.103-.118-.162-.173-.217-.142-.154-.288-.275-.485-.407-.345-.23-.437-.696-.206-1.041.23-.345.697-.437,1.04-.207.302.202.535.398.736.619.101.1.212.236.312.386.078.102.17.241.251.392.164.304.28.603.354.911.031.085.059.234.083.395.032.174.045.38.045.586s-.013.412-.048.606c-.021.14-.049.289-.099.438-.057.246-.172.544-.337.85-.08.149-.172.289-.276.428-.073.112-.185.248-.31.373-.176.194-.409.391-.711.594-.128.086-.273.127-.417.127Z'];

/* 背景の虹色のもやを、ゆっくり流れるように動かす（背景画像をノイズで歪ませて描く） */
function startFlow(cv, imgUrl) {
  const gl = cv.getContext('webgl', {alpha: false, antialias: false, premultipliedAlpha: false});
  if (!gl) return false;
  const VS = 'attribute vec2 p;varying vec2 v;void main(){v=p*.5+.5;gl_Position=vec4(p,0.,1.);}';
  const FS = `precision mediump float;varying vec2 v;uniform sampler2D T;uniform float t;uniform vec2 R;uniform vec2 I;
  vec3 h3(vec3 p){p=vec3(dot(p,vec3(127.1,311.7,74.7)),dot(p,vec3(269.5,183.3,246.1)),dot(p,vec3(113.5,271.9,124.6)));return -1.+2.*fract(sin(p)*43758.5453);}
  float n3(vec3 p){vec3 i=floor(p),f=fract(p),u=f*f*(3.-2.*f);
    return mix(mix(mix(dot(h3(i),f),dot(h3(i+vec3(1,0,0)),f-vec3(1,0,0)),u.x),mix(dot(h3(i+vec3(0,1,0)),f-vec3(0,1,0)),dot(h3(i+vec3(1,1,0)),f-vec3(1,1,0)),u.x),u.y),
               mix(mix(dot(h3(i+vec3(0,0,1)),f-vec3(0,0,1)),dot(h3(i+vec3(1,0,1)),f-vec3(1,0,1)),u.x),mix(dot(h3(i+vec3(0,1,1)),f-vec3(0,1,1)),dot(h3(i+vec3(1,1,1)),f-vec3(1,1,1)),u.x),u.y),u.z);}
  void main(){
    // cover 配置
    float ra=R.x/R.y, ia=I.x/I.y; vec2 uv=v; uv.y=1.-uv.y;
    if(ra>ia){uv.y=(uv.y-.5)*ia/ra+.5;}else{uv.x=(uv.x-.5)*ra/ia+.5;}
    vec2 q=uv*vec2(ra,1.)*1.3; float s=t*.32;
    vec2 w=vec2(n3(vec3(q,s)),n3(vec3(q+5.2,s+1.7)));
    vec2 w2=vec2(n3(vec3(q*1.7+w*1.2+3.1,s*1.3)),n3(vec3(q*1.7+w*1.2+8.3,s*1.3+2.)));
    vec2 d=(w*.2+w2*.12) + vec2(sin(t*.23),cos(t*.19))*.07;
    uv=(uv-.5)*(.7+.05*sin(t*.15))+.5+d;                        // 端が見えないよう少し拡大
    vec2 u2=uv+vec2(sin(s*1.3),cos(s*1.1))*.04;
    uv=1.-abs(1.-mod(uv,2.)); u2=1.-abs(1.-mod(u2,2.));   // 端は鏡映しで折り返す
    vec3 c=texture2D(T,uv).rgb;
    vec3 c2=texture2D(T,u2).rgb;
    vec3 col=mix(c,c2,.5);
    // ゆっくり漂う光のかたまり（背景の色を拾って重ねる）で、流れを目で追えるようにする
    vec2 p=v*vec2(ra,1.);
    for(int i=0;i<4;i++){
      float fi=float(i);
      vec2 ctr=vec2(.5*ra,.5)+vec2(sin(t*(.13+fi*.037)+fi*1.7)*.42*ra, cos(t*(.11+fi*.029)+fi*2.3)*.38);
      vec3 bc=texture2D(T,fract(vec2(.2+fi*.21,.3+fi*.17)+vec2(sin(t*.05+fi),cos(t*.04+fi))*.15)).rgb;
      bc=clamp(mix(vec3(dot(bc,vec3(.333))),bc,1.6),0.,1.);
      float r=.30+.08*sin(t*.2+fi);
      float a=exp(-dot(p-ctr,p-ctr)/(r*r))*.42;
      col=1.-(1.-col)*(1.-bc*a);
    }
    gl_FragColor=vec4(col,1.);
  }`;
  const sh = (ty, s) => { const o = gl.createShader(ty); gl.shaderSource(o, s); gl.compileShader(o); return o; };
  const pr = gl.createProgram(); gl.attachShader(pr, sh(gl.VERTEX_SHADER, VS)); gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, FS)); gl.linkProgram(pr);
  if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) return false;
  gl.useProgram(pr);
  const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  const loc = gl.getAttribLocation(pr, 'p'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
  const uT = gl.getUniformLocation(pr, 't'), uR = gl.getUniformLocation(pr, 'R'), uI = gl.getUniformLocation(pr, 'I');
  const tex = gl.createTexture(); let iw = 1, ih = 1, ready = false;
  const img = new Image(); img.onload = () => {
    gl.bindTexture(gl.TEXTURE_2D, tex); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, img);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    iw = img.width; ih = img.height; ready = true; frame(performance.now());
  };
  img.src = imgUrl;
  const still = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const SCALE = .35;   // もや自体がぼけているので低解像度で十分
  function fit() { const w = Math.max(1, Math.round(innerWidth * SCALE)), h = Math.max(1, Math.round(innerHeight * SCALE)); if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; } }
  const t0 = performance.now();
  function frame(now) {
    if (!ready) return;
    fit(); gl.viewport(0, 0, cv.width, cv.height);
    gl.uniform1f(uT, still ? 0 : (now - t0) / 1000); gl.uniform2f(uR, cv.width, cv.height); gl.uniform2f(uI, iw, ih);
    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    if (!still) requestAnimationFrame(frame);
  }
  addEventListener('resize', () => { if (still) frame(performance.now()); });
  return true;
}

/* =====================================================================
   サイト上で触れる PocketBoard（デモ）— 本体のソースに合わせた挙動
   - 描画: GlassHighlightEffect の GLASS_FRAG を WebGL2 に移植（プロモ動画と同じ）
   - 外からドロップ: その場にそのまま置く（出現アニメ無し）。サイトは Web リンクのランチャー（favicon ／ 頭文字の丸）
   - 左ドラッグ: バブル移動（持ち上げ 1.025）／右下の印でリサイズ／空白は範囲選択
   - クリック: アクティブ化（青い枠が脈打つ）。動画は再生/一時停止（280ms 待ってダブルクリックでなければ）
   - ダブルクリック: 全画面（ウィンドウが中身の対比へ 500ms InOutCubic、カメラも同時）。もう一度で戻る（300ms）
   - ダブルクリックの2回目を押したまま動かす／Shift+ドラッグ: 逆輸入（PBの外へ書き出し）。キャンバスが暗くなる
   - 中ボタンドラッグ: キャンバス移動（慣性あり）／ホイール: ズーム（1コリ10%、なめらかに）
   - 右クリック: アクティブ化のみ／右ドラッグ: ウィンドウ移動／右ダブルクリック: 全画面
   - 島: 上中央の 300×80 にカーソルが来たら出る。操作中は隠れる
   ===================================================================== */
var GLASS_DARK_K = .45, GUMMY_AMBIENT_LIFT = .45;
const MEDIA_BEZEL_RATIO = 25 / 162, LAUNCHER_BEZEL_RATIO = 25 / 96, MEDIA_SHORT = 162;
const SHADOW_K = .35, CONTACT_SHADOW_K = .7, GUMMY_SHADOW_K = .16, GUMMY_CONTACT_K = .45;
const ACCENT = '#0067C0';
const E = {
  inOut: x => x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2,
  out: x => 1 - Math.pow(1 - x, 3),
  outQuart: x => 1 - Math.pow(1 - x, 4),
  outQuint: x => 1 - Math.pow(1 - x, 5),
  inOutSine: x => -(Math.cos(Math.PI * x) - 1) / 2,
  outBack: (x, a = 1.70158) => { const c3 = a + 1; return x >= 1 ? 1 : 1 + c3 * Math.pow(x - 1, 3) + a * Math.pow(x - 1, 2); },
};
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, k) => a + (b - a) * k;
const SVG_NOW_PLAY = '<svg viewBox="0 0 32 32"><rect x="10.916" y="9.805" width="3.39" height="12.39" rx="1.432" fill="#fff"/><rect x="17.695" y="9.805" width="3.39" height="12.39" rx="1.432" fill="#fff"/></svg>';
const SVG_NOW_STOP = '<svg viewBox="0 0 32 32"><path d="M12.662,10.5l7.965,4.599c.694.401.694,1.402,0,1.802l-7.965,4.599c-.694.401-1.561-.1-1.561-.901v-9.197c0-.801.867-1.302,1.561-.901Z" fill="#fff"/></svg>';
const SVG_SOUND = `<svg viewBox="0 0 32 32">${SOUND3_PATHS.map(d => `<path d="${d}" fill="#fff"/>`).join('')}</svg>`;
const svgUrl = (svg, w, h) => 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg.replace(/^<svg /, `<svg xmlns="http://www.w3.org/2000/svg" width="${Math.round(w)}" height="${Math.round(h)}" `));
const loadImg = url => { const im = new Image(); im.src = url; return im.decode().then(() => im).catch(() => im); };
const loadCanvas = url => new Promise((ok, ng) => { const im = new Image(); im.onload = () => { const c = document.createElement('canvas'); c.width = im.naturalWidth; c.height = im.naturalHeight; c.getContext('2d').drawImage(im, 0, 0); ok(c); }; im.onerror = () => ng(new Error('load failed: ' + url)); im.src = url; });
const rasterSvg = (svg, w, h) => loadImg(svgUrl(svg, w, h)).then(im => { const c = document.createElement('canvas'); c.width = Math.round(w); c.height = Math.round(h); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); return c; });
function labelCanvas(text, rgba) {
  const S = 6, px = 14 * S, c = document.createElement('canvas'), x = c.getContext('2d');
  x.font = `700 ${px}px Arial, "Segoe UI", sans-serif`; const w = Math.ceil(x.measureText(text).width) + 8;
  c.width = w; c.height = Math.ceil(px * 1.35);
  x.font = `700 ${px}px Arial, "Segoe UI", sans-serif`; x.textBaseline = 'top'; x.fillStyle = rgba; x.fillText(text, 4, px * .12);
  return c;
}
// Web リンクの favicon が無いときの代わり（WebLinkIcon::fallbackIcon と同じ: ホスト名の色相の丸＋頭文字）
function webFallbackIcon(host, size = 256) {
  let h = 0; for (const ch of host) h = (h * 31 + ch.charCodeAt(0)) >>> 0;
  const c = document.createElement('canvas'); c.width = c.height = size; const x = c.getContext('2d');
  x.fillStyle = `hsl(${h % 360} ${Math.round(150 / 255 * 100)}% ${Math.round(105 / 255 * 100)}%)`;
  x.beginPath(); x.arc(size / 2, size / 2, size * .44, 0, Math.PI * 2); x.fill();
  x.fillStyle = 'rgba(255,255,255,.92)'; x.font = `700 ${size * .5}px Arial, sans-serif`; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.fillText(host[0].toUpperCase(), size / 2, size / 2 + size * .03);
  return c;
}
function siteThumb() {   // 左のブラウザに出す見た目（架空のギャラリーサイト）
  const c = document.createElement('canvas'); c.width = 640; c.height = 400; const x = c.getContext('2d');
  x.fillStyle = '#12151f'; x.fillRect(0, 0, 640, 400);
  x.fillStyle = '#fff'; x.font = '700 34px sans-serif'; x.fillText('Lumen Gallery', 32, 62);
  x.fillStyle = '#7d86a6'; x.font = '400 16px sans-serif'; x.fillText('Light, color and form', 32, 92);
  const g1 = x.createLinearGradient(32, 120, 300, 370); g1.addColorStop(0, '#2fb9a6'); g1.addColorStop(1, '#0b3a44');
  x.fillStyle = g1; x.beginPath(); x.roundRect(32, 120, 280, 248, 14); x.fill();
  x.fillStyle = '#f06fa8'; x.beginPath(); x.arc(240, 196, 38, 0, 7); x.fill(); x.fillStyle = '#c6fff3'; x.beginPath(); x.arc(130, 290, 56, 0, 7); x.fill();
  const g2 = x.createLinearGradient(330, 120, 608, 240); g2.addColorStop(0, '#5b3fd6'); g2.addColorStop(1, '#e0557c');
  x.fillStyle = g2; x.beginPath(); x.roundRect(328, 120, 280, 118, 14); x.fill();
  x.fillStyle = '#ffb46a'; x.beginPath(); x.roundRect(328, 250, 134, 118, 14); x.fill();
  x.fillStyle = '#26304a'; x.beginPath(); x.roundRect(474, 250, 134, 118, 14); x.fill();
  return c;
}

/* 入れられる素材（中身の短辺は本体の基準 162px） */
const SOURCES = {
  site:    {kind: 'tile', label: 'lumen.gallery', web: true},
  sunset:  {kind: 'image', label: 'sunset.png', ar: 4 / 3, make: () => loadCanvas('assets/art_sunset.jpg')},
  spheres: {kind: 'image', label: 'spheres.jpg', ar: 4 / 3, make: () => loadCanvas('assets/art_spheres.jpg')},
  ocean:   {kind: 'video', label: 'ocean.mp4', ar: 16 / 9, paint: 'vid1', dur: 72},
  orbs:    {kind: 'video', label: 'orbs.mp4', ar: 16 / 9, paint: 'vid2', dur: 48},
  folder:  {kind: 'tile', label: 'Assets', icon: 'folder'},
  notes:   {kind: 'tile', label: 'notes.txt', icon: 'notes'},
  app:     {kind: 'tile', label: 'Studio', icon: 'exe'},
};
const PAINT = {vid1: paintVid1, vid2: paintVid2};

function initDemo() {
  const demoEl = document.getElementById('demo'); if (!demoEl) return;
  const section = demoEl.closest('section');
  const pbEl = demoEl.querySelector('.pb'), host = demoEl.querySelector('.pb-canvas'), pbBody = demoEl.querySelector('.pb-body');
  const uiCv = demoEl.querySelector('.pb-ui'), uiX = uiCv.getContext('2d');
  const islandEl = demoEl.querySelector('.pb-island'), islandCv = islandEl.querySelector('canvas'), islandBlur = islandEl.querySelector('.iblur');
  const recall = demoEl.querySelector('.pb-recall');
  let g = null; try { g = makeGLR(); } catch (e) { g = null; console.error(e); window.__glErr = e; }
  if (!g) { demoEl.classList.add('no-gl'); showDemoError(demoEl, window.__glErr || new Error('WebGL2 が使えません')); return; }
  host.appendChild(g.cv);

  /* ---------- 状態 ---------- */
  let W = 1, H = 1, DPR = 1;
  let style = window.PB_STYLE || 'gummy', styleChangedAt = -10, visible = true;
  const BUB = [], selected = new Set();
  const cam = {cx: 0, cy: 0, z: 1}; let zoomTarget = null, zoomAnchor = null; const inertia = {vx: 0, vy: 0, on: false, sampleT: 0};   // CameraPanInertia（キャンバス単位/秒）
  let active = null;               // アクティブなバブル（青い枠・再生バーの持ち主）
  let focus = null;                // {b, t0, dir, from:{cx,cy,z,w,h}, to:{...}}
  let focusAmt = 0, glassF = 1;    // 全画面の進み具合 / ガラスの濃さ（全画面中は消える）
  let exportHint = 0, exportHintTarget = 0, exportFrom = 0, exportT0 = 0, exportWant = 0;
  let mode = '', press = null, pendingClick = null;
  let rect = null;                 // 範囲選択
  let TEX_STOP, TEX_PLAY;
  let lastT = performance.now() / 1000, mouseLocal = null, lastMoveT = 0;
  const now = () => performance.now() / 1000;
  const baseSize = {w: 0, h: 0};   // 全画面前のウィンドウサイズ（キャンバス固定の挙動で戻す）

  /* ---------- サイズ ---------- */
  function applySize() {
    const r = pbBody.getBoundingClientRect(); W = Math.max(1, r.width); H = Math.max(1, r.height);
    DPR = Math.min(2, devicePixelRatio || 1); g.resize(W, H, DPR); g.cv.style.width = W + 'px'; g.cv.style.height = H + 'px';
    uiCv.width = Math.round(W * DPR); uiCv.height = Math.round(H * DPR); uiCv.style.width = W + 'px'; uiCv.style.height = H + 'px';
  }
  new ResizeObserver(() => { if (!focus) applySize(); kick(); }).observe(pbBody);

  /* ---------- バブル ---------- */
  async function makeBubble(key, x, y) {
    const S = SOURCES[key], b = {key, kind: S.kind, label: S.label, x, y, scale: 1, lift: 1, liftAnim: null, playing: false, vt: 0, playAt: -10, dur: S.dur || 0};
    if (S.kind === 'tile') {
      b.cw0 = b.ch0 = 96;
      const ic = S.web ? webFallbackIcon(S.label) : await loadCanvas(`assets/icon_${S.icon}.png`);
      b.tex = g.texFrom(ic, {mip: true}); b.small = g.makeSmall(ic, 0, 0, ic.width, ic.height); b.thumb = ic;
      const lw = labelCanvas(S.label, 'rgba(245,247,252,.941)'), lg = labelCanvas(S.label, 'rgba(70,70,70,.941)');
      b.labelW = g.texFrom(lw); b.labelG = g.texFrom(lg); b.labelAR = lw.width / lw.height; b.labelPxW = lw.width / 6;
    } else {
      b.ch0 = MEDIA_SHORT; b.cw0 = MEDIA_SHORT * S.ar;
      if (S.kind === 'video') {
        b.paint = PAINT[S.paint]; b.vcv = document.createElement('canvas'); b.vcv.width = Math.round(b.cw0 * 3); b.vcv.height = Math.round(b.ch0 * 3);
        b.paint(b.vcv, .8); b.tex = g.texFrom(b.vcv); b.small = g.makeSmall(b.vcv, 0, 0, b.vcv.width, b.vcv.height); b.smallKey = -1; b.thumb = b.vcv;
      } else {
        const c = await S.make(); b.tex = g.texFrom(c, {mip: true}); b.small = g.makeSmall(c, 0, 0, c.width, c.height); b.thumb = c;
      }
    }
    return b;
  }
  const cw = b => b.cw0 * b.scale, ch = b => b.ch0 * b.scale;
  const bezOf = b => Math.min(cw(b), ch(b)) * (b.kind === 'tile' ? LAUNCHER_BEZEL_RATIO : MEDIA_BEZEL_RATIO);
  const boardOf = b => { const z = bezOf(b); return {x0: b.x - cw(b) / 2 - z, y0: b.y - ch(b) / 2 - z, x1: b.x + cw(b) / 2 + z, y1: b.y + ch(b) / 2 + z}; };
  const toWorld = (sx, sy) => ({x: cam.cx + (sx - W / 2) / cam.z, y: cam.cy + (sy - H / 2) / cam.z});
  const toScreen = (wx, wy) => ({x: W / 2 + (wx - cam.cx) * cam.z, y: H / 2 + (wy - cam.cy) * cam.z});
  function hit(sx, sy) {
    const p = toWorld(sx, sy);
    for (let i = BUB.length - 1; i >= 0; i--) {
      const b = BUB[i], r = boardOf(b), bz = bezOf(b);
      if (p.x >= r.x1 - bz * 1.3 && p.x <= r.x1 + 4 / cam.z && p.y >= r.y1 - bz * 1.3 && p.y <= r.y1 + 4 / cam.z) return {b, handle: true};
      if (p.x >= r.x0 && p.x <= r.x1 && p.y >= r.y0 && p.y <= r.y1) return {b, handle: false};
    }
    return null;
  }
  const raise = b => { BUB.splice(BUB.indexOf(b), 1); BUB.push(b); };
  function setLift(b, to) { b.liftAnim = {from: b.lift, to, t0: now(), dur: .25, ease: to > 1 ? E.outQuart : E.outQuint}; }
  function activate(b) {
    if (active === b) return;
    if (active) { active.lift = 1; active.liftAnim = null; }
    active = b;
    if (b && b.kind === 'video') { bar.popT0 = now(); bar.owner = b; }
  }


  /* ---------- 重なりの押し出し（CanvasWidget::computeOverlapPushOffsets / animateItemOffsets） ---------- */
  const pushAnims = new Map();
  function pushOverlaps(fixedList) {
    const fixed = new Set(fixedList), off = new Map(), rank = new Map(), base = new Map(), UNR = 1e9;
    BUB.forEach(b => { base.set(b, boardOf(b)); off.set(b, {x: 0, y: 0}); rank.set(b, fixed.has(b) ? 0 : UNR); });
    for (let iter = 0; iter < 64; iter++) {
      let any = false;
      for (let i = 0; i < BUB.length; i++) for (let j = i + 1; j < BUB.length; j++) {
        const a = BUB[i], b = BUB[j]; if (fixed.has(a) && fixed.has(b)) continue;
        const oa = off.get(a), ob = off.get(b), ra = base.get(a), rb = base.get(b);
        const ax0 = ra.x0 + oa.x, ax1 = ra.x1 + oa.x, ay0 = ra.y0 + oa.y, ay1 = ra.y1 + oa.y, bx0 = rb.x0 + ob.x, bx1 = rb.x1 + ob.x, by0 = rb.y0 + ob.y, by1 = rb.y1 + ob.y;
        const ox = Math.min(ax1, bx1) - Math.max(ax0, bx0), oy = Math.min(ay1, by1) - Math.max(ay0, by0);
        if (ox <= 0 || oy <= 0) continue; any = true;
        const dx = (bx0 + bx1) / 2 - (ax0 + ax1) / 2, dy = (by0 + by1) / 2 - (ay0 + ay1) / 2;
        const d = ox < oy ? {x: (dx >= 0 ? 1 : -1) * (ox + .5), y: 0} : {x: 0, y: (dy >= 0 ? 1 : -1) * (oy + .5)};
        const rA = rank.get(a), rB = rank.get(b);
        if (rA < rB) { ob.x += d.x; ob.y += d.y; rank.set(b, rA + 1); }
        else if (rB < rA) { oa.x -= d.x; oa.y -= d.y; rank.set(a, rB + 1); }
        else { oa.x -= d.x / 2; oa.y -= d.y / 2; ob.x += d.x / 2; ob.y += d.y / 2; }
      }
      if (!any) break;
    }
    off.forEach((o, b) => { if (fixed.has(b) || (Math.abs(o.x) < .01 && Math.abs(o.y) < .01)) return;
      pushAnims.set(b, {t0: now(), fx: b.x, fy: b.y, tx: b.x + o.x, ty: b.y + o.y}); });
    kick();
  }
  function stepPush(t) {
    let any = false;
    pushAnims.forEach((a, b) => { const k = clamp((t - a.t0) / .42), e = E.outBack(k); b.x = lerp(a.fx, a.tx, e); b.y = lerp(a.fy, a.ty, e); if (k >= 1) pushAnims.delete(b); else any = true; });
    return any;
  }

  /* ---------- 島 ---------- */
  const isl = {showing: false, w: 42, wFrom: 42, wTo: 42, wT0: -10, op: 0, opFrom: 0, opT0: -10, lockUntil: 0,
    btn: [0, 0, 0, 0], btnT0: [-1, -1, -1, -1], bounce: [1, 1, 1, 1], bounceFrom: 1, hoverIdx: -1, hoverT0: 0, leaveIdx: -1, leaveT0: 0, key: ''};
  const islDelay = [0, 140, 70, 0];   // 設定・最小化・最大化・閉じる（設定と閉じるが先、最大化は70ms、最小化は140ms遅れ）
  function showIsland(t) {
    isl.showing = true; isl.lockUntil = t + .3; isl.op = 1;
    isl.wFrom = isl.w; isl.wTo = 240; isl.wT0 = t; isl.btnT0 = islDelay.map(d => t + d / 1000);
  }
  function hideIsland(t) {
    isl.showing = false; isl.lockUntil = t + .3; isl.btnT0 = [-1, -1, -1, -1]; isl.btn = [0, 0, 0, 0]; isl.bounce = [1, 1, 1, 1];
    isl.wFrom = isl.w; isl.wTo = 42; isl.wT0 = t; isl.opFrom = isl.op; isl.opT0 = t + .05;
  }
  const islandRect = () => ({x: W / 2 - 120, y: 15, w: 240, h: 42});
  const islBtnX = [21, 240 - 95, 240 - 58, 240 - 21];
  function islandButtonAt(sx, sy) {
    if (!isl.showing || isl.op < .5) return -1; const r = islandRect();
    for (let i = 0; i < 4; i++) if (Math.hypot(sx - (r.x + islBtnX[i]), sy - (r.y + 21)) <= 13) return i;
    return -1;
  }
  function updateIsland(t) {
    const manip = mode === 'move' || mode === 'pan' || mode === 'rect' || mode === 'resize' || mode === 'window' || mode === 'export';
    if (manip) { if (isl.showing && t >= isl.lockUntil) hideIsland(t); }
    else if (t >= isl.lockUntil && mouseLocal) {
      const inTrigger = Math.abs(mouseLocal.x - W / 2) <= 150 && mouseLocal.y >= 0 && mouseLocal.y <= 80;
      const r = islandRect(), onIsland = mouseLocal.x >= r.x - 30 && mouseLocal.x <= r.x + r.w + 30 && mouseLocal.y >= r.y - 30 && mouseLocal.y <= r.y + r.h + 30;
      if (inTrigger && !isl.showing) showIsland(t);
      else if (!inTrigger && !onIsland && isl.showing) hideIsland(t);
    } else if (!mouseLocal && isl.showing && t >= isl.lockUntil) hideIsland(t);
    // アニメ（幅 500ms OutBack、ボタン 600ms OutBack(振幅2)、消えるときは50ms後に120msでフェード）
    const kw = clamp((t - isl.wT0) / .5); isl.w = lerp(isl.wFrom, isl.wTo, E.outBack(kw));
    if (!isl.showing) { const ko = clamp((t - isl.opT0) / .12); isl.op = t < isl.opT0 ? isl.opFrom : lerp(isl.opFrom, 0, ko); }
    for (let i = 0; i < 4; i++) {
      if (isl.btnT0[i] >= 0) { const k = clamp((t - isl.btnT0[i]) / .6); isl.btn[i] = t < isl.btnT0[i] ? 0 : E.outBack(k, 1.70158 * 2); }
      if (isl.hoverIdx === i) { const k = clamp((t - isl.hoverT0) / .15); isl.bounce[i] = lerp(isl.bounceFrom, 1.15, 1 - (1 - k) * (1 - k)); }
      else if (isl.leaveIdx === i) { const k = clamp((t - isl.leaveT0) / .4); isl.bounce[i] = k < .4 ? 1.15 - k * .25 / .4 : .9 + (k - .4) * .1 / .6; }
    }
    const animating = kw < 1 || (!isl.showing && isl.op > 0) || isl.btnT0.some(t0 => t0 >= 0 && t - t0 < .6) || (isl.leaveIdx >= 0 && t - isl.leaveT0 < .4) || (isl.hoverIdx >= 0 && t - isl.hoverT0 < .15);
    islandEl.style.opacity = isl.op.toFixed(3);
    const key = isl.w.toFixed(2) + '|' + isl.btn.map((v, i) => (v * isl.bounce[i]).toFixed(3)).join(',');
    if (key !== isl.key && isl.op > 0) {
      isl.key = key;
      const d = Math.min(2, devicePixelRatio || 1); if (islandCv.width !== Math.round(280 * d)) { islandCv.width = Math.round(280 * d); islandCv.height = Math.round(82 * d); }
      drawIsland(islandCv, isl.w, isl.btn.map((v, i) => v * isl.bounce[i]));
      const inset = (240 - isl.w) / 2 + 1; islandBlur.style.left = islandBlur.style.right = inset + 'px';
    }
    return animating;
  }

  /* ---------- 再生バー（CanvasVideo::paintPlaybackOverlay） ---------- */
  const bar = {owner: null, fade: 0, popT0: -10, seekHover: 0, countdown: false, muted: false};
  const ICON_IMG = {};
  ['play', 'stop', 'sound'].forEach(k => loadCanvas(`assets/ui_${k}.png`).then(c => ICON_IMG[k] = c).catch(() => {}));
  const acc = hexRgb(ACCENT), accShade = shadeOf(ACCENT, .42);
  const accLight = (() => { const [h, s, v] = rgb2hsv(acc); return hsv2rgb(h, Math.min(1, s * .82), Math.min(1, v * 1.35 + 40 / 255)); })();
  function glassPlate(x, path, a) {   // 島・再生バー共通のガラスの板（アクセント色 α165 ＋ フロスト ＋ 乗算の縁）
    x.save(); x.fillStyle = rgba(acc, 165 * a); x.fill(path); x.clip(path); x.fillStyle = W8(10 * a); x.fill(path); x.restore();
    x.save(); x.globalCompositeOperation = 'multiply'; x.strokeStyle = rgba(accShade, 190 * a); x.lineWidth = 1; x.stroke(path); x.restore();
  }
  function drawBar(t, dt) {
    const x = uiX; x.setTransform(DPR, 0, 0, DPR, 0, 0); x.clearRect(0, 0, W, H);
    const v = active && active.kind === 'video' ? active : null;
    if (v) bar.owner = v;
    const idleHidden = focus && focus.dir > 0 && (t - lastMoveT) > 2 && !(mouseLocal && mouseLocal.y >= H - 76);   // 全画面中は2秒止まると隠れる
    const want = !!v && mode !== 'move' && !idleHidden;
    bar.fade += ((want ? 1 : 0) - bar.fade) * Math.min(1, (want ? 8 : 12) * dt);
    const o = bar.owner; if (!o || bar.fade < .002) return want || idleHidden === false && !!v;
    const a = bar.fade, by = H - 28;
    const tp = t - bar.popT0, popVol = tp < 0 ? 0 : (tp > .32 ? 1 : E.outBack(tp / .32)), popPlay = tp < .07 ? 0 : (tp - .07 > .32 ? 1 : E.outBack((tp - .07) / .32));
    const circle = (cx, r, img, imgSize, imgAlpha = 1) => {
      if (r < .5) return; const p = new Path2D(); p.arc(cx, by, r, 0, Math.PI * 2);
      glassPlate(x, p, a);
      x.save(); x.clip(p); x.globalCompositeOperation = 'lighter';
      const hl = x.createLinearGradient(cx - r, by - r, cx + r, by + r); hl.addColorStop(0, W8(22 * a)); hl.addColorStop(.55, W8(4 * a)); hl.addColorStop(1, W8(0));
      x.fillStyle = hl; x.fillRect(cx - r, by - r, r * 2, r * 2); x.restore();
      if (img) { x.save(); x.globalAlpha = a * imgAlpha; const s = imgSize * r / 16; x.drawImage(img, cx - s / 2, by - s / 2, s, s); x.restore(); }
    };
    circle(28, 16 * popPlay, ICON_IMG[o.playing ? 'play' : 'stop'], 25);
    circle(64, 16 * popVol, ICON_IMG.sound, 18, bar.muted ? .45 : 1);
    const sx = 88, sw = W - sx - 100, sy = by - 2;
    if (sw > 0) {
      const tr = new Path2D(); tr.roundRect(sx, sy, sw, 4, 2);
      x.save(); x.fillStyle = rgba(acc, 165 * .72 * a); x.fill(tr); x.save(); x.clip(tr); x.globalCompositeOperation = 'lighter'; x.fillStyle = W8(16 * a); x.fillRect(sx, sy, sw, 1.4); x.restore();
      x.globalCompositeOperation = 'multiply'; x.strokeStyle = rgba(accShade, 170 * a); x.lineWidth = 1; x.stroke(tr); x.restore();
      const played = sw * ((o.vt % o.dur) / o.dur);
      x.fillStyle = rgba(accLight, 235 * a); x.beginPath(); x.roundRect(sx, sy, Math.max(0, played), 4, 2); x.fill();
      const hov = mouseLocal && mouseLocal.x >= sx && mouseLocal.x <= sx + sw && Math.abs(mouseLocal.y - by) <= 12;
      bar.seekHover += ((hov || mode === 'seek' ? 1 : 0) - bar.seekHover) * Math.min(1, 14 * dt);
      if (bar.seekHover > .01) { x.fillStyle = `rgba(255,255,255,${(a * bar.seekHover).toFixed(3)})`; x.beginPath(); x.arc(sx + played, by, 6 * (.6 + .4 * bar.seekHover), 0, Math.PI * 2); x.fill(); }
    }
    const pad = new Path2D(); pad.roundRect(W - 12 - 80, by - 16, 80, 32, 16); glassPlate(x, pad, a);
    const fmt = s => `${s < 0 ? '-' : ''}${Math.floor(Math.abs(s) / 60)}:${String(Math.floor(Math.abs(s) % 60)).padStart(2, '0')}`;
    const pos = o.vt % o.dur, txt = bar.countdown ? fmt(pos - o.dur) : `${fmt(pos)} / ${fmt(o.dur)}`;
    x.fillStyle = `rgba(255,255,255,${(.94 * a).toFixed(3)})`; x.font = '600 11px "Segoe UI", Arial, sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(txt, W - 12 - 40, by + .5);
    return Math.abs(bar.fade - (want ? 1 : 0)) > .002 || tp < .4 || (bar.seekHover > .01 && bar.seekHover < .99) || (focus && focus.dir > 0 && !idleHidden);
  }
  function barHit(sx, sy) {
    if (!bar.owner || bar.fade < .5 || active !== bar.owner) return null;
    const by = H - 28;
    if (Math.hypot(sx - 28, sy - by) <= 17) return 'play';
    if (Math.hypot(sx - 64, sy - by) <= 17) return 'vol';
    if (sx >= W - 92 && sx <= W - 12 && Math.abs(sy - by) <= 16) return 'time';
    if (sx >= 88 && sx <= W - 100 && sy >= by - 12 && sy <= by + 16) return 'seek';
    return null;
  }
  const seekTo = sx => { const o = bar.owner; if (!o) return; o.vt = clamp((sx - 88) / (W - 188)) * o.dur; o.needPaint = true; };

  /* ---------- 全画面 ---------- */
  function focusSize(aw, ah) {   // MainWindow::calcFocusSize（今の大きさの中で中身の対比へ。最小 480×270 だが置き場に収める）
    const curW = baseSize.w, curH = baseSize.h, tar = aw / ah, car = curW / curH;
    let nw, nh; if (tar > car) { nw = curW; nh = curW / tar; } else { nh = curH; nw = curH * tar; }
    const minW = Math.min(480, curW), minH = Math.min(270, curH);
    if (nw < minW) { nw = minW; nh = nw / tar; } if (nh < minH) { nh = minH; nw = nh * tar; }
    return {w: Math.min(nw, curW), h: Math.min(nh, curH)};
  }
  // CanvasWidget::animateCamera（画面座標ベースの補間）:
  //   zoom(f) = z0 × (z1/z0)^f（対数補間）, camPos(f) = P − ((1−f)·off0 + f·off1) / zoom(f)
  //   寄る: P = 着地先（バブル中心）, off1 = 0 → バブルが画面中心へまっすぐ引き込まれる
  //   引く: P = 出発点（いま中心にあるバブル）, off0 = 0 → バブルが着地後の位置へまっすぐ送り出される
  function camAnim(tp, tz, dur, anchorTarget, extra) {
    const from = {x: cam.cx, y: cam.cy}, z0 = cam.z, P = anchorTarget ? {x: tp.x, y: tp.y} : from;
    return Object.assign({t0: now(), dur, z0, z1: tz, P, tp,
      off0: {x: (P.x - from.x) * z0, y: (P.y - from.y) * z0}, off1: {x: (P.x - tp.x) * tz, y: (P.y - tp.y) * tz}}, extra);
  }
  function startFocus(b) {
    if (b.kind === 'tile') return;
    activate(b); b.lift = 1; b.liftAnim = null; inertia.on = false; inertia.vx = inertia.vy = 0; zoomTarget = null; selected.clear();
    baseSize.w = W; baseSize.h = H;
    const fs = focusSize(cw(b), ch(b)), z = clamp(Math.min(fs.w / cw(b), fs.h / ch(b)), .1, 10);
    focus = camAnim({x: b.x, y: b.y}, z, .5, true, {b, dir: 1, w0: W, h0: H, w1: fs.w, h1: fs.h, pre: {x: cam.cx, y: cam.cy, z: cam.z}});
  }
  function endFocus() {
    if (!focus || focus.dir < 0) return;
    const pre = focus.pre;
    focus = camAnim({x: pre.x, y: pre.y}, pre.z, .3, false, {b: focus.b, dir: -1, w0: W, h0: H, w1: baseSize.w, h1: baseSize.h, pre});
  }
  function stepFocus(t) {
    if (!focus) return false;
    const k = clamp((t - focus.t0) / focus.dur), f = E.inOut(k);
    if (focus.dir < 0 || !focus.settled) {
      const zf = focus.z0 * Math.pow(focus.z1 / focus.z0, f);
      cam.z = zf; cam.cx = focus.P.x - ((1 - f) * focus.off0.x + f * focus.off1.x) / zf; cam.cy = focus.P.y - ((1 - f) * focus.off0.y + f * focus.off1.y) / zf;
      const w = lerp(focus.w0, focus.w1, f), h = lerp(focus.h0, focus.h1, f);   // ウィンドウも同じ長さ・同じカーブ（InOutCubic）
      pbBody.style.width = w + 'px'; pbBody.style.height = h + 'px';
      if (Math.abs(w - W) > .5 || Math.abs(h - H) > .5) applySize();
      if (k >= 1 && focus.dir > 0) focus.settled = true;
    }
    focusAmt = focus.dir > 0 ? f : 1 - f;
    if (k >= 1 && focus.dir < 0) { focus = null; focusAmt = 0; pbBody.style.width = ''; pbBody.style.height = ''; applySize(); return true; }
    return k < 1;
  }
  function clampFocusCam() {
    if (!focus || focus.dir < 0) return; const b = focus.b, hw = Math.max(0, (cw(b) * cam.z - W) / 2) / cam.z, hh = Math.max(0, (ch(b) * cam.z - H) / 2) / cam.z;
    cam.cx = clamp(cam.cx, b.x - hw, b.x + hw); cam.cy = clamp(cam.cy, b.y - hh, b.y + hh);
  }

  /* ---------- 描画（CanvasWidget::paintGL のバブル部分） ---------- */
  function render(t, dt) {
    let anim = stepFocus(t); if (stepPush(t)) anim = true;
    if (zoomTarget !== null) {   // ホイールズームのイージング（CameraZoomEase）
      const before = toWorld(zoomAnchor.x, zoomAnchor.y);
      cam.z += (zoomTarget - cam.z) * Math.min(1, dt * 16);
      const after = toWorld(zoomAnchor.x, zoomAnchor.y); cam.cx += before.x - after.x; cam.cy += before.y - after.y; clampFocusCam();
      if (Math.abs(zoomTarget - cam.z) < 1e-4) { cam.z = zoomTarget; zoomTarget = null; } anim = true;
    }
    if (inertia.on && mode !== 'pan') {   // 慣性: 1秒で6%まで減速する指数減衰、5未満で停止
      const d = Math.min(dt, .064); cam.cx += inertia.vx * d; cam.cy += inertia.vy * d; clampFocusCam();
      const k = Math.pow(.06, d); inertia.vx *= k; inertia.vy *= k;
      if (Math.hypot(inertia.vx, inertia.vy) < 5) { inertia.on = false; inertia.vx = inertia.vy = 0; } else anim = true;
    }
    const gTarget = focus && focus.dir > 0 ? 0 : 1; glassF += (gTarget - glassF) * Math.min(1, dt / .1); if (Math.abs(glassF - gTarget) > .002) anim = true; else glassF = gTarget;
    // 逆輸入の暗転（2回目を押して140ms／動かす／Shift。200ms OutCubic）
    const want = (mode === 'export' || (mode === 'dpress' && press && (t - press.t >= .14 || press.moved3)) || (shiftDown && BUB.length && pointerInside && !focus)) ? 1 : 0;
    if (want !== exportWant) { exportWant = want; exportFrom = exportHint; exportT0 = t; }
    exportHint = lerp(exportFrom, exportWant, E.out(clamp((t - exportT0) / .2))); if (Math.abs(exportHint - exportWant) > .002) anim = true;
    const gs = 22 * cam.z; host.style.backgroundSize = `${gs}px ${gs}px`; host.style.backgroundPosition = `${W / 2 - cam.cx * cam.z}px ${H / 2 - cam.cy * cam.z}px`;

    g.begin();
    const gummy = style === 'gummy', z = cam.z, vcx = W / 2, vcy = H / 2, pm = g.pm, anchorX = W * .3, anchorY = -H * .25;
    if (exportHint > .002) g.rect(0, 0, W, H, 0, pm(0, 0, 0, 120 * exportHint), pm(0, 0, 0, 0), 0);
    const ph = (t / .9) % 2, pulse = 190 + 65 * E.inOutSine(ph < 1 ? ph : 2 - ph);   // 190↔255 を 900ms で往復
    for (const b of BUB) {
      if (b.liftAnim) { const k = clamp((t - b.liftAnim.t0) / b.liftAnim.dur); b.lift = lerp(b.liftAnim.from, b.liftAnim.to, b.liftAnim.ease(k)); if (k >= 1) b.liftAnim = null; else anim = true; }
      let s = b.lift, wob = 0;
      const d2 = t - styleChangedAt - Math.hypot(b.x - cam.cx, b.y - cam.cy) * .0006;   // スタイル切り替えのぷるっ（サイトの演出）
      if (d2 > 0 && d2 < .7) { s *= 1 - Math.sin(Math.min(d2, .12) / .12 * Math.PI) * .07; wob = Math.sin(d2 * 24) * Math.exp(-d2 * 7) * .05; anim = true; }
      const isF = focus && focus.b === b, gf = isF ? glassF : 1, ccf = isF ? 1 - focusAmt : 1;
      if (b.vcv) {
        if (b.playing) { b.vt += dt; anim = true; }
        if (b.playing || b.needPaint) { b.paint(b.vcv, b.vt + .8); g.texUpdate(b.tex, b.vcv); b.needPaint = false;
          const key = Math.floor(b.vt * 10); if (key !== b.smallKey) { b.smallKey = key; g.makeSmall(b.vcv, 0, 0, b.vcv.width, b.vcv.height, b.small); } }
      }
      const cx = W / 2 + (b.x - cam.cx) * z, cy = H / 2 + (b.y - cam.cy) * z;
      const sw = cw(b) * z * s * (1 + wob), sh = ch(b) * z * s * (1 - wob);
      const launcher = b.kind === 'tile', bez = Math.min(sw, sh) * (launcher ? LAUNCHER_BEZEL_RATIO : MEDIA_BEZEL_RATIO);
      const sr = [cx - sw / 2, cy - sh / 2, sw, sh], board = [sr[0] - bez, sr[1] - bez, sw + bez * 2, sh + bez * 2];
      if (board[0] > W + 80 || board[1] > H + 80 || board[0] + board[2] < -80 || board[1] + board[3] < -80) continue;
      const boardR = launcher ? bez * .8 : bez * 1.25, contentR = Math.min(sw, sh) * MEDIA_BEZEL_RATIO * .25 * ccf;
      const zn = Math.max(z, 1e-6);
      const lightAngle = Math.atan2((vcy + (anchorY - vcy) / zn) - (vcy + (cy - vcy) / zn), (vcx + (anchorX - vcx) / zn) - (vcx + (cx - vcx) / zn));
      const isAct = (b === active || selected.has(b)) && !isF;
      const opts = {board, radius: boardR, bezel: bez, contentRadius: contentR, lightAngle, intensity: (isAct ? 1 : .8) * gf,
        innerMix: launcher ? 0 : 1, launcher, content: launcher ? (gummy ? b.tex : null) : b.tex, small: gummy ? b.small : null};
      if (gf > .001) g.glow(...board, boardR, gummy ? pm(5, 31, 38, 150 * GUMMY_SHADOW_K * gf) : pm(0, 0, 0, 45 * SHADOW_K * gf), Math.max(8, bez * (gummy ? 1.21 : .64)));
      const chrome = a => {   // 枠（アクティブ時は青い枠とグローが脈打つ）
        if (a <= .002) return;
        if (isAct) { g.glow(...board, boardR, pm(120, 180, 255, Math.min(165, pulse * .6) * a), 32); g.rect(...board, boardR, pm(255, 255, 255, 90 * a), pm(140, 195, 255, pulse * a), 4); anim = true; }
        else g.rect(...board, boardR, pm(255, 255, 255, (launcher ? 46 : gummy ? 0 : 46) * a), pm(255, 255, 255, (launcher ? 130 : gummy ? 118 : 130) * a), 1.5);
      };
      const markers = a => { if (a <= .002) return; const ix = board[0] + board[2] - bez * .5, iy = board[1] + board[3] - bez * .5, is = bez * 10 / 25, lw = Math.max(1, bez * 1.5 / 25), c = pm(255, 255, 255, 180 * a);
        g.line(ix - is, iy - is * .3, ix - is * .3, iy - is, lw, c); g.line(ix - is * .6, iy - is * .3, ix - is * .3, iy - is * .6, lw, c); };
      if (!launcher) {
        if (gf > .001) g.glow(...sr, contentR, pm(2, 4, 8, gummy ? 67 * GUMMY_CONTACT_K * gf : 82 * CONTACT_SHADOW_K * gf), bez * .22);
        chrome(ccf); markers(ccf);
        g.image(b.tex, ...sr, contentR, 1);
        if (b.kind === 'video') {
          const r0 = Math.min(sw, sh) * .13; let sc = 1, mark = 1, al = 1, tex = TEX_STOP;
          if (b.playing) { const k = Math.exp(-12 * (t - b.playAt)); sc = k; mark = 1.5 * k; al = k; tex = TEX_PLAY; if (al > .002) anim = true; }
          if (al > .002) { g.circle(cx, cy, r0 * sc, pm(0, 0, 0, 120 * al)); const is = r0 * mark * 1.1; g.image(tex, cx - is / 2, cy - is / 2, is, is, 0, al); }
        }
        if (gf > .001) g.glass(style, opts);
      } else {
        if (gummy && gf > .001) g.glass(style, opts);
        chrome(1);
        const unit = sw / 96, iconS = 60 * unit, icy = board[1] + board[3] / 2;
        g.image(b.tex, cx - iconS / 2, icy - iconS / 2, iconS, iconS, 0, 1);
        const fs = Math.min(1, 66 / b.labelPxW), lh = 14 * 1.35 * unit * fs, lwid = lh * b.labelAR, ly = icy + 34 * unit;
        if (gummy) { g.multiply(true); g.image(b.labelG, cx - lwid / 2, ly, lwid, lh, 0, 1); g.multiply(false); }
        else g.image(b.labelW, cx - lwid / 2, ly, lwid, lh, 0, 1);
        markers(1);
        if (!gummy && gf > .001) g.glass(style, opts);
      }
    }
    if (rect) { const a = toScreen(rect.x0, rect.y0), c = toScreen(rect.x1, rect.y1), x0 = Math.min(a.x, c.x), y0 = Math.min(a.y, c.y), w = Math.abs(c.x - a.x), h = Math.abs(c.y - a.y);
      if (w >= 2 || h >= 2) g.rect(x0, y0, w, h, Math.min(1, w / 2, h / 2), pm(130, 175, 255, 30), pm(130, 175, 255, 230), 1.5); }
    if (drawBar(t, dt)) anim = true;
    if (updateIsland(t)) anim = true;
    return anim;
  }

  /* ---------- 操作 ---------- */
  let shiftDown = false, pointerInside = false, lastMid = null, lastRight = null;
  addEventListener('keydown', e => { if (e.key === 'Shift') { shiftDown = true; kick(); } });
  addEventListener('keyup', e => { if (e.key === 'Shift') { shiftDown = false; kick(); } });
  const local = e => { const r = pbBody.getBoundingClientRect(); return {x: e.clientX - r.left, y: e.clientY - r.top}; };
  pbEl.addEventListener('contextmenu', e => e.preventDefault());
  pbEl.addEventListener('mousedown', e => { if (e.button === 1) e.preventDefault(); });   // 中ボタンの自動スクロールを出さない
  pbEl.addEventListener('auxclick', e => { if (e.button === 1) e.preventDefault(); });
  function schedClick(b) {   // 280ms 待ってダブルクリックでなければシングルクリック（動画は再生/一時停止）
    if (pendingClick) clearTimeout(pendingClick.timer);
    const pc = {b, t: now()}; pc.timer = setTimeout(() => { if (pendingClick === pc) { pendingClick = null; if (b.kind === 'video') { togglePlay(b); kick(); } } }, 280);
    pendingClick = pc;
  }
  const cancelClick = () => { if (pendingClick) { clearTimeout(pendingClick.timer); pendingClick = null; } };
  function togglePlay(b) { b.playing = !b.playing; if (b.playing) b.playAt = now(); }

  pbEl.addEventListener('pointerdown', e => {
    if (pbEl.classList.contains('hidden') || exporting) return;
    const p = local(e), t = now(); try { pbEl.setPointerCapture(e.pointerId); } catch (_) {} mouseLocal = p; lastMoveT = t;
    const ib = islandButtonAt(p.x, p.y);
    if (ib >= 0 && e.button === 0) { islandAction(ib); kick(); return; }
    if (e.button === 1) {   // 中ボタン: キャンバス移動（全画面中は中身の表示位置のパン）
      e.preventDefault(); inertia.on = false; inertia.vx = inertia.vy = 0; zoomTarget = null;
      if (focus && (focus.dir < 0 || !focus.settled)) return;
      const dbl = lastMid && t - lastMid.t < .3 && Math.abs(p.x - lastMid.x) + Math.abs(p.y - lastMid.y) < 6; lastMid = {t, x: p.x, y: p.y};
      if (dbl && focus) { const b = focus.b; zoomAnchor = {x: W / 2, y: H / 2}; zoomTarget = Math.min(W / cw(b), H / ch(b)); cam.cx = b.x; cam.cy = b.y; kick(); return; }
      inertia.on = false; inertia.vx = inertia.vy = 0; inertia.sampleT = performance.now();
      mode = 'pan'; press = {x: p.x, y: p.y, lx: p.x, ly: p.y, t, mt: t}; kick(); return;
    }
    if (e.button === 2) { press = {x: p.x, y: p.y, cx: e.clientX, cy: e.clientY, t, moved: false, ox: winOff.x, oy: winOff.y}; mode = 'rpress'; kick(); return; }
    if (e.button !== 0) return;
    const bh = barHit(p.x, p.y);   // 再生バー（左クリック専用）
    if (bh) {
      const o = bar.owner;
      if (bh === 'play') togglePlay(o); else if (bh === 'vol') bar.muted = !bar.muted; else if (bh === 'time') bar.countdown = !bar.countdown;
      else { mode = 'seek'; press = {x: p.x, y: p.y, t}; seekTo(p.x); }
      kick(); return;
    }
    const h = hit(p.x, p.y);
    if (focus) {   // 全画面中: ダブルクリックで解除。シングルは再生/一時停止だけ。ほかの操作はしない
      if (pendingClick && t - pendingClick.t < .28) { cancelClick(); mode = 'fdpress'; press = {x: p.x, y: p.y, t}; return; }
      schedClick(focus.b); return;
    }
    if (pendingClick && t - pendingClick.t < .28 && h && h.b === pendingClick.b) {   // ダブルクリックの2回目（離したときに確定）
      cancelClick(); activate(h.b); mode = 'dpress'; press = {x: p.x, y: p.y, t, b: h.b}; kick(); return;
    }
    if (h) {
      pushAnims.delete(h.b); raise(h.b);
      if (!(selected.size > 1 && selected.has(h.b))) selected.clear();
      activate(h.b);
      if (h.handle) { mode = 'resize'; press = {x: p.x, y: p.y, t, b: h.b, s0: h.b.scale, w0: toWorld(p.x, p.y)}; }
      else { mode = 'move'; press = {x: p.x, y: p.y, lx: p.x, ly: p.y, t, b: h.b, shift: e.shiftKey}; setLift(h.b, 1.025); }
      schedClick(h.b);
    } else {
      cancelClick(); if (active) setLift(active, 1); active = null;
      if (!e.shiftKey) selected.clear();
      mode = 'rect'; const w = toWorld(p.x, p.y); rect = {x0: w.x, y0: w.y, x1: w.x, y1: w.y}; press = {x: p.x, y: p.y, t};
    }
    kick();
  });

  pbEl.addEventListener('pointermove', e => {
    if (exporting) return;
    const p = local(e), t = now(); mouseLocal = p; lastMoveT = t; pointerInside = true;
    if (!press) {
      const ib = islandButtonAt(p.x, p.y);
      if (ib !== isl.hoverIdx) { if (isl.hoverIdx >= 0) { isl.leaveIdx = isl.hoverIdx; isl.leaveT0 = t; } isl.bounceFrom = ib >= 0 ? isl.bounce[ib] : 1; isl.hoverIdx = ib; isl.hoverT0 = t; }
      pbEl.style.cursor = ib >= 0 || barHit(p.x, p.y) ? 'pointer' : (hit(p.x, p.y) || {}).handle ? 'nwse-resize' : '';
      kick(); return;
    }
    const dx = p.x - (press.lx ?? press.x), dy = p.y - (press.ly ?? press.y); press.lx = p.x; press.ly = p.y;
    const dist = Math.abs(p.x - press.x) + Math.abs(p.y - press.y);
    if (mode === 'pan') {
      const bx = cam.cx, by = cam.cy; cam.cx -= dx / cam.z; cam.cy -= dy / cam.z; clampFocusCam();
      const gap = (performance.now() - inertia.sampleT); inertia.sampleT = performance.now();   // 実際に動いた量から速度（EMA 0.35、200ms以上空いたら使わない）
      if (gap > 0 && gap < 200) { const ivx = (cam.cx - bx) * 1000 / gap, ivy = (cam.cy - by) * 1000 / gap; inertia.vx = inertia.vx * .65 + ivx * .35; inertia.vy = inertia.vy * .65 + ivy * .35; }
    } else if (mode === 'move') {
      if (dist > 6) cancelClick();
      if ((press.shift || e.shiftKey) && dist > 8) { beginExport(press.b, e); return; }   // Shift+ドラッグでも逆輸入
      const targets = selected.size > 1 && selected.has(press.b) ? [...selected] : [press.b];
      targets.forEach(b => { b.x += dx / cam.z; b.y += dy / cam.z; });
    } else if (mode === 'resize') {
      if (dist > 6) cancelClick();
      const b = press.b, w = toWorld(p.x, p.y), d0 = Math.hypot(press.w0.x - b.x, press.w0.y - b.y), d1 = Math.hypot(w.x - b.x, w.y - b.y);
      b.scale = clamp(press.s0 * d1 / Math.max(1, d0), .35, 4);
    } else if (mode === 'rect') {
      const w = toWorld(p.x, p.y); rect.x1 = w.x; rect.y1 = w.y;
      const x0 = Math.min(rect.x0, rect.x1), x1 = Math.max(rect.x0, rect.x1), y0 = Math.min(rect.y0, rect.y1), y1 = Math.max(rect.y0, rect.y1);
      selected.clear(); BUB.forEach(b => { const r = boardOf(b); if (r.x1 >= x0 && r.x0 <= x1 && r.y1 >= y0 && r.y0 <= y1) selected.add(b); });
    } else if (mode === 'dpress') {
      if (dist > 3) press.moved3 = true;
      if (dist > 8) { beginExport(press.b, e); return; }
    } else if (mode === 'seek') seekTo(p.x);
    else if (mode === 'rpress' || mode === 'window') {
      if (Math.hypot(e.clientX - press.cx, e.clientY - press.cy) > 6) { mode = 'window'; press.moved = true; }
      if (mode === 'window') moveWindow(press.ox + e.clientX - press.cx, press.oy + e.clientY - press.cy);
    }
    kick();
  });
  const endPress = () => {
    if (exporting) return;
    const t = now(), m = mode, pr = press; mode = ''; press = null;
    if (m === 'pan') {   // 離す前に30ms以上止まっていたら慣性なし。40未満も始めない
      if (performance.now() - inertia.sampleT > 30) inertia.vx = inertia.vy = 0;
      inertia.on = Math.hypot(inertia.vx, inertia.vy) > 40; if (!inertia.on) inertia.vx = inertia.vy = 0;
    }
    if (m === 'move' && pr) { setLift(pr.b, 1); pushOverlaps(selected.size > 1 && selected.has(pr.b) ? [...selected] : [pr.b]); }
    if (m === 'resize' && pr) pushOverlaps([pr.b]);
    if (m === 'rect') rect = null;
    if (m === 'dpress' && pr) startFocus(pr.b);   // ダブルクリック確定 → 全画面
    if (m === 'fdpress') endFocus();
    if (m === 'rpress' && pr && !pr.moved) {      // 右クリック: アクティブ化だけ／右ダブルクリック: 全画面
      const h = hit(pr.x, pr.y);
      if (lastRight && t - lastRight.t < .3 && (focus || (h && h.b === lastRight.b))) { lastRight = null; if (focus) endFocus(); else startFocus(h.b); }
      else { lastRight = {t, b: h ? h.b : null}; if (h && !focus) { raise(h.b); activate(h.b); } }
    }
    kick();
  };
  pbEl.addEventListener('pointerup', endPress); pbEl.addEventListener('pointercancel', endPress);
  pbEl.addEventListener('pointerleave', () => { if (!press) { mouseLocal = null; pointerInside = false; if (isl.hoverIdx >= 0) { isl.leaveIdx = isl.hoverIdx; isl.leaveT0 = now(); } isl.hoverIdx = -1; kick(); } });
  pbEl.addEventListener('wheel', e => {   // PB の上ではホイールは常に PB のズーム（ページはスクロールしない）
    e.preventDefault(); if (pbEl.classList.contains('hidden') || (focus && (focus.dir < 0 || !focus.settled))) return;
    inertia.on = false; inertia.vx = inertia.vy = 0;
    const p = local(e), notches = clamp(-e.deltaY / (e.deltaMode === 1 ? 3 : 100), -3, 3);
    let tz = (zoomTarget ?? cam.z) * Math.pow(1.1, notches);
    if (focus) { const b = focus.b, mn = Math.min(W / cw(b), H / ch(b)); tz = clamp(tz, mn, mn * 6); } else tz = clamp(tz, .1, 6);
    zoomTarget = tz; zoomAnchor = p; kick();
  }, {passive: false});

  /* ---------- ウィンドウ（右ドラッグで移動・島のボタン） ---------- */
  const winOff = {x: 0, y: 0};
  function moveWindow(x, y) {
    const st = demoEl.getBoundingClientRect(), r = pbEl.getBoundingClientRect(), bx = r.left - winOff.x;
    winOff.x = clamp(x, st.left - bx - r.width * .45, st.right - bx - r.width * .55); winOff.y = clamp(y, -r.height * .25, r.height * .25);
    pbEl.style.translate = `${winOff.x}px ${winOff.y}px`;
  }
  function islandAction(i) {
    if (i === 3 || i === 1) {   // 閉じる / 最小化 → トレイへ。ショートカットで呼び戻す
      if (focus) { focus = null; focusAmt = 0; glassF = 1; pbBody.style.width = ''; pbBody.style.height = ''; }
      hideIsland(now()); pbEl.classList.add('hidden'); recall.hidden = false; mouseLocal = null;
    } else if (i === 2) {      // 最大化 ⇄ 戻す（中身を素早く消して、ウィンドウが変わったらフェードで戻す。島は即座に）
      host.classList.add('fading'); uiCv.classList.add('fading'); islandEl.style.visibility = 'hidden';
      setTimeout(() => {
        demoEl.classList.toggle('maxed'); winOff.x = winOff.y = 0; pbEl.style.translate = '';
        setTimeout(() => { applySize(); host.classList.remove('fading'); uiCv.classList.remove('fading'); islandEl.style.visibility = ''; kick(); }, 220);
      }, 120);
    }
  }
  function summon() { if (!pbEl.classList.contains('hidden')) return; pbEl.classList.remove('hidden'); recall.hidden = true; applySize(); kick(); }
  recall.addEventListener('click', summon);
  addEventListener('keydown', e => { if (e.ctrlKey && e.shiftKey && e.code === 'Space' && visible) { e.preventDefault(); summon(); } });

  /* ---------- 逆輸入（BubbleDragExporter）: 中身だけのプレビュー（最大 160×120）を PB の外へ ---------- */
  let exporting = null;
  const explorer = section.querySelector('.src-explorer'), exList = explorer.querySelector('.src-list');
  function beginExport(b, e) {
    cancelClick(); if (mode === 'move' && press) setLift(press.b, 1);
    mode = 'export'; press = null;
    const src = b.thumb, k = Math.min(160 / src.width, 120 / src.height, 1), pw = Math.round(src.width * k), ph = Math.round(src.height * k);
    const ghost = document.createElement('canvas'); ghost.className = 'export-ghost'; ghost.width = pw * 2; ghost.height = ph * 2; ghost.style.width = pw + 'px'; ghost.style.height = ph + 'px';
    ghost.getContext('2d').drawImage(src, 0, 0, pw * 2, ph * 2); document.body.appendChild(ghost);
    exporting = {b, ghost};
    const inEx = ev => { const r = explorer.getBoundingClientRect(); return ev.clientX > r.left && ev.clientX < r.right && ev.clientY > r.top && ev.clientY < r.bottom; };
    const mv = ev => { ghost.style.left = ev.clientX + 6 + 'px'; ghost.style.top = ev.clientY + 6 + 'px'; explorer.classList.toggle('drop-target', inEx(ev)); };
    mv(e);
    const up = ev => {
      removeEventListener('pointermove', mv); removeEventListener('pointerup', up);
      explorer.classList.remove('drop-target'); ghost.remove();
      if (inEx(ev)) addExplorerItem(b);
      exporting = null; mode = ''; kick();
    };
    addEventListener('pointermove', mv); addEventListener('pointerup', up);
    kick();
  }
  function addExplorerItem(b) {
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'item exported' + (b.kind === 'tile' ? ' tile' : ''); btn.dataset.key = b.key;
    const th = document.createElement('span'); th.dataset.thumb = b.key; const c = document.createElement('canvas'); c.width = b.thumb.width; c.height = b.thumb.height; c.getContext('2d').drawImage(b.thumb, 0, 0); th.appendChild(c);
    const sm = document.createElement('small'); sm.textContent = b.label; btn.append(th, sm); exList.appendChild(btn); wireItem(btn);
    explorer.classList.add('got-file'); setTimeout(() => explorer.classList.remove('got-file'), 900);
  }

  /* ---------- 外から素材を入れる（ドロップした場所にそのまま置く） ---------- */
  function wireItem(item) {
    item.addEventListener('pointerdown', e => {
      if (e.button !== 0) return; e.preventDefault();
      const key = item.dataset.key, r0 = item.getBoundingClientRect();
      const ghost = item.cloneNode(true); ghost.classList.add('ghost'); ghost.classList.remove('exported'); ghost.removeAttribute('id');
      const gcs = ghost.querySelectorAll('canvas'); item.querySelectorAll('canvas').forEach((c, i) => { const d = gcs[i]; d.width = c.width; d.height = c.height; d.getContext('2d').drawImage(c, 0, 0); });
      Object.assign(ghost.style, {left: r0.left + 'px', top: r0.top + 'px', width: r0.width + 'px', height: r0.height + 'px'});
      document.body.appendChild(ghost);
      const ox = e.clientX - r0.left, oy = e.clientY - r0.top; let moved = false;
      try { item.setPointerCapture(e.pointerId); } catch (_) {} item.classList.add('lifting');
      const move = ev => { if (Math.hypot(ev.clientX - e.clientX, ev.clientY - e.clientY) > 4) moved = true; ghost.style.left = ev.clientX - ox + 'px'; ghost.style.top = ev.clientY - oy + 'px'; };
      const up = ev => {
        item.removeEventListener('pointermove', move); item.removeEventListener('pointerup', up); item.removeEventListener('pointercancel', up);
        item.classList.remove('lifting'); ghost.remove();
        if (pbEl.classList.contains('hidden')) return;
        const pr = pbBody.getBoundingClientRect(), inside = ev.clientX > pr.left && ev.clientX < pr.right && ev.clientY > pr.top && ev.clientY < pr.bottom;
        if (focus) return;               // 全画面中はドロップできない
        if (inside || !moved) {          // タップだけでもボードの見えている場所に入れる
          const p = inside && moved ? toWorld(ev.clientX - pr.left, ev.clientY - pr.top) : toWorld(W / 2 + (Math.random() - .5) * W * .4, H / 2 + (Math.random() - .5) * H * .3);
          makeBubble(key, p.x, p.y).then(b => { BUB.push(b); pushOverlaps([b]); kick(); });
        }
      };
      item.addEventListener('pointermove', move); item.addEventListener('pointerup', up); item.addEventListener('pointercancel', up);
    });
  }
  section.querySelectorAll('.src .item').forEach(wireItem);

  addEventListener('pbstyle', e => { style = e.detail; styleChangedAt = now(); kick(); });
  section.querySelector('.demo-reset').addEventListener('click', async () => {
    focus = null; focusAmt = 0; glassF = 1; pbBody.style.width = ''; pbBody.style.height = ''; demoEl.classList.remove('maxed'); winOff.x = winOff.y = 0; pbEl.style.translate = '';
    pbEl.classList.remove('hidden'); recall.hidden = true; exList.querySelectorAll('.exported').forEach(x => x.remove());
    active = null; selected.clear(); BUB.length = 0; applySize(); fitCam(); await seed(); kick();
  });

  /* ---------- ループ ---------- */
  let raf = 0;
  function loop() {
    raf = 0; if (!visible) return;
    const t = now(), dt = Math.min(.05, Math.max(0, t - lastT)); lastT = t;
    const a = render(t, dt);
    if (a || press || mode || pendingClick || shiftDown) raf = requestAnimationFrame(loop);
  }
  function kick() { if (!raf && visible) { lastT = Math.max(lastT, now() - .016); raf = requestAnimationFrame(loop); } }
  new IntersectionObserver(es => { visible = es[0].isIntersecting; if (visible) kick(); }).observe(demoEl);

  function fitCam() { cam.cx = 0; cam.cy = 0; cam.z = clamp(Math.min(W / 820, H / 470), .4, 1); }
  async function seed() { for (const [k, x, y] of [['ocean', -60, -10], ['sunset', -330, 30], ['folder', 210, -70], ['site', 210, 95]]) BUB.push(await makeBubble(k, x, y)); }
  (async () => {
    TEX_STOP = g.texFrom(await loadCanvas('assets/ui_stop.png'));
    TEX_PLAY = g.texFrom(await loadCanvas('assets/ui_play.png'));
    applySize(); fitCam(); await seed();
    section.querySelectorAll('.src .item [data-thumb]').forEach(async el => {
      const S = SOURCES[el.dataset.thumb];
      try {
        if (S.web) el.appendChild(siteThumb());
        else if (S.kind === 'tile') { const im = new Image(); im.alt = ''; im.src = `assets/icon_${S.icon}.png`; el.appendChild(im); }
        else if (S.kind === 'video') { const c = document.createElement('canvas'); c.width = 320; c.height = 180; PAINT[S.paint](c, 1.2); el.appendChild(c); }
        else el.appendChild(await S.make());
      } catch (e) { console.error(e); }
    });
    kick();
  })().catch(e => showDemoError(demoEl, e));
}
function showDemoError(demoEl, e) {
  console.error(e);
  const box = document.createElement('p'); box.className = 'demo-error';
  box.textContent = 'デモを読み込めませんでした: ' + (e && e.message || e);
  demoEl.querySelector('.pb-body').appendChild(box);
}

/* 紹介画像を画像バブルとして描く（デモと同じガラス。スタイルのスイッチにも追従） */
function initFigures() {
  const figs = [...document.querySelectorAll('.bubble-fig')]; if (!figs.length) return;
  let g = null; try { g = makeGLR(); } catch (e) { g = null; console.error(e); }
  if (!g) { figs.forEach(f => f.classList.add('no-gl')); return; }
  let style = window.PB_STYLE || 'gummy', styleAt = -10;
  const now = () => performance.now() / 1000;
  const items = figs.map(el => {
    const cv = document.createElement('canvas'); cv.className = 'fig-cv'; el.appendChild(cv);
    const it = {el, cv, ctx: cv.getContext('2d'), img: null, tex: null, small: null, s: 1, sTarget: 1, w: 0, h: 0, M: 0, visible: false};
    const im = new Image(); im.onload = () => { it.img = im; it.tex = g.texFrom(im, {mip: true}); it.small = g.makeSmall(im, 0, 0, im.width, im.height); layout(it); paint(it); }; im.src = el.dataset.src;
    el.addEventListener('pointerenter', () => { it.sTarget = 1.012; kick(); });   // ごく控えめに大きく
    el.addEventListener('pointerleave', () => { it.sTarget = 1; kick(); });
    return it;
  });
  // 中身の矩形は要素いっぱい（16:9）。枠・影ははみ出して描くので、キャンバスを外側へ広げる
  function layout(it) {
    const r = it.el.getBoundingClientRect(); if (!r.width) return;
    const cw = r.width, ch = r.height, bez = Math.min(cw, ch) * MEDIA_BEZEL_RATIO, M = Math.ceil(bez * 2.6);
    it.cw = cw; it.ch = ch; it.bez = bez; it.M = M; it.w = cw + M * 2; it.h = ch + M * 2;
    const d = Math.min(2, devicePixelRatio || 1); it.d = d;
    it.cv.width = Math.round(it.w * d); it.cv.height = Math.round(it.h * d);
    Object.assign(it.cv.style, {left: -M + 'px', top: -M + 'px', width: it.w + 'px', height: it.h + 'px'});
  }
  function paint(it, t = now()) {
    if (!it.tex || !it.w) return false;
    g.resize(it.w, it.h, it.d); g.begin();
    const gummy = style === 'gummy', pm = g.pm;
    let s = it.s, wob = 0, anim = false;
    const d2 = t - styleAt;   // スタイル切り替えのぷるっ（デモと同じ演出）
    if (d2 > 0 && d2 < .7) { s *= 1 - Math.sin(Math.min(d2, .12) / .12 * Math.PI) * .03; wob = Math.sin(d2 * 24) * Math.exp(-d2 * 7) * .02; anim = true; }
    const cx = it.w / 2, cy = it.h / 2, sw = it.cw * s * (1 + wob), sh = it.ch * s * (1 - wob);
    const bez = Math.min(sw, sh) * MEDIA_BEZEL_RATIO, sr = [cx - sw / 2, cy - sh / 2, sw, sh], board = [sr[0] - bez, sr[1] - bez, sw + bez * 2, sh + bez * 2];
    const boardR = bez * 1.25, contentR = Math.min(sw, sh) * MEDIA_BEZEL_RATIO * .25;
    const lightAngle = Math.atan2(-it.h * .25 - cy, it.w * .3 - cx);
    g.glow(...board, boardR, gummy ? pm(5, 31, 38, 150 * GUMMY_SHADOW_K) : pm(0, 0, 0, 45 * SHADOW_K), Math.max(8, bez * (gummy ? 1.21 : .64)));
    g.glow(...sr, contentR, pm(2, 4, 8, gummy ? 67 * GUMMY_CONTACT_K : 82 * CONTACT_SHADOW_K), bez * .22);
    g.rect(...board, boardR, pm(255, 255, 255, gummy ? 0 : 46), pm(255, 255, 255, gummy ? 118 : 130), 1.5);
    const ix = board[0] + board[2] - bez * .5, iy = board[1] + board[3] - bez * .5, is = bez * 10 / 25, lw = Math.max(1, bez * 1.5 / 25), c = pm(255, 255, 255, 180);
    g.line(ix - is, iy - is * .3, ix - is * .3, iy - is, lw, c); g.line(ix - is * .6, iy - is * .3, ix - is * .3, iy - is * .6, lw, c);
    g.image(it.tex, ...sr, contentR, 1);
    g.glass(style, {board, radius: boardR, bezel: bez, contentRadius: contentR, lightAngle, intensity: .8, innerMix: 1, launcher: false, content: it.tex, small: gummy ? it.small : null});
    it.ctx.setTransform(1, 0, 0, 1, 0, 0); it.ctx.clearRect(0, 0, it.cv.width, it.cv.height); it.ctx.drawImage(g.cv, 0, 0); it.el.classList.add('gl');
    return anim;
  }
  let raf = 0, lastT = now();
  function loop() {
    raf = 0; const t = now(), dt = Math.min(.05, t - lastT); lastT = t; let more = false;
    for (const it of items) {
      if (!it.visible) continue;
      const ds = it.sTarget - it.s, moving = Math.abs(ds) > 1e-4;
      if (moving) it.s += ds * Math.min(1, dt * 9); else it.s = it.sTarget;   // なめらかに
      if (moving || it.dirty || (t - styleAt) < .75) { if (paint(it, t) || moving) more = true; it.dirty = false; }
    }
    if (more || (now() - styleAt) < .75) raf = requestAnimationFrame(loop);
  }
  function kick() { if (!raf) { lastT = now() - .016; raf = requestAnimationFrame(loop); } }
  const io = new IntersectionObserver(es => es.forEach(e => { const it = items.find(i => i.el === e.target); it.visible = e.isIntersecting; if (it.visible) { it.dirty = true; kick(); } }), {rootMargin: '200px'});
  items.forEach(it => io.observe(it.el));
  items.forEach(it => new ResizeObserver(() => { layout(it); it.dirty = true; kick(); }).observe(it.el));
  addEventListener('pbstyle', e => { style = e.detail; styleAt = now(); items.forEach(it => it.dirty = true); kick(); });
}

/* ガラスのスタイル切り替え（本体の島・再生バーと同じガラスの台。つまみはドラッグでも動かせる） */
function initStyleSwitch() {
  const sw = document.getElementById('style-switch'); if (!sw) return;
  const plate = sw.querySelector('canvas'), thumb = sw.querySelector('.sw-thumb'), btns = [...sw.querySelectorAll('button')];
  const order = btns.map(b => b.dataset.style);
  let idx = Math.max(0, order.indexOf(window.PB_STYLE || 'gummy')), pos = idx, drag = null;
  const PAD = 4;
  function geom() { const r = sw.getBoundingClientRect(); return {w: r.width, h: r.height, seg: (r.width - PAD * 2) / order.length}; }
  function drawPlate() {
    const {w, h} = geom(), d = Math.min(2, devicePixelRatio || 1);
    plate.width = Math.round(w * d); plate.height = Math.round(h * d);
    const x = plate.getContext('2d'); x.setTransform(d, 0, 0, d, 0, 0); x.clearRect(0, 0, w, h);
    paintIslandBody(x, w, h, '#6f7076');   // 本体の既定のアクセント色（グレー）
  }
  function place(animate) {
    const {seg} = geom();
    thumb.style.transition = animate ? 'transform .42s cubic-bezier(.3,1.45,.5,1)' : 'none';
    thumb.style.width = seg + 'px'; thumb.style.transform = `translateX(${PAD + pos * seg}px)`;
    btns.forEach((b, i) => { const on = Math.abs(pos - i) < .5; b.setAttribute('aria-checked', on); b.tabIndex = on ? 0 : -1; });
  }
  function choose(i, fromDrag) {
    i = Math.max(0, Math.min(order.length - 1, i));
    if (i !== idx || fromDrag === 'init') {
      idx = i; window.PB_STYLE = order[i];
      if (fromDrag !== 'init') dispatchEvent(new CustomEvent('pbstyle', {detail: order[i]}));
    }
  }
  // 押したところへは離したときに移動（クリック）。つかんで動かすとその場で追従して、離すと一番近い所へ収まる
  sw.addEventListener('pointerdown', e => {
    if (e.button !== 0) return; e.preventDefault(); sw.setPointerCapture(e.pointerId);
    const {seg} = geom(), r = sw.getBoundingClientRect(), px = (e.clientX - r.left - PAD) / seg - .5;
    drag = {startX: e.clientX, startPos: pos, px, onThumb: Math.abs(px - pos) < .55, moved: false};
  });
  sw.addEventListener('pointermove', e => {
    if (!drag) return; const {seg} = geom();
    if (!drag.moved && Math.abs(e.clientX - drag.startX) < 4) return;
    if (!drag.moved) { drag.moved = true; sw.classList.add('dragging'); if (!drag.onThumb) drag.startPos = Math.max(0, Math.min(order.length - 1, drag.px)); }
    pos = Math.max(-.1, Math.min(order.length - 1 + .1, drag.startPos + (e.clientX - drag.startX) / seg));
    place(false); choose(Math.round(Math.max(0, Math.min(order.length - 1, pos))), true);
  });
  const end = () => {
    if (!drag) return; const d = drag; drag = null; sw.classList.remove('dragging');
    if (!d.moved) choose(Math.round(Math.max(0, Math.min(order.length - 1, d.px))));
    pos = idx; place(true);
  };
  sw.addEventListener('pointerup', end); sw.addEventListener('pointercancel', end);
  sw.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') { e.preventDefault(); choose(idx + (e.key === 'ArrowRight' ? 1 : -1)); pos = idx; place(true); btns[idx].focus(); }
  });
  new ResizeObserver(() => { drawPlate(); place(false); }).observe(sw);
  choose(idx, 'init'); drawPlate(); place(false);
}

window.PB_STYLE = window.PB_STYLE || 'gummy';
const safe = (n, f) => { try { f(); } catch (e) { console.error(n, e); if (n === 'demo') { const d = document.getElementById('demo'); if (d) showDemoError(d, e); } } };
safe('switch', initStyleSwitch);
safe('demo', initDemo);
safe('figs', initFigures);
})();
